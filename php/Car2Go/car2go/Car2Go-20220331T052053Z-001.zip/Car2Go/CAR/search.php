<!DOCTYPE html>
<html>
<head>
<title>Search</title>
</head>
<body>
<!--------search------->

<div class="search" style="background-color: #eff6fa";>
            <div class="container" style="background-color:#ffffff"; >
                <div class="row " style="margin-left: 50px";>
				    <div class="col-lg-7" >
					    <table >
						    
							<tr>
							  
							  <td><img src="img/economy1.jpg"  alt="Maruti Suzuki Swift " width="250" height="200"></td>
							  <td><p><b>Maruti Suzuki Swift</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
										
							</tr>			
						</table>
					</div>		
				</div>
			</div>
</div>			
</body>
</html>