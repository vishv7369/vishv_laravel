<!DOCTYPE html>
<html>
<head>
<title>Economy Car's</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
  <style>
  table {
            margin-left: auto;
            margin-right: auto;
            font-size: 20px;
            height: 100%;
            table-layout: fixed;
        }
  td {
	       width: 10%;
            border: 1px ;
            text-align: center;
            padding: 10px;
        }
  		
  </style>
</head>

<body>
<div class="section-header text-left" style="margin-left: 500px";>
     <p><b><u><span style="color:#202C45";>Economy Car's</span></u></b></p>
     <h2><u><span style="color:#202C45";>Car's in <span style="color:red";>your </span>budgets</span></u></h2>
</div><br>
<table class="auto-index"style="margin-left:25px";>
                              
							  <tr>
							  
							  <td><img src="img/economy1.jpg"  alt="Maruti Suzuki Swift " width="200" height="150"></td>
							  <td ><p><b>Maruti Suzuki Swift</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>		
							
                             <td><img src="img/economy7.jpg"  alt="Hyundai Elite i20 " width="200" height="150"></td>							 
                             <td ><p><b>Hyundai Elite i20</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">6L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>			
                              </tr>
							  
						     <tr>
							  
							  <td><img src="img/economy2.jpg"  alt="Maruti Suzuki Swift " width="200" height="150"></td>
							  <td ><p><b>Maruti Suzuki Swift</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>		
                            
                              <td><img src="img/economy8.jpg"  alt="Hyundai Elite i20 " width="200" height="150"></td>							 
                              <td ><p><b>Hyundai Elite i20</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">6L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>			
                              </tr>
                              
							  <tr>
							  
							  <td><img src="img/economy3.jpg"  alt="Maruti Suzuki Swift " width="200" height="150"></td>
							  <td ><p><b>Maruti Suzuki Swift</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>		
                              
                              <td><img src="img/economy9.jpg"  alt="Hyundai Elite i20 " width="200" height="150"></td>							 
                             <td ><p><b>Hyundai Elite i20</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">6L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>			
                              </tr>
                                
							  <tr>
							  
							  <td><img src="img/economy4.jpg"  alt="Maruti Suzuki Baleno " width="200" height="150"></td>
							  <td ><p><b>Maruti Suzuki Baleno</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>		
                              
                              <td><img src="img/economy10.jpg"  alt="Hyundai Grand i10 " width="200" height="150"></td>							 
                             <td ><p><b>Hyundai Grand i10</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">6L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>	
                              </tr>
                              <tr>
							  
							  <td><img src="img/economy5.jpg"  alt="Maruti Suzuki Baleno " width="200" height="150"></td>
							  <td ><p><b>Maruti Suzuki Baleno</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>		
                             
                              <td><img src="img/economy11.jpg"  alt="Hyundai Grand i10 " width="200" height="150"></td>							 
                             <td ><p><b>Hyundai Grand i10</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">6L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>	
                              </tr>  	
                              <tr>
							  
							  <td><img src="img/economy6.jpg"  alt="Maruti Suzuki Baleno " width="200" height="150"></td>
							  <td ><p><b>Maruti Suzuki Baleno</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>		
                            
                              <td><img src="img/economy12.jpg"  alt="Hyundai Grand i10 " width="200" height="150"></td>							 
                             <td ><p><b>Hyundai Grand i10</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">6L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>	
                              </tr>

                               <tr>
							  
							  <td><img src="img/economy13.jpg"  alt="Renault KWID " width="200" height="150"></td>
							  <td ><p><b>Renault KWID</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>		
                             
                              <td><img src="img/economy14.jpg"  alt="Renault KWID " width="200" height="150"></td>							 
                             <td ><p><b>Renault KWID</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">6L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>	
                              </tr>  		
      
                             <tr>
							  
							  <td><img src="img/economy15.jpg"  alt="Renault KWID " width="200" height="150"></td>
							  <td ><p><b>Renault KWID</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>		
                             
                              <td><img src="img/economy16.jpg"  alt="Renault KWID " width="200" height="150"></td>							 
                             <td ><p><b>Renault KWID</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">6L/100Km</i>
		                                </p></td>
							  <td ><h4>$27.00</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>	
                              </tr>  		  					  
</table>
</body>
</html>