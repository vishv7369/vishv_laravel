<!DOCTYPE html>
<html>
<head>
<title>Intermediate Car's</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
  <style>
  table {
            margin-left: auto;
            margin-right: auto;
            font-size: 20px;
            height: 100%;
            table-layout: fixed;
        }
  td {
	       width: 10%;
            border: 1px ;
            text-align: center;
            padding: 10px;
        }
  		
  </style>
  <body>
  <div class="section-header text-left" style="margin-left: 500px";>
     <p><b><u><span style="color:#202C45";>Intermediate Car's</span></u></b></p>
     <h2><u><span style="color:#202C45";>Car's in <span style="color:red";>your </span>budgets</span></u></h2>
 </div><br>
 <table class="auto-index" style="margin-left:25px";>
                      <tr>
							  
							  <td><img src="img/intermediate1.jpg"  alt="Honda city " width="200" height="150"></td>
							  <td ><p><b>Honda city</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
							  <td ><h4>$53.09</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>		
							 
                             <td><img src="img/intermediate2.jpg"  alt="Honda city " width="200" height="150"></td>							 
                             <td ><p><b>Honda city</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">6L/100Km</i>
		                                </p></td>
							  <td ><h4>$53.09</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>			
                      </tr>
					  
					  <tr>
							  
							  <td><img src="img/intermediate3.jpg"  alt="Honda city " width="200" height="150"></td>
							  <td ><p><b>Honda city</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
							  <td ><h4>$53.09</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>		
							
                             <td><img src="img/intermediate4.jpg"  alt="Honda city " width="200" height="150"></td>							 
                             <td ><p><b>Honda city</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">6L/100Km</i>
		                                </p></td>
							  <td ><h4>$53.09</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>			
                      </tr>
					  
					  <tr>
							  
							  <td><img src="img/intermediate5.jpg"  alt="Honda city " width="200" height="150"></td>
							  <td ><p><b>Honda city</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
							  <td ><h4>$53.09</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>		
							 
                             <td><img src="img/intermediate6.jpg"  alt="Honda city " width="200" height="150"></td>							 
                             <td ><p><b>Honda city</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">6L/100Km</i>
		                                </p></td>
							  <td ><h4>$53.09</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>			
                      </tr>
					  
					  <tr>
							  
							  <td><img src="img/intermediate7.jpg"  alt="Toyota " width="200" height="150"></td>
							  <td ><p><b>Toyota</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
							  <td ><h4>$53.09</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>		
							 
                             <td><img src="img/intermediate8.jpg"  alt="Toyota " width="200" height="150"></td>							 
                             <td ><p><b>Toyota</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">6L/100Km</i>
		                                </p></td>
							  <td ><h4>$53.09</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>			
                      </tr>
					  
					   <tr>
							  
							  <td><img src="img/intermediate9.jpg"  alt="Toyota " width="200" height="150"></td>
							  <td ><p><b>Toyota</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
							  <td ><h4>$53.09</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>		
							 
                             <td><img src="img/intermediate10.jpg"  alt="Toyota " width="200" height="150"></td>							 
                             <td ><p><b>Toyota</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">6L/100Km</i>
		                                </p></td>
							  <td ><h4>$53.09</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>			
                      </tr>
					  
					   <tr>
							  
							  <td><img src="img/intermediate11.jpg"  alt="Toyota " width="200" height="150"></td>
							  <td ><p><b>Toyota</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">5L/100Km</i>
		                                </p></td>
							  <td ><h4>$53.09</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>		
							 
                             <td><img src="img/intermediate12.jpg"  alt="Toyota " width="200" height="150"></td>							 
                             <td ><p><b>Toyota</b><br>
		                                                2019<br>
		                                 <i class="fa fa-user" aria-hidden="true">5</i><br>
		                                 <i class="fas fa-gas-pump" aria-hidden="true">6L/100Km</i>
		                                </p></td>
							  <td ><h4>$53.09</h4>
			                              Per day <br>
		                                  <button type="button" class="btn btn-danger">Book Now</button></td>			
                      </tr>
					  
 </table>
  </body>
  </html>