 <?php
    include_once('header.php');
?>
<style>
/* ---------------------------------------

[Main Stylesheet]

Project:    	  Drophut - Single Product Dropshipping HTML Template
Version:    	  1.0
Primary Use:      Dropshipping Business

------------------------------------------

[Table of contents]

1. Fonts
2. Reset Css
3. Global Settings
4. Section Styles
5. Colors
6. Margin and Padding
7. Background Overlay
8. Buttons Style
9. Preloader
10. ScrollUp Button
11. Main Header style
12. Hero Area
13. Features Area
14. Custom Hero
15. Promo Area
16. Our Partners
17. Pricing Table
18. Why Choose us
19. Parallax Area
20. Testimonial Area
21. Counter Area
22. App Area
23. Blog Area
24. Footer Area
25. Custom Banner
26. About Area
27. Award Area
28. Card Features
29. All Partners Area
30. Team Area
31. Card Apply Form
32. Become Partner Area
33. Card Details Area
34. Choose Card
35. Faq Area
36. Error Area

-------------------------------------------*/
/*** 

================
	Fonts
================


font-family: 'Nunito', sans-serif;

 ***/

@import url('https://fonts.googleapis.com/css?family=Nunito:300,300i,400,400i,600,600i,700,700i,900,900i&amp;display=swap');
* {
  box-sizing: border-box;
}

/* transition */
/* flex */
/* transform */
/* opacity */
/*----------------------------------------*/
/*  01. Theme default CSS
/*----------------------------------------*/
/*-- Google Font --*/
/*-- Common Style --*/
*, *::after, *::before {
  box-sizing: border-box;
}

html, body {
  height: 100%;
}

body {
  line-height: 24px;
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  visibility: visible;
  font-family: 'Nunito', sans-serif;
  color: #242424;
}

h1, h2, h3, h4, h5, h6 {
  font-weight: 700;
  margin-top: 0;
}

h1 {
  font-size: 48px;
  font-weight: 700;
}

h2 {
  font-size: 36px;
  line-height: 36px;
}

h3 {
  font-size: 30px;
  line-height: 30px;
}

h4 {
  font-size: 16px;
  line-height: 19px;
  font-weight: 700;
}

h5 {
  font-size: 14px;
  line-height: 18px;
}

h6 {
  font-size: 12px;
  line-height: 14px;
}

p:last-child {
  margin-bottom: 0;
}

a, button {
  color: inherit;
  line-height: inherit;
  text-decoration: none;
  cursor: pointer;
}

a, button, img, input, span {
  transition: all 0.3s ease 0s;
}

*:focus {
  outline: none !important;
}

a:focus {
  color: inherit;
  outline: none;
  text-decoration: none;
}

a:hover {
  text-decoration: none;
}

button, input[type="submit"] {
  cursor: pointer;
}

img {
  max-width: 100%;
  height: auto;
}

ul {
  list-style: outside none none;
  margin: 0;
  padding: 0;
}

figure {
  padding: 0;
  margin: 0;
}

/*-- 
    - Common Classes
-----------------------------------------*/
.fix {
  overflow: hidden;
}

.hidden {
  display: none;
}

.clear {
  clear: both;
}

@media only screen and (max-width: 767px) {
  .container {
    max-width: 100%;
  }
}
@media only screen and (max-width: 479px) {
  .container {
    width: 100%;
  }
}
.capitalize {
  text-transform: capitalize;
}

.uppercase {
  text-transform: uppercase;
}

.no-gutters > .col, .no-gutters > [class*="col-"] {
  padding-right: 0;
  padding-left: 0;
  margin: 0;
}

/*-- 
    - Background color
-----------------------------------------*/
.bg-white {
  background-color: #ffffff;
}

.bg-light-grey {
  background-color: #f6fafb;
}

.bg-grey {
  background-color: #f8f8f8;
}

.bluewood-bg {
  background: #354b65;
}

/*- Overlay Color BG -*/
.bluewood-bg-overlay {
  position: relative;
}
.bluewood-bg-overlay::before {
  background: rgba(70, 90, 112, 0.9);
  content: "";
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
}

.overly-bg-black {
  position: relative;
}
.overly-bg-black::after {
  background: rgba(0, 0, 0, 0.3);
  content: "";
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
}

/*-- 
    - color
-----------------------------------------*/
/*-- 
    - Input Placeholder
-----------------------------------------*/
input:-moz-placeholder, textarea:-moz-placeholder {
  opacity: 1;
  filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
  -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
}

input::-webkit-input-placeholder, textarea::-webkit-input-placeholder {
  opacity: 1;
  filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
  -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
}

input::-moz-placeholder, textarea::-moz-placeholder {
  opacity: 1;
  filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
  -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
}

input:-ms-input-placeholder, textarea:-ms-input-placeholder {
  opacity: 1;
  filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
  -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
}

/*-- 
    Scroll Up 
-----------------------------------------*/
#scrollUp {
  background: #1D1678 none repeat scroll 0 0;
  bottom: 80px;
  color: #ffffff;
  cursor: pointer;
  display: none;
  font-size: 16px;
  height: 45px;
  line-height: 39px;
  position: fixed;
  border-radius: 5px;
  right: 20px;
  text-align: center;
  width: 45px;
  z-index: 9999;
  border: 2px solid #fff;
  -webkit-transition: .3s;
  transition: .3s;
}

/*-- 
    - Main Wrapper
-----------------------------------------*/
.main-wrapper.header-transparent {
  padding: 0 !important;
  margin: 0 !important;
}

/*-- 
    - Section Padding
-------------------------------------*/
.section-ptb {
  padding: 100px 0;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .section-ptb {
    padding: 90px 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .section-ptb {
    padding: 80px 0;
  }
}
@media only screen and (max-width: 767px) {
  .section-ptb {
    padding: 70px 0;
  }
}
@media only screen and (max-width: 479px) {
  .section-ptb {
    padding: 60px 0;
  }
}

.section-pt {
  padding-top: 100px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .section-pt {
    padding-top: 90px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .section-pt {
    padding-top: 80px;
  }
}
@media only screen and (max-width: 767px) {
  .section-pt {
    padding-top: 70px;
  }
}
@media only screen and (max-width: 479px) {
  .section-pt {
    padding-top: 60px;
  }
}

.section-pt-70 {
  padding-top: 70px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .section-pt-70 {
    padding-top: 60px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .section-pt-70 {
    padding-top: 50px;
  }
}
@media only screen and (max-width: 767px) {
  .section-pt-70 {
    padding-top: 40px;
  }
}
@media only screen and (max-width: 479px) {
  .section-pt-70 {
    padding-top: 30px;
  }
}

.section-pb-70 {
  padding-bottom: 80px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .section-pb-70 {
    padding-bottom: 60px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .section-pb-70 {
    padding-bottom: 50px;
  }
}
@media only screen and (max-width: 767px) {
  .section-pb-70 {
    padding-bottom: 40px;
  }
}
@media only screen and (max-width: 479px) {
  .section-pb-70 {
    padding-bottom: 30px;
  }
}

.section-pb {
  padding-bottom: 100px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .section-pb {
    padding-bottom: 90px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .section-pb {
    padding-bottom: 80px;
  }
}
@media only screen and (max-width: 767px) {
  .section-pb {
    padding-bottom: 70px;
  }
}
@media only screen and (max-width: 479px) {
  .section-pb {
    padding-bottom: 60px;
  }
}

.mt-23 {
  margin-top: 23px;
}

.mt-30 {
  margin-top: 30px;
}

.mt-32 {
  margin-top: 32px;
}

.mt-50 {
  margin-top: 50px;
}

.mt-60 {
  margin-top: 60px;
}

.mb-0 {
  margin-bottom: 0;
}

.mb-15 {
  margin-bottom: 15px;
}

.mb-40 {
  margin-bottom: 40px;
}

.mb-45 {
  margin-bottom: 45px;
}

.mb-46 {
  margin-bottom: 46px;
}

.mb-50 {
  margin-bottom: 50px;
}

.mb-30 {
  margin-bottom: 30px;
}

.mb-36 {
  margin-bottom: 36px;
}

.mb-55 {
  margin-bottom: 55px;
}

.mb-60 {
  margin-bottom: 60px;
}

.mb-65 {
  margin-bottom: 65px;
}

.mb-68 {
  margin-bottom: 68px;
}

.mb-70 {
  margin-bottom: 70px;
}

/* 02. Element */
.button {
  background: #fb5252;
  box-shadow: none;
  color: #ffffff;
  display: inline-block;
  height: 45px;
  line-height: 45px;
  padding: 0 22px;
  text-transform: uppercase;
  font-size: 13px;
  border-radius: 3px;
}

/* 2. Home 1 Header css here */
/* 01. header css here */
.off_canvars_overlay {
  width: 100%;
  height: 100%;
  position: fixed;
  z-index: 99;
  opacity: 0;
  visibility: hidden;
  cursor: crosshair;
  background: #242424;
  top: 0;
}
.off_canvars_overlay.active {
  opacity: 0.5;
  visibility: visible;
}

.Offcanvas_menu {
  display: none;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .Offcanvas_menu {
    display: block;
  }
}
@media only screen and (max-width: 767px) {
  .Offcanvas_menu {
    display: block;
  }
}

.Offcanvas_menu_wrapper {
  width: 290px;
  position: fixed;
  background: #fff;
  z-index: 99;
  top: 0;
  height: 100vh;
  transition: .5s;
  left: 0;
  margin-left: -300px;
  padding: 50px 20px 30px;
  overflow-y: auto;
}
.Offcanvas_menu_wrapper.active {
  margin-left: 0;
}
.Offcanvas_menu_wrapper .slinky-theme-default {
  background: inherit;
  min-height: 300px;
  overflow-y: auto;
}
.Offcanvas_menu_wrapper .search_container {
  display: block;
}
.Offcanvas_menu_wrapper .middel_right_info {
  display: flex;
  justify-content: center;
}

.offcanvas_main_menu > li.menu-item-has-children.menu-open > span.menu-expand {
  transform: rotate(180deg);
}
.offcanvas_main_menu > li ul li.menu-item-has-children.menu-open span.menu-expand {
  transform: rotate(180deg);
}

.offcanvas_main_menu li {
  position: relative;
}
.offcanvas_main_menu li:last-child {
  margin: 0;
}
.offcanvas_main_menu li span.menu-expand {
  position: absolute;
  right: 0;
}
.offcanvas_main_menu li a {
  font-size: 14px;
  font-weight: 400;
  text-transform: capitalize;
  display: block;
  padding-bottom: 10px;
  margin-bottom: 10px;
  border-bottom: 1px solid #ebebeb;
}
.offcanvas_main_menu li a:hover {
  color: #1D1678;
}
.offcanvas_main_menu li ul.sub-menu {
  padding-left: 20px;
}

.Offcanvas_footer {
  margin-top: 50px;
  padding-bottom: 50px;
  text-align: center;
}
.Offcanvas_footer span a {
  font-size: 14px;
}
.Offcanvas_footer span a:hover {
  color: #1D1678;
}
.Offcanvas_footer ul {
  margin-top: 20px;
}
.Offcanvas_footer ul li {
  display: inline-block;
  margin-right: 4px;
}
.Offcanvas_footer ul li:last-child {
  margin-right: 0;
}
.Offcanvas_footer ul li a {
  display: inline-block;
  width: 30px;
  height: 30px;
  text-align: center;
  line-height: 30px;
  border-radius: 50%;
  font-size: 13px;
  color: #ffffff;
}
.Offcanvas_footer ul li.facebook a {
  background: #3c5b9b;
}
.Offcanvas_footer ul li.facebook a:hover {
  background: #1D1678;
}
.Offcanvas_footer ul li.twitter a {
  background: #1DA1F2;
}
.Offcanvas_footer ul li.twitter a:hover {
  background: #1D1678;
}
.Offcanvas_footer ul li.pinterest a {
  background: #BD081B;
}
.Offcanvas_footer ul li.pinterest a:hover {
  background: #1D1678;
}
.Offcanvas_footer ul li.google-plus a {
  background: #DD4D42;
}
.Offcanvas_footer ul li.google-plus a:hover {
  background: #1D1678;
}
.Offcanvas_footer ul li.linkedin a {
  background: #010103;
}
.Offcanvas_footer ul li.linkedin a:hover {
  background: #1D1678;
}

.slinky-theme-default a:not(.back) {
  padding: 10px 0;
  text-transform: capitalize;
  font-size: 16px;
  font-weight: 400;
}
.slinky-theme-default a:not(.back):hover {
  background: inherit;
  color: #1D1678;
}

.canvas_close {
  position: absolute;
  top: 10px;
  right: 13px;
}
.canvas_close a {
  font-size: 18px;
  text-transform: uppercase;
  font-weight: 600;
  width: 32px;
  height: 32px;
  display: block;
  text-align: center;
  line-height: 31px;
  border: 1px solid #ebebeb;
  border-radius: 50%;
}
.canvas_close a:hover {
  background: #1D1678;
  border-color: #1D1678;
  color: #fff;
}

.canvas_open {
  position: absolute;
  right: 17px;
  top: 26px;
  z-index: 9;
}
@media only screen and (max-width: 767px) {
  .canvas_open {
    right: 18px;
    top: 20px;
  }
}
.canvas_open a {
  font-size: 30px;
  color: #242424;
  width: 43px;
  height: 40px;
  display: block;
  line-height: 39px;
  text-align: center;
  border: 1px solid #ebebeb;
}
@media only screen and (max-width: 767px) {
  .canvas_open a {
    width: 35px;
    height: 34px;
    line-height: 34px;
    font-size: 24px;
  }
}
.canvas_open a:hover {
  color: #1D1678;
}

.Offcanvas_menu_two .canvas_close a:hover {
  background: #1953b4;
  border-color: #1953b4;
}
.Offcanvas_menu_two .offcanvas_main_menu li a:hover {
  color: #1953b4;
}
.Offcanvas_menu_two .Offcanvas_footer span a:hover {
  color: #1953b4;
}

@media only screen and (min-width: 768px) and (max-width: 991px) {
  .main_header {
    padding-bottom: 30px;
  }
}
@media only screen and (max-width: 767px) {
  .main_header {
    padding-bottom: 25px;
  }
}
.main_header.header_padding {
  padding-bottom: 0;
}

.sticky-header.sticky {
  position: fixed;
  z-index: 99;
  width: 100%;
  top: 0;
  background: rgba(255, 255, 255, 0.95);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.11);
  -webkit-animation-name: fadeInDown;
  animation-name: fadeInDown;
  -webkit-animation-duration: 900ms;
  animation-duration: 900ms;
  -webkit-animation-timing-function: cubic-bezier(0.2, 1, 0.22, 1);
  animation-timing-function: cubic-bezier(0.2, 1, 0.22, 1);
  -webkit-animation-delay: 0s;
  animation-delay: 0s;
  -webkit-animation-iteration-count: 1;
  animation-iteration-count: 1;
  -webkit-animation-direction: normal;
  animation-direction: normal;
  -webkit-animation-fill-mode: none;
  animation-fill-mode: none;
  -webkit-animation-play-state: running;
  animation-play-state: running;
  border-bottom: 0;
  display: block;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .sticky-header.sticky {
    display: none;
  }
}
@media only screen and (max-width: 767px) {
  .sticky-header.sticky {
    display: none;
  }
}

.sticky_header_area {
  display: none;
}

.sticky_header_right {
  display: flex;
  justify-content: flex-end;
}
.sticky_header_right .main_menu {
  margin-left: 0;
  margin-right: 50px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .sticky_header_right .main_menu {
    margin-right: 44px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .sticky_header_right .main_menu nav > ul > li {
    margin-right: 24px;
  }
}
.sticky_header_right .main_menu nav > ul > li > a {
  color: #242424;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .sticky_header_right .main_menu nav > ul > li > a {
    font-size: 13px;
  }
}
.sticky_header_right .main_menu nav > ul > li > a.active {
  color: #1D1678;
}
.sticky_header_right .main_menu nav > ul > li > a::before {
  display: none;
}
.sticky_header_right .main_menu nav > ul > li:hover > a {
  color: #1D1678;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .sticky_header_right .header_wishlist {
    margin-right: 30px;
  }
}

.header_top {
  background-image: linear-gradient(to right, #6a11cb 0%, #2575fc 100%);
  color: #fff;
}
@media only screen and (max-width: 767px) {
  .header_top {
    display: none;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .header_top {
    display: none;
  }
}

.support_info p {
  line-height: 43px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .support_info p {
    line-height: 22px;
    text-align: center;
    font-size: 12px;
  }
}
@media only screen and (max-width: 767px) {
  .support_info p {
    line-height: 22px;
    text-align: center;
    font-size: 12px;
  }
}
.support_info p a:hover {
  color: #c1c1c1;
}

@media only screen and (max-width: 767px) {
  .top_right {
    text-align: center !important;
    margin-bottom: 16px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .top_right {
    text-align: center !important;
    margin-bottom: 16px;
  }
}
.top_right > ul > li {
  display: inline-block;
  position: relative;
  padding-right: 20px;
  margin-right: 20px;
}
.top_right > ul > li:hover > a {
  color: #c1c1c1;
}
@media only screen and (max-width: 767px) {
  .top_right > ul > li {
    padding-right: 15px;
    margin-right: 15px;
  }
}
.top_right > ul > li:last-child {
  padding-right: 0;
  margin-right: 0;
}
.top_right > ul > li::before {
  position: absolute;
  content: "";
  width: 1px;
  height: 12px;
  background: #fff;
  top: 50%;
  right: 0px;
  transform: translatey(-50%);
}
.top_right > ul > li:last-child::before {
  display: none;
}
.top_right > ul > li > a {
  color: #fff;
  text-transform: capitalize;
  line-height: 43px;
  cursor: pointer;
  display: inline-block;
  font-weight: 400;
}
@media only screen and (max-width: 767px) {
  .top_right > ul > li > a {
    line-height: 30px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .top_right > ul > li > a {
    line-height: 30px;
  }
}

.top_right > ul > li:hover a:not([href]):not([tabindex]) {
  color: #1D1678;
}

/*header top css end*/
/* 2.2 header middel css here */
.logo a img {
  max-width: 162px;
}
@media only screen and (max-width: 767px) {
  .logo a img {
    max-width: 120px;
  }
}

.header_middle {
  padding: 25px 0;
  background: #3e51eb;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .header_middle {
    padding: 28px 0;
  }
}
@media only screen and (max-width: 767px) {
  .header_middle {
    padding: 23px 0 24px;
  }
}

.middel_right {
  display: flex;
  -webkit-box-pack: end;
  -ms-flex-pack: end;
  justify-content: flex-end;
  align-items: center;
}
@media only screen and (max-width: 767px) {
  .middel_right {
    justify-content: center;
    flex-direction: column;
  }
}

/*search container css here*/
.hover_category {
  position: relative;
}
.hover_category::before {
    content: "";
    width: 1px;
    height: 100%;
    background: #dcdcdc;
    position: absolute;
    right: 0;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .hover_category::before {
    display: none;
  }
}
@media only screen and (max-width: 767px) {
  .hover_category::before {
    display: none;
  }
}
.hover_category .select_option {
  border: 0;
  background: inherit;
  height: 47px;
  line-height: 47px;
  padding-left: 13px;
  padding-right: 30px;
  font-size: 14px;
  min-width: 170px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .hover_category .select_option {
    min-width: 150px;
    padding-right: 28px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .hover_category .select_option {
    height: 34px;
    line-height: 35px;
    font-size: 13px;
    padding-left: 50px;
    padding-right: 51px;
    border: 1px solid #ebebeb;
  }
}
@media only screen and (max-width: 767px) {
  .hover_category .select_option {
    height: 34px;
    line-height: 35px;
    font-size: 13px;
    padding-left: 50px;
    padding-right: 51px;
    border: 1px solid #ebebeb;
  }
}
.hover_category .select_option::after {
  top: 54%;
  right: 13px;
}
.hover_category .select_option ul.list {
  max-height: 300px;
  overflow: auto;
  border-radius: 0;
  margin: 0;
  overflow-y: scroll;
}


.hover_category .select_option ul.list::-webkit-scrollbar-track
{
	-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
	box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
	background-color: #F5F5F5;
}

.hover_category .select_option ul.list::-webkit-scrollbar
{
	width: 3px;
	background-color: #F5F5F5;
}

.hover_category .select_option ul.list::-webkit-scrollbar-thumb
{
	background-color: #FA5252;
}

.search_container {
  margin-right: 60px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .search_container {
    margin-right: 50px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .search_container {
    margin-bottom: 28px;
    display: none;
    margin-right: 0;
  }
}
@media only screen and (max-width: 767px) {
  .search_container {
    margin-bottom: 28px;
    margin-right: 0;
    display: none;
  }
}
.search_container form {
  display: flex;
  background: #fff;
  width: 600px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .search_container form {
    width: 481px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .search_container form {
    flex-direction: column-reverse;
    border: 0;
    align-items: center;
    width: 100%;
  }
}
@media only screen and (max-width: 767px) {
  .search_container form {
    flex-direction: column-reverse;
    border: 0;
    align-items: center;
    width: 100%;
  }
}

.search_box {
  position: relative;
  width: 100%;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .search_box {
    border: 1px solid #ebebeb;
    margin-bottom: 25px;
  }
}
@media only screen and (max-width: 767px) {
  .search_box {
    border: 1px solid #ebebeb;
    margin-bottom: 25px;
  }
}
.search_box input::-webkit-input-placeholder {
  /* Chrome/Opera/Safari */
  color: #242424;
}
.search_box input::-moz-placeholder {
  /* Firefox 19+ */
  color: #242424;
}
.search_box input:-ms-input-placeholder {
  /* IE 10+ */
  color: #242424;
}
.search_box input:-moz-placeholder {
  /* Firefox 18- */
  color: #242424;
}
.search_box input {
  border: 0;
  background: inherit;
  width: 100%;
  height: 46px;
  color: #242424;
  font-size: 14px;
  font-weight: 400;
  padding: 0 132px 0 20px;
  opacity: 0.7;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .search_box input {
    font-size: 12px;
    padding: 0 92px 0 10px;
    width: 100%;
    height: 34px;
  }
}
@media only screen and (max-width: 767px) {
  .search_box input {
    font-size: 12px;
    padding: 0 92px 0 10px;
    width: 100%;
    height: 34px;
  }
}
.search_box button {
  border: 0;
  position: absolute;
  top: -2px;
  bottom: -2px;
  right: -2px;
  background: #1D1678;
  color: #fff;
  font-weight: 400;
  padding: 0 20px;
  min-width: 120px;
  -webkit-transition: 0.3s;
  transition: 0.3s;
}
.search_box button:hover {
  background: #242424;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .search_box button {
    padding: 0 17px;
    min-width: 100px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .search_box button {
    min-width: 78px;
    padding: 0 14px;
    top: -1px;
    bottom: -1px;
    right: -1px;
  }
}
@media only screen and (max-width: 767px) {
  .search_box button {
    min-width: 78px;
    padding: 0 14px;
    top: -1px;
    bottom: -1px;
    right: -1px;
  }
}

/*search container css end*/
.middel_right_info {
  display: flex;
  align-items: center;
  margin-top: 7px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .middel_right_info {
    display: none;
    margin-bottom: 22px;
  }
}
@media only screen and (max-width: 767px) {
  .middel_right_info {
    display: none;
    margin-bottom: 22px;
  }
}

.header_wishlist {
  position: relative;
  margin-right: 25px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .header_wishlist {
    margin-right: 35px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .header_wishlist {
    margin-right: 35px;
  }
}
@media only screen and (max-width: 767px) {
  .header_wishlist {
    margin-right: 35px;
  }
}
.header_wishlist span.wishlist_quantity {
  position: absolute;
  left: 17px;
  width: 20px;
  height: 20px;
  line-height: 20px;
  text-align: center;
  color: #ffffff;
  background: #fa5252;
  border-radius: 50%;
  top: -7px;
  font-size: 11px;
}
.header_wishlist a {
  font-size: 20px;
  font-weight: 400;
  text-transform: capitalize;
  display: block;
}
.header_wishlist a:hover {
  color: #1D1678;
}
.header_wishlist a span {
  font-size: 32px;
  padding-right: 4px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .header_wishlist a span {
    font-size: 27px;
    padding-right: 3px;
  }
}

.mini_cart_wrapper {
  position: relative;
}
.mini_cart_wrapper:hover > a {
  color: #1D1678;
}
.mini_cart_wrapper span.cart_quantity {
  position: absolute;
  left: 17px;
  width: 20px;
  height: 20px;
  line-height: 20px;
  text-align: center;
  color: #ffffff;
  background: #fa5252;
  border-radius: 50%;
  top: -7px;
  font-size: 11px;
}
.mini_cart_wrapper > a {
  font-size: 14px;
  font-weight: 600;
  text-transform: capitalize;
  display: block;
}
.mini_cart_wrapper > a i.fa-shopping-bag {
  font-size: 20px;
  padding-right: 10px;
}
.mini_cart_wrapper > a i.fa-angle-down {
  margin-left: 6px;
}
.mini_cart_wrapper > a span {
  font-size: 32px;
  padding-right: 5px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .mini_cart_wrapper > a span {
    font-size: 27px;
    padding-right: 2px;
  }
}
.mini_cart_wrapper:hover .mini_cart {
  max-height: 500px;
  padding: 18px 28px 33px;
  visibility: visible;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .mini_cart_wrapper:hover .mini_cart {
    padding: 10px 11px 20px;
    visibility: inherit;
  }
}
@media only screen and (max-width: 767px) {
  .mini_cart_wrapper:hover .mini_cart {
    padding: 10px 11px 20px;
    visibility: inherit;
  }
}

.mini_cart {
  position: absolute;
  min-width: 355px;
  padding: 0 28px;
  background: #fff;
  border: 0;
  z-index: 999;
  right: 0;
  top: 142%;
  max-height: 0;
  visibility: hidden;
  overflow: hidden;
  border: 1px solid #ebebeb;
  -webkit-transition: 0.5s;
  transition: 0.5s;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .mini_cart {
    display: none;
    transition: unset;
    max-height: 500px;
    padding: 10px 11px 20px;
    min-width: 260px;
    border: 1px solid #ebebeb;
    right: -50px;
    visibility: inherit;
  }
}
@media only screen and (max-width: 767px) {
  .mini_cart {
    display: none;
    transition: unset;
    max-height: 500px;
    padding: 10px 11px 20px;
    min-width: 260px;
    border: 1px solid #ebebeb;
    right: -85px;
    visibility: inherit;
  }
}

.cart_img {
  width: 90px;
  margin-right: 10px;
  border: 1px solid transparent;
}
.cart_img:hover {
  border-color: #1D1678;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .cart_img {
    width: 70px;
  }
}
@media only screen and (max-width: 767px) {
  .cart_img {
    width: 70px;
  }
}

.cart_info {
  width: 63%;
}
.cart_info a {
  font-weight: 400;
  font-size: 14px;
  line-height: 20px;
  display: block;
  margin-bottom: 6px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .cart_info a {
    font-size: 13px;
  }
}
@media only screen and (max-width: 767px) {
  .cart_info a {
    font-size: 13px;
  }
}
.cart_info a:hover {
  color: #1D1678;
}
.cart_info p {
  font-size: 12px;
}
.cart_info p span {
  font-weight: 600;
}

.cart_remove a {
  font-size: 15px;
  border: 1px solid #ebebeb;
  width: 20px;
  height: 20px;
  display: block;
  line-height: 20px;
  text-align: center;
  border-radius: 50%;
}
.cart_remove a:hover {
  background: #1D1678;
  border-color: #1D1678;
  color: #ffffff;
}

.cart_item {
  overflow: hidden;
  padding: 11px 0;
  border-bottom: 1px solid #ebebeb;
  display: flex;
  justify-content: space-between;
}

.mini_cart_table {
  padding: 23px 0;
}

.cart_total {
  display: flex;
  justify-content: space-between;
}
.cart_total span {
  font-size: 14px;
  font-weight: 400;
}
.cart_total span.price {
  font-weight: 700;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .cart_total span {
    font-size: 13px;
  }
}
@media only screen and (max-width: 767px) {
  .cart_total span {
    font-size: 13px;
  }
}

.cart_button:first-child {
  margin-bottom: 15px;
}
.cart_button a {
  text-transform: uppercase;
  border-radius: 3px;
  font-size: 12px;
  font-weight: 600;
  background: #eef0f1;
  display: block;
  text-align: center;
  line-height: 20px;
  margin-bottom: 0;
  padding: 13px 0px 11px;
  border: 1px solid #ebebeb;
}
.cart_button a:hover {
  background: #1D1678;
  border-color: #1D1678;
  color: #fff;
}

/*header middel css end*/
/* 2.4 main menu css here */
.main_menu_area {
  background: #1D1678;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .main_menu_area {
    background: inherit;
  }
}
@media only screen and (max-width: 767px) {
  .main_menu_area {
    background: inherit;
  }
}

.menu_position {
  position: relative;
}

.main_menu {
  margin-left: 20px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .main_menu {
    margin-left: 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .main_menu {
    display: none;
  }
}
@media only screen and (max-width: 767px) {
  .main_menu {
    display: none;
  }
}
.main_menu nav > ul > li {
  display: inline-block;
  position: relative;
  margin-right: 45px;
  padding: 14px 0;
}
.main_menu nav > ul > li:last-child {
  margin-right: 0;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .main_menu nav > ul > li {
    margin-right: 36px;
  }
}
.main_menu nav > ul > li:hover ul.sub_menu {
  opacity: 1;
  visibility: visible;
  transform: perspective(600px) rotateX(0deg);
}
.main_menu nav > ul > li:hover .mega_menu {
  opacity: 1;
  visibility: visible;
  transform: perspective(600px) rotateX(0deg);
}
.main_menu nav > ul > li:hover > a::before {
  left: 0;
  right: 0;
  width: 100%;
}
.main_menu nav > ul > li > a {
  display: block;
  padding: 6px 0;
  font-size: 14px;
  line-height: 16px;
  text-transform: uppercase;
  font-weight: 600;
  color: #ffffff;
  position: relative;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .main_menu nav > ul > li > a {
    font-size: 13px;
  }
}
.main_menu nav > ul > li > a i {
  margin-left: 3px;
}
.main_menu nav > ul > li > a.active::before {
  left: 0;
  right: 0;
  width: 50%;
}
.main_menu nav > ul > li ul.sub_menu {
  position: absolute;
  min-width: 240px;
  padding: 24px 30px;
  background: #fff;
  box-shadow: 0 3px 11px 0 rgba(0, 0, 0, 0.1);
  -webkit-transform: translate3d(0, 5px, 0);
  transform: translate3d(0, 5px, 0);
  -webkit-transform-origin: 0 0 0;
  transform-origin: 0 0 0;
  left: 0;
  right: auto;
  opacity: 0;
  visibility: hidden;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  z-index: 99;
  top: 100%;
  text-align: left;
}
.main_menu nav > ul > li ul.sub_menu li a {
  font-size: 13px;
  font-weight: 400;
  display: block;
  line-height: 32px;
  text-transform: capitalize;
  font-size: 13px;
}
.main_menu nav > ul > li ul.sub_menu li a:hover {
  color: #1D1678;
}
.main_menu nav > ul > li.mega_items {
  position: static;
}
.main_menu nav > ul > li .mega_menu {
  position: absolute;
  min-width: 100%;
  padding: 25px 30px 30px 30px;
  background: #fff;
  box-shadow: 0 3px 11px 0 rgba(0, 0, 0, 0.1);
  -webkit-transform: translate3d(0, 5px, 0);
  transform: translate3d(0, 5px, 0);
  -webkit-transform-origin: 0 0 0;
  transform-origin: 0 0 0;
  left: 0;
  right: auto;
  opacity: 0;
  visibility: hidden;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  z-index: 99;
  top: 100%;
  text-align: left;
}

.mega_menu_inner {
  display: flex;
  justify-content: space-between;
}
.mega_menu_inner > li > a {
  font-size: 14px;
  line-height: 24px;
  text-transform: capitalize;
  font-weight: 600;
  display: block;
  margin-bottom: 8px;
}
.mega_menu_inner > li > a:hover {
  color: #1D1678;
}
.mega_menu_inner > li ul li {
  display: block;
}
.mega_menu_inner > li ul li a {
  font-size: 13px;
  font-weight: 400;
  display: block;
  line-height: 28px;
  text-transform: capitalize;
}
.mega_menu_inner > li ul li a:hover {
  color: #1D1678;
}

/*main menu css end*/
/*mobaile menu css here*/
.mean-container .mean-bar {
  background: inherit;
  position: absolute;
  z-index: 9;
  top: 43px;
  left: 0;
  width: 100%;
}
.mean-container .mean-bar::after {
  top: -33px;
  left: 22px;
  color: #fff;
}
@media only screen and (max-width: 767px) {
  .mean-container .mean-bar::after {
    left: 22px;
    font-size: 15px;
  }
}
.mean-container .mean-nav {
  max-height: 300px;
  overflow: auto;
}
.mean-container .mean-nav ul li a {
  font-weight: 400;
}
.mean-container a.meanmenu-reveal {
  float: left;
  right: 17px;
  top: -34px;
  color: #fff;
}
@media only screen and (max-width: 767px) {
  .mean-container a.meanmenu-reveal {
    right: 15px;
    top: -34px;
  }
}
.mean-container a.meanmenu-reveal span {
  background: #fff;
}

.mobile-menu {
  border: 1px solid #ddd;
  height: 45px;
  top: -31px;
  position: relative;
}
@media only screen and (max-width: 767px) {
  .mobile-menu {
    top: 19px;
  }
}

/*-- 2.3 Categories menu css here --*/
.categories_menu {
  position: relative;
}

.categories_title {
  background: #fa5252;
  padding: 0 30px;
  position: relative;
  cursor: pointer;
  height: 56px;
  line-height: 56px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_title {
    height: 45px;
    line-height: 46px;
  }
}
@media only screen and (max-width: 767px) {
  .categories_title {
    height: 43px;
    line-height: 43px;
  }
}
.categories_title::before {
  content: "\f394";
  color: #fff;
  display: inline-block;
  font-family: Ionicons;
  position: absolute;
  font-size: 22px;
  line-height: 0px;
  right: 20px;
  top: 50%;
  transform: translatey(-50%);
}
.categories_title h2 {
  font-size: 14px;
  font-weight: 600;
  line-height: 26px;
  color: #fff;
  cursor: pointer;
  margin-bottom: 0;
  display: inline-block;
}
@media only screen and (max-width: 767px) {
  .categories_title h2 {
    font-size: 13px;
    line-height: 22px;
  }
}

.categories_menu_toggle {
  padding: 15px 0 9px;
  border-left: 1px solid #ddd;
  border-right: 1px solid #ddd;
  border-bottom: 1px solid #ddd;
  background: #fff;
  position: absolute;
  width: 100%;
  top: 100%;
  display: none;
  z-index: 9;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_menu_toggle {
    display: none;
    max-height: 350px;
    overflow: auto;
  }
}
@media only screen and (max-width: 767px) {
  .categories_menu_toggle {
    display: none;
    max-height: 350px;
    overflow: auto;
    padding: 0 11px 0 20px;
  }
}
.categories_menu_toggle > ul > li {
  position: relative;
}
.categories_menu_toggle > ul > li > a {
  font-size: 14px;
  line-height: 43px;
  text-transform: capitalize;
  font-weight: 400;
  display: block;
  cursor: pointer;
  padding: 0 20px 0 30px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .categories_menu_toggle > ul > li > a {
    line-height: 38px;
  }
}
@media only screen and (max-width: 767px) {
  .categories_menu_toggle > ul > li > a {
    line-height: 35px;
    padding: 0;
  }
}
.categories_menu_toggle > ul > li > a i.fa-angle-right {
  float: right;
  font-size: 15px;
  line-height: 35px;
  transition: .3s;
  -webkit-transition: .3s;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_menu_toggle > ul > li > a i.fa-angle-right {
    display: none;
  }
}
@media only screen and (max-width: 767px) {
  .categories_menu_toggle > ul > li > a i.fa-angle-right {
    display: none;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_menu_toggle > ul > li > a:hover {
    color: #1D1678;
  }
}
@media only screen and (max-width: 767px) {
  .categories_menu_toggle > ul > li > a:hover {
    color: #1D1678;
  }
}
.categories_menu_toggle > ul > li:last-child > a {
  border-bottom: 0;
}
.categories_menu_toggle > ul > li:hover ul.categories_mega_menu {
  opacity: 1;
  visibility: visible;
  left: 100%;
}
.categories_menu_toggle > ul > li:hover > a {
  color: #1D1678;
}
.categories_menu_toggle > ul > li ul.categories_mega_menu {
  position: absolute;
  left: 120%;
  width: 720px;
  -webkit-box-shadow: 1px 0 6px 0 rgba(0, 0, 0, 0.3);
  box-shadow: 1px 0 6px 0 rgba(0, 0, 0, 0.3);
  background: #fff;
  padding: 25px 20px 23px;
  overflow: hidden;
  top: 0;
  -webkit-transition: .3s;
  transition: .3s;
  z-index: 99;
  opacity: 0;
  visibility: hidden;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .categories_menu_toggle > ul > li ul.categories_mega_menu {
    width: 680px;
  }
}
@media only screen and (max-width: 767px) {
  .categories_menu_toggle > ul > li ul.categories_mega_menu {
    display: none;
    opacity: inherit !important;
    visibility: inherit !important;
    left: inherit !important;
    width: 100%;
    top: 100%;
    max-height: 350px;
    overflow: auto;
    transition: unset;
    box-shadow: inherit;
    position: inherit;
    padding: 6px 20px 0px 25px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_menu_toggle > ul > li ul.categories_mega_menu {
    display: none;
    opacity: inherit !important;
    visibility: inherit !important;
    left: inherit !important;
    width: 100%;
    top: 100%;
    max-height: 350px;
    overflow: auto;
    transition: unset;
    box-shadow: inherit;
    position: inherit;
    padding: 6px 20px 0px 40px;
  }
}
.categories_menu_toggle > ul > li ul.categories_mega_menu.open {
  display: block;
  left: 0;
}
.categories_menu_toggle > ul > li ul.categories_mega_menu > li {
  padding: 0 15px;
  width: 25%;
  float: left;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_menu_toggle > ul > li ul.categories_mega_menu > li {
    width: 100%;
    padding: 0;
  }
}
@media only screen and (max-width: 767px) {
  .categories_menu_toggle > ul > li ul.categories_mega_menu > li {
    width: 100%;
    padding: 0;
  }
}
.categories_menu_toggle > ul > li ul.categories_mega_menu > li > a {
  line-height: 30px;
  font-size: 14px;
  font-weight: 600;
  text-transform: uppercase;
  display: block;
  margin-bottom: 10px;
}
.categories_menu_toggle > ul > li ul.categories_mega_menu > li > a:hover {
  color: #1D1678;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_menu_toggle > ul > li ul.categories_mega_menu > li.menu_item_children > a {
    text-transform: capitalize;
    font-weight: 400;
  }
}
@media only screen and (max-width: 767px) {
  .categories_menu_toggle > ul > li ul.categories_mega_menu > li.menu_item_children > a {
    text-transform: capitalize;
    font-weight: 400;
  }
}

@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_menu_toggle ul li.menu_item_children > a {
    position: relative;
  }
  .categories_menu_toggle ul li.menu_item_children > a::before {
    position: absolute;
    content: "+";
    right: 15px;
    top: 50%;
    transform: translatey(-50%);
    font-size: 20px;
  }
}
@media only screen and (max-width: 767px) {
  .categories_menu_toggle ul li.menu_item_children > a {
    position: relative;
  }
  .categories_menu_toggle ul li.menu_item_children > a::before {
    position: absolute;
    content: "+";
    right: 15px;
    top: 50%;
    transform: translatey(-50%);
    font-size: 20px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_menu_toggle ul li.menu_item_children.open > a::before {
    display: none;
  }
  .categories_menu_toggle ul li.menu_item_children.open > a::after {
    position: absolute;
    content: "-";
    right: 15px;
    top: 50%;
    transform: translatey(-50%);
    font-size: 30px;
  }
}
@media only screen and (max-width: 767px) {
  .categories_menu_toggle ul li.menu_item_children.open > a::before {
    display: none;
  }
  .categories_menu_toggle ul li.menu_item_children.open > a::after {
    position: absolute;
    content: "-";
    right: 15px;
    top: 50%;
    transform: translatey(-50%);
    font-size: 30px;
  }
}

@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categorie_sub_menu {
    display: none;
    padding: 1px 0 9px 30px;
  }
}
@media only screen and (max-width: 767px) {
  .categorie_sub_menu {
    display: none;
    padding: 1px 0 9px 30px;
  }
}
.categorie_sub_menu li a {
  color: #242424;
  text-transform: capitalize;
  display: block;
  font-size: 14px;
  font-weight: 400;
  line-height: 30px;
}
.categorie_sub_menu li a:hover {
  color: #1D1678;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categorie_sub_menu li a {
    line-height: 33px;
  }
}
@media only screen and (max-width: 767px) {
  .categorie_sub_menu li a {
    line-height: 33px;
  }
}

.categories_menu_toggle ul li ul.categories_mega_menu.column_3 {
  width: 620px;
}
@media only screen and (max-width: 767px) {
  .categories_menu_toggle ul li ul.categories_mega_menu.column_3 {
    width: 100%;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_menu_toggle ul li ul.categories_mega_menu.column_3 {
    width: 100%;
  }
}

.categories_menu_toggle ul li ul.categories_mega_menu.column_3 > li {
  width: 33.33%;
}
@media only screen and (max-width: 767px) {
  .categories_menu_toggle ul li ul.categories_mega_menu.column_3 > li {
    width: 100%;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_menu_toggle ul li ul.categories_mega_menu.column_3 > li {
    width: 100%;
  }
}

.categories_menu_toggle ul li ul.categories_mega_menu.column_2 {
  width: 500px;
}
@media only screen and (max-width: 767px) {
  .categories_menu_toggle ul li ul.categories_mega_menu.column_2 {
    width: 100%;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_menu_toggle ul li ul.categories_mega_menu.column_2 {
    width: 100%;
  }
}

.categories_menu_toggle ul li ul.categories_mega_menu.column_2 > li {
  width: 50%;
}
@media only screen and (max-width: 767px) {
  .categories_menu_toggle ul li ul.categories_mega_menu.column_2 > li {
    width: 100%;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_menu_toggle ul li ul.categories_mega_menu.column_2 > li {
    width: 100%;
  }
}

.categorie_sub {
  opacity: 0;
  z-index: 999;
  position: absolute;
  width: 101%;
  left: -1px;
  border: lef;
  border-left: 1px solid #ddd;
  border-right: 1px solid #ddd;
  border-bottom: 1px solid #ddd;
  background: #fff;
  -webkit-transition: .3s;
  transition: .3s;
  top: 65%;
  visibility: hidden;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categorie_sub {
    width: 100%;
    left: 0px;
  }
}
.categorie_sub.open {
  top: 95%;
  opacity: 1;
  visibility: visible;
}

.categories_menu_toggle ul li.has-sub > a::before {
  position: absolute;
  content: "\f107";
  font-family: FontAwesome;
  top: 0;
  right: 20px;
  font-size: 18px;
  pointer-events: none;
}

.categories_menu_toggle ul li.has-sub > a.open::before {
  content: "\f106";
}

.categories_menu_toggle ul li.has-sub ul.categorie_sub li a {
  text-transform: capitalize;
  font-size: 14px;
  font-weight: 400;
  padding-bottom: 16px;
  padding-left: 30px;
  display: block;
}

.categories_menu_toggle ul li.has-sub ul.categorie_sub li a:hover {
  color: #1D1678;
}

.categories_menu_toggle ul li.has-sub {
  padding-bottom: 10px;
}

.categories_menu_toggle ul li ul.categories_mega_menu > li:first-child {
  padding-left: 0;
}

.categories_menu_toggle ul li ul.categories_mega_menu > li:last-child {
  padding-right: 0;
}

.categorie_banner {
  position: absolute;
  bottom: 0;
  right: 20px;
  width: 500px;
}
@media only screen and (max-width: 767px) {
  .categorie_banner {
    display: none;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categorie_banner {
    display: none;
  }
}
.categorie_banner a img:hover {
  opacity: 0.8;
}

/*-- 2.7 Categories menu css end --*/
/*home two css here*/
.header_bottom {
  margin-bottom: 30px;
}
@media only screen and (max-width: 767px) {
  .header_bottom {
    margin-bottom: 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .header_bottom {
    margin-bottom: 0;
  }
}

.menu_two nav > ul > li > a {
  color: #242424;
}
.menu_two nav > ul > li > a::before {
  background: #242424;
}

.categories_two .categories_title {
  height: 51px;
  line-height: 51px;
  border-radius: 4px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_two .categories_title {
    height: 45px;
    line-height: 46px;
  }
}
@media only screen and (max-width: 767px) {
  .categories_two .categories_title {
    height: 43px;
    line-height: 43px;
  }
}

.middle_two {
  padding: 30px 0;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .middle_two {
    padding: 28px 0;
  }
}
@media only screen and (max-width: 767px) {
  .middle_two {
    padding: 23px 0 24px;
  }
}

/*home four css here*/
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_four {
    padding: 0;
  }
}
@media only screen and (max-width: 767px) {
  .categories_four {
    padding: 0;
  }
}
.categories_four .categories_menu_toggle {
  display: block;
  padding: 14px 0 5px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_four .categories_menu_toggle {
    display: none;
  }
}
@media only screen and (max-width: 767px) {
  .categories_four .categories_menu_toggle {
    display: none;
  }
}
.categories_four .categories_menu_toggle > ul > li > a {
  line-height: 41px;
}

/* 02. slider area css here */
@media only screen and (max-width: 767px) {
  .slider_section {
    margin-bottom: 60px;
  }
}

.single_slider {
  background-repeat: no-repeat;
  background-attachment: scroll;
  background-position: center center;
  background-size: cover;
  height: 500px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .single_slider {
    height: 420px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .single_slider {
    height: 340px;
    background-position: 55%;
  }
}
@media only screen and (max-width: 767px) {
  .single_slider {
    background-position: 10%;
    height: 300px;
  }
}

.slider_area .owl-dots {
  position: absolute;
  bottom: 20px;
  text-align: center;
  left: 50%;
  transform: translatex(-50%);
  display: block;
}
@media only screen and (max-width: 767px) {
  .slider_area .owl-dots {
    bottom: 10px;
  }
}
.slider_area .owl-dots .owl-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  display: inline-block;
  background: #a075f5;
  margin: 0 3px;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  position: relative;
}
.slider_area .owl-dots .owl-dot.active {
  -webkit-transition: 0.3s;
  transition: 0.3s;
}
.slider_area .owl-dots .owl-dot.active {
  background: #1D1678;
  width: 8px;
  height: 8px;
  border-radius: 50%;
}

@media only screen and (max-width: 767px) {
  .slider_content {
    text-align: center;
  }
}
.slider_content h1 {
  font-size: 60px;
  font-weight: 300;
  margin-bottom: 17px;
  text-transform: uppercase;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .slider_content h1 {
    font-size: 40px;
    line-height: 40px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .slider_content h1 {
    font-size: 35px;
  }
}
@media only screen and (max-width: 767px) {
  .slider_content h1 {
    font-size: 26px;
    margin-bottom: 8px;
  }
}
.slider_content h2 {
  font-size: 60px;
  line-height: 55px;
  font-weight: 400;
  text-transform: uppercase;
  margin-bottom: 0;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .slider_content h2 {
    font-size: 40px;
    line-height: 40px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .slider_content h2 {
    font-size: 35px;
  }
}
@media only screen and (max-width: 767px) {
  .slider_content h2 {
    font-size: 26px;
  }
}
.slider_content p {
  font-size: 18px;
  line-height: 25px;
  text-transform: capitalize;
  margin-top: 19px;
  margin-bottom: 0;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .slider_content p {
    font-size: 16px;
    margin-top: 12px;
  }
}
@media only screen and (max-width: 767px) {
  .slider_content p {
    font-size: 16px;
    margin-top: 15px;
  }
}
.slider_content p span {
  color: #1D1678;
}
.slider_content a {
  font-size: 13px;
  font-weight: 600;
  margin-top: 40px;
  color: #fff;
  height: 50px;
  line-height: 50px;
  padding: 0 35px;
  display: inline-block;
  border-radius: 0px;
}
.slider_content a:hover {
  background: #fa5252;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .slider_content a {
    margin-top: 26px;
    height: 45px;
    line-height: 45px;
    padding: 0 25px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .slider_content a {
    margin-top: 20px;
    height: 38px;
    line-height: 38px;
    padding: 0 18px;
  }
}
@media only screen and (max-width: 767px) {
  .slider_content a {
    margin-top: 17px;
    height: 35px;
    line-height: 35px;
    padding: 0 15px;
    font-size: 12px;
  }
}

.active .slider_content h1, .active .slider_content h2, .active .slider_content p, .active .slider_content a {
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-name: fadeInLeft;
  animation-name: fadeInLeft;
  -webkit-animation-delay: 0.3s;
  animation-delay: 0.3s;
}

.active .slider_content h2 {
  -webkit-animation-delay: 0.5s;
  animation-delay: 0.5s;
}

.active .slider_content p {
  -webkit-animation-delay: 0.7s;
  animation-delay: 0.7s;
}

.active .slider_content a {
  -webkit-animation-delay: 0.9s;
  animation-delay: 0.9s;
}

/*home two css here*/
@media only screen and (max-width: 767px) {
  .slider_section_two {
    margin-bottom: 55px;
  }
}

/*homr three css here*/
@media only screen and (max-width: 767px) {
  .slider_section_three {
    margin-bottom: 60px;
  }
}

/*home four css here*/
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .slider_section_four {
    margin-top: 0;
  }
}
@media only screen and (max-width: 767px) {
  .slider_section_four {
    margin-top: 0;
    margin-bottom: 57px;
  }
}
.slider_section_four .single_slider {
  height: 410px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .slider_section_four .single_slider {
    height: 340px;
  }
}
@media only screen and (max-width: 767px) {
  .slider_section_four .single_slider {
    height: 300px;
  }
}
.slider_section_four .slider_area .owl-dots {
  left: 6%;
}
@media only screen and (max-width: 767px) {
  .slider_section_four .slider_area .owl-dots {
    left: 50%;
  }
}

.slider_c_four {
  padding-left: 50px;
}
@media only screen and (min-width: 1200px) and (max-width: 1600px) {
  .slider_c_four {
    padding-left: 40px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .slider_c_four {
    padding-left: 30px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .slider_c_four {
    padding-left: 30px;
  }
}
@media only screen and (max-width: 767px) {
  .slider_c_four {
    padding-left: 0;
    width: 100%;
  }
}
.slider_c_four h1 {
  font-size: 36px;
  line-height: 38px;
  text-transform: capitalize;
  font-weight: 400;
}
@media only screen and (min-width: 1200px) and (max-width: 1600px) {
  .slider_c_four h1 {
    font-size: 33px;
    line-height: 33px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .slider_c_four h1 {
    font-size: 28px;
    line-height: 30px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .slider_c_four h1 {
    font-size: 28px;
    line-height: 30px;
  }
}
@media only screen and (max-width: 767px) {
  .slider_c_four h1 {
    font-size: 25px;
    line-height: 25px;
  }
}
.slider_c_four h2 {
  font-size: 36px;
  line-height: 38px;
  text-transform: capitalize;
  font-weight: 400;
}
@media only screen and (min-width: 1200px) and (max-width: 1600px) {
  .slider_c_four h2 {
    font-size: 33px;
    line-height: 35px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .slider_c_four h2 {
    font-size: 28px;
    line-height: 30px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .slider_c_four h2 {
    font-size: 28px;
    line-height: 30px;
  }
}
@media only screen and (max-width: 767px) {
  .slider_c_four h2 {
    font-size: 25px;
    line-height: 25px;
  }
}

/*  04. banner section css here  */
@media only screen and (max-width: 767px) {
  .banner_area {
    margin-bottom: 25px;
  }
}

.banner_thumb {
  position: relative;
  overflow: hidden;
}
.banner_thumb:hover img {
  transform: scale(1.02);
}
@media only screen and (max-width: 767px) {
  .banner_thumb a {
    width: 100%;
  }
}
.banner_thumb a img {
  -webkit-transition: 0.3s;
  transition: 0.3s;
}
@media only screen and (max-width: 767px) {
  .banner_thumb a img {
    width: 100%;
  }
}

/*home two css here*/
@media only screen and (max-width: 767px) {
  .banner_two {
    margin-bottom: 30px;
  }
}

@media only screen and (max-width: 767px) {
  .banner_area.mb-70 {
    margin-bottom: 56px;
  }
}

/* 03. product section css here */
.tab-content > .tab-pane.active {
  display: block;
  height: auto;
  opacity: 1;
  overflow: visible;
}

.tab-content > .tab-pane {
  display: block;
  height: 0;
  opacity: 0;
  overflow: hidden;
}

.section_title {
  margin-bottom: 20px;
  padding-bottom: 14px;
  border-bottom: 1px solid #ebebeb;
  position: relative;
}
.section_title:before {
  position: absolute;
  content: "";
  height: 2px;
  width: 50px;
  bottom: -1px;
  background: #1D1678;
}
@media only screen and (max-width: 767px) {
  .section_title {
    margin-bottom: 20px;
    padding-bottom: 10px;
  }
}
.section_title h2 {
  font-size: 20px;
  line-height: 17px;
  font-weight: 600;
  display: inline-block;
  margin-bottom: 0;
  position: relative;
  text-transform: capitalize;
}
@media only screen and (max-width: 767px) {
  .section_title h2 {
    font-size: 18px;
    line-height: 17px;
  }
}

@media only screen and (max-width: 767px) {
  .product_area {
    margin-bottom: 32px;
  }
}

.product_thumb {
  position: relative;
}
.product_thumb a.secondary_img {
  position: absolute;
  top: 0;
  left: 0;
  opacity: 0;
  visibility: hidden;
}

.product_carousel:hover .owl-nav div {
  opacity: 1;
  visibility: visible;
}
.product_carousel .owl-nav div {
  opacity: 0;
  visibility: hidden;
  position: absolute;
  top: 50%;
  transform: translatey(-50%);
  left: -35px;
  font-size: 40px;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  color: #b0b0b0;
}
@media only screen and (min-width: 1200px) and (max-width: 1300px) {
  .product_carousel .owl-nav div {
    left: 0;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_carousel .owl-nav div {
    left: 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_carousel .owl-nav div {
    left: 0;
  }
}
@media only screen and (max-width: 767px) {
  .product_carousel .owl-nav div {
    left: 0;
  }
}
.product_carousel .owl-nav div:hover {
  color: #1D1678;
}
.product_carousel .owl-nav div.owl-next {
  right: -35px;
  left: auto;
}
@media only screen and (min-width: 1200px) and (max-width: 1300px) {
  .product_carousel .owl-nav div.owl-next {
    right: 0;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_carousel .owl-nav div.owl-next {
    right: 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_carousel .owl-nav div.owl-next {
    right: 0;
  }
}
@media only screen and (max-width: 767px) {
  .product_carousel .owl-nav div.owl-next {
    right: 0;
  }
}

.label_product {
  position: absolute;
  top: 10px;
  right: 10px;
}
.label_product span.label_sale {
	text-transform: capitalize;
    color: #ffffff;
    background: #fb5252;
    font-size: 12px;
    text-align: center;
    display: block;
    padding: 0px 10px;
    letter-spacing: 1px;
}

.single_product {
  padding: 15px;
  border-radius: 3px;
  background: #e8e8e8cc;
}
.single_product:hover {
  border-color: #ebebeb;
}
.single_product:hover .product_thumb a.secondary_img {
  opacity: 1;
  visibility: visible;
}
.single_product:hover .action_links {
  opacity: 1;
  visibility: visible;
}
.single_product:hover .add_to_cart {
  opacity: 1;
  visibility: visible;
}

.product_content {
  margin-top: 16px;
  text-align: center;
}
.product_content h3 {
  font-size: 14px;
  line-height: 19px;
  margin-bottom: 0;
}
.product_content h3 a:hover {
  color: #1D1678;
}

.action_links {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  opacity: 0;
  visibility: hidden;
  width: 100%;
  text-align: center;
}
.action_links ul li {
  margin-right: 3px;
  display: inline-block;
}
.action_links ul li:last-child {
  margin-bottom: 0;
}
.action_links ul li a {
  line-height: 32px;
  width: 32px;
  height: 32px;
  text-align: center;
  font-size: 14px;
  background: #fb5252;
  color: #ffffff;
  display: block;
  transition: all 0.5s ease;
  border-radius: 50%;
}
.action_links ul li a:hover {
  background: #fb5252;
}

.add_to_cart {
  opacity: 0;
  visibility: hidden;
  position: absolute;
  bottom: 20px;
  left: 0;
  right: 0;
  text-align: center;
  transition: all 0.5s ease;
}
.add_to_cart a {
  line-height: 16px;
  text-align: center;
  font-size: 12px;
  padding: 10px 30px;
  text-transform: uppercase;
  font-weight: 600;
  display: inline-block;
  transition: all 0.5s ease;
  background: #1D1678;
  color: #ffffff;
  border-radius: 0px;
}
.add_to_cart a:hover {
  background: #fb5252;
}
@media only screen and (max-width: 767px) {
  .add_to_cart a {
    font-size: 12px;
    padding: 10px 30px;
    line-height: 15px;
  }
}

.price_box {
  margin-bottom: 13px;
}
.price_box span.old_price {
  text-decoration: line-through;
  font-weight: 400;
  font-size: 14px;
  margin-right: 5px;
}
.price_box span.current_price {
  color: #1D1678;
  font-weight: 600;
  font-size: 16px;
}
@media only screen and (max-width: 767px) {
  .price_box span.current_price {
    font-size: 14px;
  }
}

.product_timing {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
}

.countdown_area {
  display: flex;
  justify-content: space-between;
  background: #F95252;
  padding: 15px 40px;
}
@media only screen and (max-width: 767px) {
  .countdown_area {
    padding: 6px 10px;
  }
}

.countdown_number {
  color: #ffffff;
  font-size: 18px;
  font-weight: 600;
  line-height: 17px;
}
@media only screen and (max-width: 767px) {
  .countdown_number {
    font-size: 14px;
    line-height: 15px;
  }
}

.countdown_title {
  text-transform: uppercase;
  font-size: 12px;
  color: #ffffff;
  line-height: 17px;
}
@media only screen and (max-width: 767px) {
  .countdown_title {
    font-size: 9px;
    line-height: 16px;
  }
}

/*top category css here*/
@media only screen and (max-width: 767px) {
  .top_category_product {
    margin-bottom: 58px;
  }
}

.top_category_container .col-lg-2 {
  flex: 0 0 100%;
  max-width: 100%;
}

@media only screen and (max-width: 767px) {
  .top_category_header {
    text-align: center;
    margin-bottom: 30px;
  }
}
.top_category_header h3 {
  font-size: 20px;
  line-height: 24px;
  font-weight: 600;
  text-transform: capitalize;
  letter-spacing: -1px;
  margin-bottom: 15px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .top_category_header h3 {
    font-size: 16px;
    margin-bottom: 10px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .top_category_header h3 {
    font-size: 16px;
    line-height: 22px;
    margin-bottom: 10px;
  }
}
@media only screen and (max-width: 767px) {
  .top_category_header h3 {
    font-size: 16px;
    line-height: 22px;
    margin-bottom: 10px;
  }
}
.top_category_header p {
  font-size: 14px;
  line-height: 25px;
  letter-spacing: -0.5px;
  margin-bottom: 0;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .top_category_header p {
    line-height: 23px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .top_category_header p {
    font-size: 12px;
    line-height: 23px;
  }
}
@media only screen and (max-width: 767px) {
  .top_category_header p {
    font-size: 13px;
    line-height: 23px;
  }
}
.top_category_header a {
  color: #ffffff;
  background: #1D1678;
  text-transform: capitalize;
  display: inline-block;
  padding: 10px 15px;
  border-radius: 4px;
  margin-top: 28px;
}
.top_category_header a:hover {
  background: #242424;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .top_category_header a {
    padding: 7px 4px;
    margin-top: 20px;
    font-size: 13px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .top_category_header a {
    margin-top: 12px;
    font-size: 13px;
    padding: 7px 10px;
  }
}
@media only screen and (max-width: 767px) {
  .top_category_header a {
    margin-top: 12px;
    font-size: 13px;
    padding: 7px 10px;
  }
}

.single_category {
  padding: 20px 15px;
  background: #ffffff;
  border: 1px solid #ebebeb;
  position: relative;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  border-radius: 4px;
}
.single_category:hover {
  border-color: #1D1678;
}
.single_category:hover::before {
  border-color: #1D1678;
}
.single_category::before {
  border: 1px solid transparent;
  border-top-color: transparent;
  border-right-color: transparent;
  border-bottom-color: transparent;
  border-left-color: transparent;
  bottom: 0;
  content: '';
  display: block;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
  z-index: 2;
  -webkit-transition: 0.3s;
  transition: 0.3s;
}

.category_thumb {
  position: relative;
  z-index: 5;
}

.category_name {
  text-align: center;
  margin-top: 5px;
  position: relative;
  z-index: 5;
}
.category_name h3 {
  font-size: 14px;
  line-height: 18px;
  font-weight: 600;
  margin-bottom: 0;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .category_name h3 {
    font-size: 12px;
  }
}
@media only screen and (max-width: 767px) {
  .category_name h3 {
    font-size: 12px;
  }
}
.category_name h3 a:hover {
  color: #1D1678;
}

/*featured product css here*/
.featured_product_area {
  background: #f8f8f8;
  padding: 70px 0 35px;
}
@media only screen and (max-width: 767px) {
  .featured_product_area {
    padding: 56px 0 25px;
    margin-bottom: 57px;
  }
}

.featured_container .col-lg-4 {
  flex: 0 0 100%;
  max-width: 100%;
}
.featured_container .single_product {
  overflow: hidden;
  margin-bottom: 30px;
  padding: 0;
  border: 1px solid transparent;
}
.featured_container .single_product:hover {
  border-color: #ebebeb;
}
.featured_container .product_thumb {
  width: 48%;
  padding-right: 15px;
  float: left;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .featured_container .product_thumb {
    width: 42%;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .featured_container .product_thumb {
    width: 42%;
  }
}
.featured_container .product_content {
  float: left;
  padding: 15px;
  width: 52%;
  margin-top: 0;
  text-align: left;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .featured_container .product_content {
    width: 56%;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .featured_container .product_content {
    width: 56%;
  }
}
.featured_container .price_box {
  margin-bottom: 11px;
}
.featured_container .add_to_cart {
  position: inherit;
  margin-top: 15px;
}
.featured_container .add_to_cart a {
  display: block;
  padding: 9px 15px;
}
.featured_container:hover button {
  opacity: 1;
  visibility: visible;
}
.featured_container button {
  opacity: 0;
  visibility: hidden;
  position: absolute;
  top: 50%;
  transform: translatey(-50%);
  left: -35px;
  font-size: 40px;
  border: 0;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  color: #b0b0b0;
  background: inherit;
  z-index: 9;
}
@media only screen and (min-width: 1200px) and (max-width: 1300px) {
  .featured_container button {
    left: 0;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .featured_container button {
    left: 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .featured_container button {
    left: 0;
  }
}
@media only screen and (max-width: 767px) {
  .featured_container button {
    left: 0;
  }
}
.featured_container button:hover {
  color: #1D1678;
}
.featured_container button.next_arrow {
  right: -35px;
  left: auto;
}
@media only screen and (min-width: 1200px) and (max-width: 1300px) {
  .featured_container button.next_arrow {
    right: 0;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .featured_container button.next_arrow {
    right: 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .featured_container button.next_arrow {
    right: 0;
  }
}
@media only screen and (max-width: 767px) {
  .featured_container button.next_arrow {
    right: 0;
  }
}

/*featured product css end*/
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_left_area {
    margin-bottom: 42px;
  }
}
@media only screen and (max-width: 767px) {
  .product_left_area {
    margin-bottom: 30px;
  }
}

/*home two css here*/
.product_slick:hover button {
  opacity: 1;
  visibility: visible;
}
.product_slick button {
  opacity: 0;
  visibility: hidden;
  position: absolute;
  top: 50%;
  transform: translatey(-50%);
  left: -35px;
  font-size: 40px;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  color: #b0b0b0;
  border: 0;
  background: inherit;
  z-index: 9;
}
@media only screen and (min-width: 1200px) and (max-width: 1300px) {
  .product_slick button {
    left: 0;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_slick button {
    left: 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_slick button {
    left: 0;
  }
}
@media only screen and (max-width: 767px) {
  .product_slick button {
    left: 0;
  }
}
.product_slick button:hover {
  color: #1D1678;
}
.product_slick button.next_arrow {
  right: -35px;
  left: auto;
}
@media only screen and (min-width: 1200px) and (max-width: 1300px) {
  .product_slick button.next_arrow {
    right: 0;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_slick button.next_arrow {
    right: 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_slick button.next_arrow {
    right: 0;
  }
}
@media only screen and (max-width: 767px) {
  .product_slick button.next_arrow {
    right: 0;
  }
}

/*custom product area css here*/
.custom_product_area {
  margin-bottom: 17px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .custom_product_area {
    margin-bottom: 24px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .custom_product_area {
    margin-bottom: 3px;
  }
}
@media only screen and (max-width: 767px) {
  .custom_product_area {
    margin-bottom: 2px;
  }
}

.small_product_container .single_product {
  margin-bottom: 30px;
  overflow: hidden;
  padding: 0;
  border: 0;
}
.small_product_container .single_product .product_content {
  width: 73%;
  padding-left: 18px;
  margin-top: 0;
  float: left;
  text-align: left;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .small_product_container .single_product .product_content {
    width: 77%;
  }
}
.small_product_container .single_product .product_content h3 {
  margin-bottom: 12px;
}
.small_product_container .single_product .product_thumb {
  width: 27%;
  float: left;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .small_product_container .single_product .product_thumb {
    width: 23%;
  }
}
.small_product_container .price_box {
  margin-bottom: 10px;
}
.small_product_container button {
  position: absolute;
  top: -60px;
  right: 24px;
  border: 0;
  background: inherit;
  font-size: 23px;
  color: #b0b0b0;
}
@media only screen and (max-width: 767px) {
  .small_product_container button {
    top: -56px;
  }
}
.small_product_container button:hover {
  color: #1D1678;
}
.small_product_container button.next_arrow {
  right: 0;
}

@media only screen and (min-width: 768px) and (max-width: 991px) {
  .small_product_area {
    margin-bottom: 21px;
  }
}
@media only screen and (max-width: 767px) {
  .small_product_area {
    margin-bottom: 11px;
  }
}

.product_ratings {
  margin-bottom: 5px;
}
.product_ratings ul {
  display: flex;
}
.product_ratings ul li {
  line-height: 18px;
  margin-right: 3px;
}
.product_ratings ul li:last-child {
  margin-right: 0;
}
.product_ratings ul li a {
  color: #1D1678;
  font-size: 21px;
}

.tab_btn_container {
  margin-bottom: 30px;
  padding-bottom: 14px;
  border-bottom: 1px solid #ebebeb;
  display: flex;
  justify-content: space-between;
}
.tab_btn_container .section_title {
  margin-bottom: 0;
  padding-bottom: 0;
  border-bottom: 0;
}
@media only screen and (max-width: 767px) {
  .tab_btn_container .section_title h2 {
    margin-bottom: 13px;
  }
}
@media only screen and (max-width: 767px) {
  .tab_btn_container {
    flex-direction: column;
  }
}

.product_tab_btn ul li {
  margin-right: 18px;
}
.product_tab_btn ul li:last-child {
  margin-right: 0;
}
.product_tab_btn ul li a {
  line-height: 25px;
}
.product_tab_btn ul li a:hover {
  color: #1D1678;
}
.product_tab_btn ul li a.active {
  color: #1D1678;
}
@media only screen and (max-width: 767px) {
  .product_tab_btn ul li a {
    line-height: 30px;
  }
}

/*home three css here*/
.product_tab_btn3 {
  border-bottom: 1px solid #ebebeb;
  margin-bottom: 20px;
}
@media only screen and (max-width: 479px) {
  .product_tab_btn3 {
    padding-bottom: 5px;
  }
}
.product_tab_btn3 ul li {
  position: relative;
  margin: 0 25px 10px 0;
  padding-right: 25px;
}
@media only screen and (max-width: 767px) {
  .product_tab_btn3 ul li {
    margin: 0 19px 10px 0;
    padding-right: 0;
  }
  .product_tab_btn3 ul li::before {
    display: none;
  }
}
.product_tab_btn3 ul li::before {
  position: absolute;
  content: "";
  background: #ebebeb;
  width: 1px;
  height: 21px;
  right: 0;
  top: 50%;
  transform: translatey(-50%);
}
.product_tab_btn3 ul li:last-child {
  margin-right: 0;
  padding-right: 0;
}
.product_tab_btn3 ul li:last-child::before {
  display: none;
}
.product_tab_btn3 ul li a {
  font-size: 20px;
  line-height: 30px;
  font-weight: 600;
  text-transform: capitalize;
  color: #555;
}
@media only screen and (max-width: 767px) {
  .product_tab_btn3 ul li a {
    font-size: 16px;
    line-height: 25px;
  }
}
.product_tab_btn3 ul li a:hover {
  color: #242424;
}
.product_tab_btn3 ul li a.active {
  color: #242424;
}

.product_deals_three {
  background: #f8f8f8;
  padding: 70px 0;
}
@media only screen and (max-width: 767px) {
  .product_deals_three {
    padding: 56px 0 60px;
    margin-bottom: 56px;
  }
}

@media only screen and (min-width: 768px) and (max-width: 991px) {
  .deals_title_three {
    margin-bottom: 25px;
  }
}
@media only screen and (max-width: 767px) {
  .deals_title_three {
    text-align: center;
    margin-bottom: 24px;
  }
}
.deals_title_three h2 {
  font-size: 20px;
  line-height: 24px;
  text-transform: capitalize;
  font-weight: 600;
  margin-bottom: 20px;
  letter-spacing: -1px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .deals_title_three h2 {
    font-size: 15px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .deals_title_three h2 {
    margin-bottom: 10px;
  }
}
@media only screen and (max-width: 767px) {
  .deals_title_three h2 {
    font-size: 19px;
    margin-bottom: 10px;
  }
}
.deals_title_three p {
  line-height: 25px;
  letter-spacing: -0.5px;
}

.product_deals_column4 .col-lg-3 {
  flex: 0 0 100%;
  max-width: 100%;
}
.product_deals_column4 .owl-nav div {
  font-size: 15px;
  font-weight: 400;
  left: -19%;
  bottom: -10px;
  top: auto;
  opacity: inherit;
  visibility: inherit;
  background: #eee;
  border: 1px solid #ebebeb;
  padding: 5px 10px;
  min-width: 80px;
  border-radius: 4px;
  text-align: center;
  color: #242424;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_deals_column4 .owl-nav div {
    min-width: 63px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_deals_column4 .owl-nav div {
    right: 98px;
    left: auto;
    top: -64px;
    bottom: auto;
    min-width: 70px;
  }
}
@media only screen and (max-width: 767px) {
  .product_deals_column4 .owl-nav div {
    display: none;
  }
}
.product_deals_column4 .owl-nav div:hover {
  background: #1D1678;
  border-color: #1D1678;
  color: #ffffff;
}
.product_deals_column4 .owl-nav div.owl-next {
  left: -10%;
  right: auto;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_deals_column4 .owl-nav div.owl-next {
    right: 17px;
    left: auto;
  }
}

/*home four css here*/
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .home_section_four .section_title h2 {
    font-size: 17px;
    line-height: 17px;
  }
}

.deals_product_four {
  margin-bottom: 43px;
}
@media only screen and (max-width: 767px) {
  .deals_product_four {
    margin-bottom: 27px;
  }
}
.deals_product_four .owl-nav div {
  right: 25px;
  left: auto;
  top: -50px;
  opacity: inherit;
  visibility: inherit;
  font-size: 26px;
}
@media only screen and (max-width: 767px) {
  .deals_product_four .owl-nav div {
    top: -43px;
  }
}
.deals_product_four .owl-nav div.owl-next {
  right: 0;
}

.product_four_area button {
  right: 25px;
  left: auto;
  top: -50px;
  opacity: inherit;
  visibility: inherit;
  font-size: 26px;
}
@media only screen and (max-width: 767px) {
  .product_four_area button {
    top: -44px;
  }
}
.product_four_area button.next_arrow {
  right: 0;
}

.product_four_bottom {
  margin-bottom: 40px;
}
@media only screen and (max-width: 767px) {
  .product_four_bottom {
    margin-bottom: 34px;
  }
}
.product_four_bottom .owl-nav div {
  right: 25px;
  left: auto;
  top: -50px;
  opacity: inherit;
  visibility: inherit;
  font-size: 26px;
}
@media only screen and (max-width: 767px) {
  .product_four_bottom .owl-nav div {
    top: -45px;
  }
}
.product_four_bottom .owl-nav div.owl-next {
  right: 0;
}

.small_product_four {
  margin-bottom: 20px;
}
@media only screen and (max-width: 767px) {
  .small_product_four {
    margin-bottom: 9px;
  }
}

/* 05. blog area css here */
.blog_section {
  background: #f8f8f8;
  padding: 70px 0;
}
@media only screen and (max-width: 767px) {
  .blog_section {
    padding: 57px 0 58px;
    margin-bottom: 30px;
  }
}

.blog_carousel:hover .owl-nav div {
  opacity: 1;
  visibility: visible;
}
.blog_carousel .owl-nav div {
  opacity: 0;
  visibility: hidden;
  position: absolute;
  top: 50%;
  transform: translatey(-50%);
  left: -25px;
  font-size: 40px;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  color: #b0b0b0;
}
@media only screen and (min-width: 1200px) and (max-width: 1300px) {
  .blog_carousel .owl-nav div {
    left: 0;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .blog_carousel .owl-nav div {
    left: 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_carousel .owl-nav div {
    left: 0;
  }
}
@media only screen and (max-width: 767px) {
  .blog_carousel .owl-nav div {
    left: 0;
  }
}
.blog_carousel .owl-nav div:hover {
  color: #1D1678;
}
.blog_carousel .owl-nav div.owl-next {
  right: -25px;
  left: auto;
}
@media only screen and (min-width: 1200px) and (max-width: 1300px) {
  .blog_carousel .owl-nav div.owl-next {
    right: 0;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .blog_carousel .owl-nav div.owl-next {
    right: 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_carousel .owl-nav div.owl-next {
    right: 0;
  }
}
@media only screen and (max-width: 767px) {
  .blog_carousel .owl-nav div.owl-next {
    right: 0;
  }
}
.blog_carousel .col-lg-3 {
  flex: 0 0 100%;
  max-width: 100%;
}

.blog_content {
  padding-top: 20px;
  text-align: center;
}
.blog_content p {
  font-size: 13px;
  line-height: 23px;
  margin-bottom: 10px;
}
.blog_content p a {
  color: #1D1678;
}
.blog_content p a:hover {
  text-decoration: underline;
}
.blog_content h3 {
  font-size: 16px;
  text-transform: capitalize;
  line-height: 21px;
  margin-bottom: 0;
  font-weight: 600;
}
.blog_content h3 a:hover {
  color: #1D1678;
}

/*home four css here*/
.blog_section_four {
  background: inherit;
  padding: 0;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_section_four {
    margin-bottom: 62px;
  }
}
@media only screen and (max-width: 767px) {
  .blog_section_four {
    margin-bottom: 52px;
  }
}
.blog_section_four .blog_content {
  text-align: left;
}
.blog_section_four .blog_content p.post_desc {
  font-size: 14px;
  line-height: 25px;
  margin-bottom: 0;
  margin-top: 14px;
}
.blog_section_four .owl-nav div {
  right: 25px;
  left: auto;
  top: -50px;
  opacity: inherit;
  visibility: inherit;
  font-size: 26px;
}
@media only screen and (max-width: 767px) {
  .blog_section_four .owl-nav div {
    top: -42px;
  }
}
.blog_section_four .owl-nav div.owl-next {
  right: 0;
}

/*06. newsletter area css here*/
.newletter_area {
  padding: 40px 0;
  border-top: 1px solid #ebebeb;
}

.newletter_title {
  display: flex;
  align-items: center;
}
@media only screen and (max-width: 767px) {
  .newletter_title {
    margin-bottom: 25px;
  }
}
.newletter_title img {
  margin-right: 20px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .newletter_title img {
    margin-right: 10px;
  }
}

.newletter_content h2 {
  font-weight: 600;
  display: inline-block;
  font-size: 24px;
  line-height: 24px;
  margin: 0;
  text-transform: capitalize;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .newletter_content h2 {
    font-size: 17px;
  }
}
@media only screen and (max-width: 767px) {
  .newletter_content h2 {
    font-size: 18px;
  }
}
.newletter_content p {
  font-size: 14px;
  margin: 13px 0 0;
  line-height: 14px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .newletter_content p {
    font-size: 13px;
    margin: 10px 0 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .newletter_content p {
    font-size: 13px;
    margin: 5px 0 0;
  }
}
@media only screen and (max-width: 767px) {
  .newletter_content p {
    font-size: 13px;
    margin: 5px 0 0;
  }
}

.newletter_subscribe form {
  position: relative;
  width: 550px;
  background: #fff;
  border: 1px solid #ebebeb;
  border-radius: 30px;
  float: right;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .newletter_subscribe form {
    width: 100%;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .newletter_subscribe form {
    width: 100%;
  }
}
@media only screen and (max-width: 767px) {
  .newletter_subscribe form {
    width: 100%;
  }
}
.newletter_subscribe form input::-webkit-input-placeholder {
  /* Chrome/Opera/Safari */
  color: #a5a5a5;
}
.newletter_subscribe form input::-moz-placeholder {
  /* Firefox 19+ */
  color: #a5a5a5;
}
.newletter_subscribe form input:-ms-input-placeholder {
  /* IE 10+ */
  color: #a5a5a5;
}
.newletter_subscribe form input:-moz-placeholder {
  /* Firefox 18- */
  color: #a5a5a5;
}
.newletter_subscribe form input {
  width: 100%;
  border: 0;
  background: none;
  padding: 0 150px 0 20px;
  height: 50px;
  font-size: 14px;
  color: #a5a5a5;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .newletter_subscribe form input {
    padding: 0 125px 0 20px;
  }
}
@media only screen and (max-width: 767px) {
  .newletter_subscribe form input {
    padding: 0 110px 0 20px;
    height: 40px;
  }
}
.newletter_subscribe form button {
  position: absolute;
  top: 0;
  right: 0;
  border: 0;
  height: 100%;
  padding: 0 35px;
  background: #1D1678;
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  border-radius: 0 30px 30px 0;
  -webkit-transition: 0.3s;
  transition: 0.3s;
}
.newletter_subscribe form button:hover {
  background: #2777d0;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .newletter_subscribe form button {
    font-size: 13px;
    padding: 0 25px;
  }
}
@media only screen and (max-width: 767px) {
  .newletter_subscribe form button {
    padding: 0 15px;
  }
}

/*home two css here*/
.newletter_two {
  border-top: 1px solid #363636;
}
.newletter_two .newletter_content h2 {
  color: #fff;
}
.newletter_two .newletter_content p {
  color: #888888;
}
.newletter_two .newletter_subscribe form {
  background: #252525;
  border: 1px solid #363636;
}

/*home three css here*/
.newletter_three .newletter_subscribe form button {
  background: #1953b4;
}
.newletter_three .newletter_subscribe form button:hover {
  background: #242424;
}

/* 21. shipping css here */
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .shipping_area {
    margin-bottom: 43px;
  }
}
@media only screen and (max-width: 767px) {
  .shipping_area {
    margin-bottom: 28px;
  }
}

.single_shipping {
  display: flex;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .single_shipping {
    margin-bottom: 25px;
  }
}
@media only screen and (max-width: 767px) {
  .single_shipping {
    margin-bottom: 28px;
  }
}

.shipping_icone {
  margin-right: 20px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .shipping_icone {
    margin-right: 12px;
  }
}

.shipping_content h2 {
  font-size: 14px;
  line-height: 20px;
  text-transform: capitalize;
  font-weight: 700;
  margin-bottom: 4px;
}
.shipping_content p {
  font-size: 13px;
  line-height: 18px;
}

/*home two css here*/
.shipping_two {
  margin-bottom: 48px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .shipping_two {
    margin-bottom: 20px;
  }
}
@media only screen and (max-width: 767px) {
  .shipping_two {
    margin-bottom: 20px;
  }
}

/*home four css here*/
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .shipping_four {
    margin-bottom: 70px;
  }
}
@media only screen and (max-width: 767px) {
  .shipping_four {
    margin-bottom: 60px;
  }
}

.shipping_inner {
  border: 1px solid #ebebeb;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .shipping_inner {
    padding: 11px 0 15px;
  }
}
@media only screen and (max-width: 767px) {
  .shipping_inner {
    padding: 11px 0 15px;
  }
}
.shipping_inner .single_shipping {
  padding: 25px 25px 20px 25px;
  border-right: 1px solid #ebebeb;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .shipping_inner .single_shipping {
    padding: 22px 5px 19px 8px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .shipping_inner .single_shipping {
    border-right: 0;
    margin-bottom: 0;
    padding: 18px 25px 13px 25px;
  }
}
@media only screen and (max-width: 767px) {
  .shipping_inner .single_shipping {
    border-right: 0;
    margin-bottom: 0;
    padding: 18px 25px 13px 25px;
  }
}
.shipping_inner .single_shipping.last_child {
  border: 0;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .shipping_inner .shipping_icone {
    margin-right: 12px;
  }
}

/*testimonial css here*/
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .testimonial_are {
    margin-bottom: 18px;
  }
}
@media only screen and (max-width: 767px) {
  .testimonial_are {
    margin-bottom: 21px;
  }
}

.testimonial_active .testimonial_thumb a img {
  width: inherit;
  display: inline-block;
  border-radius: 50%;
}
.testimonial_active .owl-dots {
  margin-top: 22px;
  text-align: center;
}
.testimonial_active .owl-dots .owl-dot {
  width: 10px;
  height: 10px;
  background: #ebebeb;
  border-radius: 50%;
  display: inline-block;
  margin: 0 3px;
  -webkit-transition: 0.3s;
  transition: 0.3s;
}
.testimonial_active .owl-dots .owl-dot.active {
  background: #1D1678;
}
.testimonial_active .owl-dots .owl-dot:hover {
  background: #1D1678;
}

.testimonial_thumb {
  text-align: center;
}
.testimonial_thumb a {
  border: 10px solid #edf4fc;
  display: inline-block;
  height: 90px;
  margin: 10px 0;
  position: relative;
  vertical-align: middle;
  width: 90px;
  -webkit-border-radius: 100%;
  -moz-border-radius: 100%;
  border-radius: 100%;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .testimonial_thumb a {
    margin: 5px 0;
  }
}
.testimonial_thumb a::before {
  border: 10px solid #fafcfe;
  bottom: -20px;
  content: '';
  left: -20px;
  pointer-events: none;
  position: absolute;
  right: -20px;
  top: -20px;
  -webkit-border-radius: 100%;
  -moz-border-radius: 100%;
  border-radius: 100%;
}

.testimonial_content {
  text-align: center;
}
.testimonial_content p {
  margin: 15px 0;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .testimonial_content p {
    margin: 5px 0;
    margin: 7px 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .testimonial_content p {
    padding: 0 66px;
  }
}
.testimonial_content h3 {
  font-size: 14px;
  line-height: 21px;
  text-transform: capitalize;
  margin-bottom: 0;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .testimonial_content h3 {
    font-size: 13px;
  }
}
.testimonial_content h3 a {
  color: #1D1678;
  font-weight: 600;
  margin-right: 10px;
}

/*brand css here*/
@media only screen and (max-width: 767px) {
  .brand_area {
    margin-bottom: 60px;
  }
}
@media only screen and (max-width: 479px) {
  .brand_area {
    margin-bottom: 34px;
  }
}

.brand_container .single_brand img {
  width: inherit;
  margin: 0 auto;
}
.brand_container .owl-item.last .brand_items {
  border-right: 0;
}
.brand_container:hover .owl-nav div {
  opacity: 1;
  visibility: visible;
}
.brand_container .owl-nav div {
  opacity: 0;
  visibility: hidden;
  position: absolute;
  top: 50%;
  transform: translatey(-50%);
  left: -35px;
  font-size: 40px;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  color: #b0b0b0;
}
@media only screen and (min-width: 1200px) and (max-width: 1300px) {
  .brand_container .owl-nav div {
    left: 0;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .brand_container .owl-nav div {
    left: 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .brand_container .owl-nav div {
    left: 0;
  }
}
@media only screen and (max-width: 767px) {
  .brand_container .owl-nav div {
    left: 0;
  }
}
.brand_container .owl-nav div:hover {
  color: #1D1678;
}
.brand_container .owl-nav div.owl-next {
  right: -35px;
  left: auto;
}
@media only screen and (min-width: 1200px) and (max-width: 1300px) {
  .brand_container .owl-nav div.owl-next {
    right: 0;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .brand_container .owl-nav div.owl-next {
    right: 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .brand_container .owl-nav div.owl-next {
    right: 0;
  }
}
@media only screen and (max-width: 767px) {
  .brand_container .owl-nav div.owl-next {
    right: 0;
  }
}

.single_brand {
  border-bottom: 1px solid #ebebeb;
  padding: 20px 15px;
}
.single_brand:last-child {
  border-bottom: 0;
}

.brand_items {
  border-right: 1px solid #ebebeb;
}

/*home two css here*/
.brand_two {
  border-top: 1px solid #ebebeb;
}
.brand_two .brand_container {
  padding-top: 70px;
}
@media only screen and (max-width: 767px) {
  .brand_two .brand_container {
    padding-top: 60px;
  }
}
@media only screen and (max-width: 479px) {
  .brand_two .brand_container {
    padding-top: 38px;
  }
}

/*  07. footer area css here */
.footer_top {
  background: #f8f8f8;
  padding: 50px 0 43px;
  border-bottom: 1px solid #ebebeb;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .footer_top {
    padding: 50px 0 36px;
  }
}
@media only screen and (max-width: 767px) {
  .footer_top {
    padding: 50px 0 6px;
  }
}

@media only screen and (min-width: 768px) and (max-width: 991px) {
  .widgets_container {
    margin-bottom: 10px;
  }
}
@media only screen and (max-width: 767px) {
  .widgets_container {
    margin-bottom: 42px;
  }
}
.widgets_container h3 {
  font-size: 20px;
  line-height: 24px;
  margin-bottom: 18px;
  text-transform: capitalize;
  font-weight: 600;
}
@media only screen and (max-width: 767px) {
  .widgets_container h3 {
    margin-bottom: 12px;
    line-height: 22px;
    font-size: 18px;
  }
}
.widgets_container p {
  margin: 0;
}
@media only screen and (max-width: 767px) {
  .widgets_container p {
    padding: 0 34px;
  }
}
.widgets_container.widget_menu {
  padding-top: 30px;
}
@media only screen and (max-width: 767px) {
  .widgets_container.widget_menu {
    padding-top: 0;
  }
}
.widgets_container.newsletter {
  padding-top: 30px;
}
@media only screen and (max-width: 767px) {
  .widgets_container.newsletter {
    padding-top: 0;
  }
}

.footer_logo {
  margin-bottom: 18px;
}
.footer_logo a img {
  max-width: 162px;
}
@media only screen and (max-width: 767px) {
  .footer_logo a img {
    max-width: 126px;
  }
}

.footer_contact p {
  font-size: 14px;
  margin-bottom: 18px;
  line-height: 25px;
}
.footer_contact p a:hover {
  color: #1D1678;
}
.footer_contact p:last-child {
  margin-bottom: 0;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .footer_contact p {
    font-size: 13px;
    margin-bottom: 14px;
  }
}
@media only screen and (max-width: 767px) {
  .footer_contact p {
    margin-bottom: 11px;
    padding: 0;
  }
}
.footer_contact p span {
  font-size: 16px;
  color: #1D1678;
}

.footer_menu ul li {
  margin-bottom: 16px;
}
@media only screen and (max-width: 767px) {
  .footer_menu ul li {
    margin-bottom: 11px;
  }
}
.footer_menu ul li:last-child {
  margin-bottom: 0;
}
.footer_menu ul li a {
  display: block;
  font-weight: 400;
  font-size: 14px;
  line-height: 20px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .footer_menu ul li a {
    font-size: 13px;
  }
}
.footer_menu ul li a:hover {
  color: #1D1678;
}

.footer_social_link {
  margin-bottom: 50px;
}
@media only screen and (max-width: 767px) {
  .footer_social_link {
    margin-bottom: 25px;
  }
}
.footer_social_link ul li {
  display: inline-block;
  margin-right: 6px;
}
.footer_social_link ul li:last-child {
  margin-right: 0;
}
.footer_social_link ul li a {
  width: 35px;
  height: 35px;
  line-height: 35px;
  color: #ffffff;
  border-radius: 50%;
  display: block;
  text-align: center;
  font-size: 14px;
}
@media only screen and (max-width: 767px) {
  .footer_social_link ul li a {
    width: 38px;
    height: 38px;
    line-height: 38px;
    font-size: 15px;
  }
}
.footer_social_link ul li a:hover {
  opacity: 0.8;
}
.footer_social_link ul li a.facebook {
  background: #3b5998;
}
.footer_social_link ul li a.twitter {
  background: #00aced;
}
.footer_social_link ul li a.instagram {
  background: #bc2a8d;
}
.footer_social_link ul li a.linkedin {
  background: #007bb6;
}
.footer_social_link ul li a.rss {
  background: #f26522;
}

.subscribe_form form {
  position: relative;
  width: 350px;
  background: #ffffff;
  border-radius: 5px;
  border: 1px solid #ebebeb;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .subscribe_form form {
    width: 100%;
  }
}
@media only screen and (max-width: 767px) {
  .subscribe_form form {
    width: 100%;
  }
}
.subscribe_form form input {
  width: 100%;
  height: 48px;
  color: #888;
  font-size: 13px;
  background: none;
  border: 0;
  padding: 0 120px 0 15px;
}
@media only screen and (max-width: 767px) {
  .subscribe_form form input {
    padding: 0 105px 0 15px;
    height: 40px;
  }
}
.subscribe_form form button {
  position: absolute;
  right: 0;
  top: 0;
  height: 100%;
  font-size: 12px;
  color: #fff;
  background: #1D1678;
  font-weight: 600;
  padding: 0 18px;
  border: 0;
  text-transform: uppercase;
  border-top-right-radius: 5px;
  border-bottom-right-radius: 5px;
}
.subscribe_form form button:hover {
  background: #242424;
}
@media only screen and (max-width: 767px) {
  .subscribe_form form button {
    padding: 0 9px;
  }
}

.mailchimp-error {
  text-align: center;
  color: green;
}

.mailchimp-success {
  text-align: center;
  margin-top: 18px;
  color: green;
}

@media only screen and (max-width: 767px) {
  .copyright_area {
    text-align: center;
    margin-bottom: 14px;
  }
}
.copyright_area p {
  line-height: 25px;
  font-size: 14px;
}
.copyright_area p a:hover {
  text-decoration: underline;
  color: #1D1678;
}

.footer_bottom {
  padding: 30px 0;
}
@media only screen and (max-width: 767px) {
  .footer_bottom {
    padding: 20px 0;
  }
}

@media only screen and (max-width: 767px) {
  .footer_payment {
    text-align: center !important;
  }
}

/*home two css here*/
.footer_top_inner {
  padding-top: 50px;
  border-top: 1px solid #ebebeb;
}

/*collection area css here*/
.collection_area {
  margin-bottom: 94px;
}
@media only screen and (min-width: 1200px) and (max-width: 1600px) {
  .collection_area {
    margin-bottom: 74px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .collection_area {
    margin-bottom: 74px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .collection_area {
    margin-bottom: 55px;
  }
}
@media only screen and (max-width: 767px) {
  .collection_area {
    margin-bottom: 53px;
  }
}

@media only screen and (max-width: 767px) {
  .collection_img {
    margin-bottom: 21px;
  }
}
.collection_img img:hover {
  opacity: 0.7;
}

@media only screen and (max-width: 767px) {
  .collection_content {
    text-align: center;
  }
}
.collection_content h1 {
  font-size: 120px;
  font-weight: 700;
  line-height: 100px;
  margin-bottom: 20px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .collection_content h1 {
    font-size: 90px;
    line-height: 80px;
    margin-bottom: 13px;
  }
}
@media only screen and (max-width: 767px) {
  .collection_content h1 {
    font-size: 90px;
    line-height: 80px;
    margin-bottom: 13px;
  }
}
.collection_content h4 {
  font-size: 18px;
  font-weight: 600;
  text-transform: capitalize;
  margin-bottom: 23px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .collection_content h4 {
    margin-bottom: 12px;
  }
}
@media only screen and (max-width: 767px) {
  .collection_content h4 {
    margin-bottom: 12px;
  }
}
.collection_content h2 {
  font-size: 36px;
  margin-top: 0;
  margin-bottom: 20px;
  font-weight: 700;
  margin-bottom: 20px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .collection_content h2 {
    margin-bottom: 10px;
    font-size: 20px;
  }
}
@media only screen and (max-width: 767px) {
  .collection_content h2 {
    margin-bottom: 10px;
    font-size: 20px;
    line-height: 28px;
  }
}
.collection_content p {
  line-height: 24px;
  font-size: 16px;
  margin: 0;
}
@media only screen and (max-width: 767px) {
  .collection_content p {
    font-size: 15px;
  }
}
.collection_content a {
  font-size: 16px;
  font-weight: 600;
  padding-bottom: 5px;
  border-bottom: 2px solid #757575;
  display: inline-block;
  margin-top: 40px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .collection_content a {
    margin-top: 15px;
  }
}
@media only screen and (max-width: 767px) {
  .collection_content a {
    margin-top: 15px;
    font-size: 16px;
  }
}
.collection_content a:hover {
  color: #1D1678;
  border-color: #1D1678;
}

@media only screen and (max-width: 767px) {
  .collection_2 {
    margin-bottom: 29px;
  }
}
@media only screen and (max-width: 767px) {
  .collection_2 .collection_content {
    margin-bottom: 29px;
  }
}

@media only screen and (max-width: 767px) {
  .collection_4 {
    margin-bottom: 32px;
  }
}
@media only screen and (max-width: 767px) {
  .collection_4 .collection_content {
    margin-bottom: 29px;
  }
}

/*categories section css here*/
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_area {
    margin-top: 68px;
  }
}

.categories_thumb {
  position: relative;
}
@media only screen and (max-width: 767px) {
  .categories_thumb {
    height: 100vh;
  }
}
@media only screen and (max-width: 767px) {
  .categories_thumb a {
    height: 100%;
  }
}
@media only screen and (max-width: 767px) {
  .categories_thumb img {
    height: 100%;
    object-fit: cover;
  }
}

.categories_content {
  position: absolute;
  top: 50%;
  right: 50px;
  transform: translatey(-50%);
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .categories_content {
    right: 20px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_content {
    right: 30px;
  }
}
@media only screen and (max-width: 767px) {
  .categories_content {
    right: 15px;
  }
}
.categories_content h4 {
  font-size: 18px;
  margin-bottom: 15px;
}
@media only screen and (max-width: 767px) {
  .categories_content h4 {
    font-size: 16px;
    margin-bottom: 10px;
  }
}
.categories_content h2 {
  font-size: 35px;
  font-weight: 600;
  line-height: 30px;
  margin-bottom: 10px;
}
@media only screen and (max-width: 767px) {
  .categories_content h2 {
    font-size: 22px;
    margin-bottom: 10px;
  }
}
.categories_content p {
  font-size: 17px;
  width: 440px;
  font-weight: 600;
  margin-top: 30px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_content p {
    width: 310px;
  }
}
@media only screen and (max-width: 767px) {
  .categories_content p {
    font-size: 14px;
    width: 210px;
    line-height: 20px;
    margin-bottom: 5px;
    margin-top: 0;
  }
}
.categories_content a {
  text-transform: capitalize;
  font-size: 16px;
  font-weight: 600;
  padding-bottom: 5px;
  border-bottom: 2px solid #757575;
}
.categories_content a:hover {
  color: #1D1678;
  border-color: #1D1678;
}

#fp-nav {
  right: 31px;
}

.categories_area .col-12 {
  padding: 0;
}

.categories_content.content_left {
  left: 60px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .categories_content.content_left {
    left: 30px;
  }
}
@media only screen and (max-width: 767px) {
  .categories_content.content_left {
    left: 30px;
  }
}

/* 10. shop page css here */
.header_shop {
  border-bottom: 1px solid #ebebeb;
}
.header_shop .header_top {
  padding: 7px 0;
}
.header_shop .header_middel {
  padding: 40px 0 18px;
}
@media only screen and (max-width: 767px) {
  .header_shop .header_middel {
    padding: 21px 0 18px;
  }
}
.header_shop .header_bottom {
  padding: 0;
}

.canvas_padding {
  margin-bottom: 0;
}

.breadcrumbs_area {
  background: #f0f0f0;
  border-bottom: 1px solid #ebebeb;
  padding: 20px 0;
}
@media only screen and (max-width: 767px) {
  .breadcrumbs_area {
    padding: 12px 0;
  }
}

.breadcrumb_content ul li {
  display: inline-block;
  text-transform: capitalize;
  font-size: 14px;
  margin-right: 3px;
  padding-right: 13px;
  position: relative;
}
.breadcrumb_content ul li::before {
  position: absolute;
  content: "/";
  right: 0;
  top: 50%;
  transform: translatey(-50%);
}
.breadcrumb_content ul li:last-child {
  margin-right: 0;
}
.breadcrumb_content ul li:last-child::before {
  display: none;
}
.breadcrumb_content ul li a {
  color: #999;
}
.breadcrumb_content ul li a:hover {
  color: #1D1678;
}

.widget_inner {
  background: #f8f8f8;
  padding: 55px 20px 48px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .widget_inner {
    padding: 55px 12px 48px;
  }
}

.sidebar_widget .single_banner {
  border: 0;
}
@media only screen and (max-width: 767px) {
  .sidebar_widget .single_banner {
    margin-bottom: 0;
  }
}
@media only screen and (max-width: 767px) {
  .sidebar_widget .single_banner a {
    width: 100%;
  }
}
@media only screen and (max-width: 767px) {
  .sidebar_widget .single_banner a img {
    width: 100%;
  }
}

.widget_list {
  margin-bottom: 56px;
}
.widget_list:last-child {
  margin-bottom: 0;
}
.widget_list h2 {
  font-size: 20px;
  margin-bottom: 20px;
  text-transform: capitalize;
  font-weight: 600;
  line-height: 24px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .widget_list h2 {
    font-size: 18px;
  }
}
.widget_list > ul > li {
  border-bottom: 1px solid #ebebeb;
}
.widget_list > ul > li:first-child a {
  padding-top: 0;
}
.widget_list > ul > li > a {
  font-size: 14px;
  display: block;
  line-height: 25px;
  padding: 10px 0;
}
.widget_list > ul > li > a:hover {
  color: #1D1678;
}
.widget_list > ul > li.widget_sub_categories > a {
  position: relative;
}
.widget_list > ul > li.widget_sub_categories > a::before {
  content: '\f107';
  cursor: pointer;
  font-family: FontAwesome;
  font-size: 12px;
  position: absolute;
  right: 0;
  top: 50%;
  transform: translatey(-50%);
}
.widget_list > ul > li.widget_sub_categories > a.active::before {
  content: '\f106';
  cursor: pointer;
  font-family: FontAwesome;
  font-size: 12px;
  position: absolute;
  right: 0;
  top: 50%;
  transform: translatey(-50%);
}
.widget_list > ul > li ul {
  padding-left: 15px;
}
.widget_list > ul > li ul li {
  border-bottom: 1px solid #ebebeb;
}
.widget_list > ul > li ul li:first-child {
  border-top: 1px solid #ebebeb;
}
.widget_list > ul > li ul li:last-child {
  border-bottom: 0;
}
.widget_list > ul > li ul li a {
  padding-bottom: 10px;
  padding: 10px 0;
  display: block;
}

.ui-slider-horizontal .ui-slider-range {
  background: #1D1678;
  height: 5px;
}

.ui-slider-horizontal {
  height: 3px;
  background: #dbdbdb;
  border: none;
  width: 92%;
  margin: 0 auto;
  margin-bottom: 22px;
}

.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default {
  background: #fff;
  border: 0;
  border-radius: 0;
  width: 19px;
  height: 19px;
  top: -7px;
  cursor: pointer;
  border-radius: 50%;
  border: 5px solid #1D1678;
}

.widget_list.widget_filter form {
  padding-top: 10px;
}
.widget_list.widget_filter form input {
  background: none;
  border: none;
  font-size: 12px;
  float: right;
  text-align: right;
  line-height: 31px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .widget_list.widget_filter form input {
    width: 65px;
  }
}
.widget_list.widget_filter form button {
  height: 30px;
  line-height: 30px;
  padding: 0 20px;
  text-transform: capitalize;
  color: #ffffff;
  background: #242424;
  border: 0;
  border-radius: 30px;
  -webkit-transition: 0.3s;
  transition: 0.3s;
}
.widget_list.widget_filter form button:hover {
  background: #1D1678;
}

@media only screen and (min-width: 768px) and (max-width: 991px) {
  .recent_product_container {
    overflow: hidden;
  }
}

.recent_product_list {
  border-bottom: 1px solid #ebebeb;
  padding-bottom: 20px;
  margin-bottom: 20px;
  overflow: hidden;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .recent_product_list {
    width: 47%;
    float: left;
    border: 1px solid #ddd;
    padding: 20px;
    margin-bottom: 25px;
  }
  .recent_product_list:first-child {
    margin-right: 30px;
  }
}
.recent_product_list:last-child {
  margin-bottom: 0;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .recent_product_list:last-child {
    border: 1px solid #ddd;
    padding: 20px;
  }
}
.recent_product_list .product_thumb {
  width: 68px;
  float: left;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .recent_product_list .product_thumb {
    width: 57px;
  }
}
.recent_product_list .product_content {
  width: 70%;
  float: left;
  padding-left: 15px;
  text-align: left;
  margin-top: 0;
}
.recent_product_list .product_content h3 {
  margin-bottom: 6px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .recent_product_list .product_content h3 {
    margin-bottom: 3px;
    font-size: 12px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .recent_product_list .product_content {
    padding-left: 10px;
    width: 69%;
  }
}
.recent_product_list .price_box {
  margin-bottom: 0;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .recent_product_list .price_box span.current_price {
    font-size: 14px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .recent_product_list .price_box span.old_price {
    font-size: 13px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .recent_product_list .product_ratings {
    margin-bottom: 2px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .recent_product_list .product_ratings ul li a {
    font-size: 18px;
  }
}

.tag_cloud a {
  margin: 0 5px 12px 0;
  padding: 5px 15px;
  text-transform: capitalize;
  display: inline-block;
  border: 1px solid #ebebeb;
  background: #ffffff;
  border-radius: 3px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .tag_cloud a {
    padding: 5px 10px;
  }
}
.tag_cloud a:hover {
  background: #1D1678;
  border-color: #1D1678;
  color: #ffffff;
}

.shop_toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border: 1px solid #e5e5e5;
  padding: 8px 10px;
  margin: 0 0 40px;
}
@media only screen and (max-width: 767px) {
  .shop_toolbar {
    flex-direction: column-reverse;
    padding: 10px 10px 18px;
  }
}

.select_option {
  display: flex;
  align-items: center;
}
@media only screen and (max-width: 767px) {
  .select_option {
    flex-direction: column;
  }
}
.select_option .nice-select {
  border: 0;
  height: 30px;
  line-height: 29px;
}
.select_option .nice-select ul.list {
  top: 114%;
  right: 0;
  width: 200px;
  max-height: 200px;
  overflow: auto;
}

@media only screen and (max-width: 767px) {
  .niceselect_option {
    margin-bottom: 16px;
  }
}

@media only screen and (max-width: 767px) {
  .page_amount {
    margin-bottom: 12px;
  }
}
@media only screen and (max-width: 767px) {
  .page_amount p {
    padding-left: 0;
    margin-left: 0;
    border-left: 0;
  }
}

.list_button ul li {
  margin-right: 12px;
}
.list_button ul li:last-child {
  margin-right: 0;
}
.list_button ul li a:hover {
  color: #1D1678;
}
.list_button ul li a i {
  margin-right: 5px;
  border-radius: 100%;
  height: 30px;
  width: 30px;
  line-height: 30px;
  text-align: center;
}
.list_button ul li a.active {
  color: #1D1678;
}
.list_button ul li a.active i {
  background: #1D1678;
  color: #ffffff;
}

.product_ratting ul li {
  display: inline-block;
}
.product_ratting ul li a {
  color: #1D1678;
}

@media only screen and (max-width: 767px) {
  .product_list_item .product_thumb {
    margin-bottom: 18px;
  }
}
.product_list_item .product_content h3 {
  margin-bottom: 10px;
}
.product_list_item .product_ratting {
  margin-bottom: 10px;
}

@media only screen and (max-width: 767px) {
  .pagination {
    margin-top: 19px;
  }
}
.pagination ul li {
  display: inline-block;
  width: 30px;
  height: 30px;
  line-height: 30px;
  text-align: center;
  background: #f1f1f1;
  border-radius: 3px;
  margin-left: 3px;
}
.pagination ul li:first-child {
  margin-left: 0;
}
.pagination ul li a {
  display: block;
  border-radius: 3px;
}
.pagination ul li a:hover {
  background: #1D1678;
  color: #ffffff;
}
.pagination ul li.current {
  background: #1D1678;
  color: #ffffff;
}
.pagination ul li.next {
  width: 40px;
}

.shop_toolbar.t_bottom {
  justify-content: center;
  margin-bottom: 0;
  margin-top: 16px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .shop_toolbar.t_bottom {
    margin-bottom: 60px;
  }
}
@media only screen and (max-width: 767px) {
  .shop_toolbar.t_bottom {
    padding: 15px 10px 15px;
    margin-bottom: 60px;
  }
}
@media only screen and (max-width: 767px) {
  .shop_toolbar.t_bottom .pagination {
    margin-top: 0;
  }
}

@media only screen and (min-width: 768px) and (max-width: 991px) {
  .shop_reverse .tab-content .row {
    flex-direction: row;
  }
}
@media only screen and (max-width: 767px) {
  .shop_reverse .tab-content .row {
    flex-direction: row;
  }
}

@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .grid_view .quick_button {
    bottom: 5px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .grid_view .quick_button a {
    line-height: 37px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .grid_view .action_button ul li a {
    width: 43px;
    height: 40px;
    line-height: 38px;
  }
}
.grid_view .hover_action a {
  width: 43px;
  height: 40px;
  line-height: 38px;
}

/* shop page css here*/
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .shop_reverse .row {
    flex-direction: column-reverse;
  }
}
@media only screen and (max-width: 767px) {
  .shop_reverse .row {
    flex-direction: column-reverse;
  }
}

.row.shop_wrapper {
  flex-direction: row;
}

.shop_toolbar_btn > button {
  margin-right: 10px;
  border: 0;
  background: inherit;
}
.shop_toolbar_btn > button.btn-grid-3 {
  background: url(../img/icon/bkg_grid.png) no-repeat scroll center center;
  width: 20px;
  height: 20px;
}
.shop_toolbar_btn > button.btn-grid-3.active {
  background: url(../img/icon/bkg_grid_hover.png) no-repeat scroll center center !important;
}
.shop_toolbar_btn > button.btn-grid-4 {
  background: url(../img/icon/bkg_grid4.png) no-repeat scroll center center;
  width: 26px;
  height: 22px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .shop_toolbar_btn > button.btn-grid-4 {
    display: none;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .shop_toolbar_btn > button.btn-grid-4 {
    display: none;
  }
}
.shop_toolbar_btn > button.btn-grid-4.active {
  background: url(../img/icon/bkg_grid4_hover.png) no-repeat scroll center center !important;
}
.shop_toolbar_btn > button.btn-list {
  background: url(../img/icon/bkg_list.png) no-repeat scroll center center;
  width: 20px;
  height: 20px;
}
.shop_toolbar_btn > button.btn-list.active {
  background: url(../img/icon/bkg_list_hover.png) no-repeat scroll center center !important;
}

.product_content.list_content {
  display: none;
}

.grid_content .product_ratings {
  margin-bottom: 11px;
}
.grid_content .product_ratings ul {
  justify-content: center;
}

.grid_list {
  margin-bottom: 39px;
}
.grid_list .grid_name {
  display: none;
}
.grid_list .action_links {
  display: none;
}
.grid_list .add_to_cart {
  display: none;
}

.grid_list .product_content.grid_content {
  display: none;
}

.grid_list .product_content.list_content {
  flex: 0 0 66.666667%;
  max-width: 66.666667%;
  float: left;
  display: flex;
  align-items: center;
  padding-left: 25px;
  text-align: left;
  margin-top: 0;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .grid_list .product_content.list_content {
    min-width: 60%;
  }
}
@media only screen and (max-width: 767px) {
  .grid_list .product_content.list_content {
    flex-direction: column;
    flex: 0 0 100%;
    min-width: 100%;
    padding-left: 0;
  }
}
.grid_list .product_content.list_content .product_name h3 {
  margin: 0 0 12px;
}
.grid_list .product_content.list_content .product_ratings {
  margin-bottom: 14px;
}

.left_caption {
  width: 60%;
  padding-right: 20px;
  border-right: 1px solid #ddd;
}
@media only screen and (max-width: 767px) {
  .left_caption {
    width: 100%;
    padding-right: 0;
    border-right: 0;
  }
}
.left_caption .price_box {
  margin-bottom: 17px;
}
.left_caption h3.product_name {
  margin-bottom: 17px;
}

.right_caption {
  width: 40%;
  padding-left: 20px;
}
@media only screen and (max-width: 767px) {
  .right_caption {
    width: 100%;
    padding-left: 0;
    margin-top: 25px;
  }
}
.right_caption .action_links {
  display: block;
  position: inherit;
  opacity: inherit;
  visibility: inherit;
  transform: initial;
}
.right_caption .action_links ul li a {
  width: inherit;
  height: inherit;
  background: inherit;
  color: #242424;
  border-radius: 0;
  text-align: left;
  font-size: 14px;
  line-height: 27px;
}
.right_caption .action_links ul li a span {
  margin-right: 8px;
}
.right_caption .action_links ul li a i {
  margin-right: 7px;
}
.right_caption .action_links ul li a:hover {
  color: #1D1678;
}
.right_caption .action_links ul li.quick_button a span {
  font-size: 22px;
  vertical-align: middle;
}
.right_caption .add_to_cart {
  display: block;
  position: inherit;
  opacity: inherit;
  visibility: inherit;
  margin-bottom: 17px;
}
@media only screen and (max-width: 767px) {
  .right_caption .add_to_cart {
    display: inline-block;
  }
}
.right_caption .add_to_cart a {
  background: #fff;
  color: #1D1678;
  border: 2px solid #1D1678;
  width: 100%;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .right_caption .add_to_cart a {
    padding: 10px 25px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .right_caption .add_to_cart a {
    padding: 10px 25px;
  }
}
.right_caption .add_to_cart a:hover {
  background: #1D1678;
  color: #fff;
}

.grid_list .single_product {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  border: 0;
  border-bottom: 1px solid #ebebeb;
  padding: 0 15px 20px 15px;
}
@media only screen and (max-width: 767px) {
  .grid_list .single_product {
    flex-direction: column;
    padding: 0 15px 20px 15px;
  }
}

.grid_list .product_thumb {
  margin-bottom: 0;
  flex: 0 0 33.333333%;
  max-width: 33.333333%;
  float: left;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .grid_list .product_thumb {
    min-width: 30%;
  }
}
@media only screen and (max-width: 767px) {
  .grid_list .product_thumb {
    flex: 0 0 100%;
    min-width: 100%;
    margin-right: 0;
    margin-bottom: 20px;
  }
}

.col-cust-5 {
  -webkit-box-flex: 0;
  -ms-flex: 0 0 20%;
  flex: 0 0 20%;
  max-width: max-width;
  padding-right: 15px;
  padding-left: 15px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .col-cust-5 {
    -ms-flex: 0 0 33%;
    flex: 0 0 33%;
  }
}
@media only screen and (max-width: 767px) {
  .col-cust-5 {
    flex: 0 0 50%;
    max-width: 50%;
  }
}
@media only screen and (max-width: 479px) {
  .col-cust-5 {
    flex: 0 0 100%;
    max-width: 100%;
  }
}

.shop_wrapper > div {
  -webkit-transition: all 1s ease;
  transition: all 1s ease;
}

.shop_toolbar_wrapper {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border: 1px solid #ddd;
  padding: 8px 10px;
  margin: 0 0 30px;
}
@media only screen and (max-width: 767px) {
  .shop_toolbar_wrapper {
    flex-direction: column;
    padding: 15px 10px 5px;
  }
}

@media only screen and (max-width: 767px) {
  .shop_toolbar_btn {
    margin-bottom: 20px;
  }
}

.shop_wrapper .single_product {
  position: relative;
  margin-bottom: 20px;
}
.shop_wrapper .label_product {
  bottom: 40px;
}
.shop_wrapper.grid_4 .price_box span.current_price {
  font-size: 15px;
  margin-right: 3px;
}
.shop_wrapper.grid_4 .price_box span.old_price {
  font-size: 14px;
}
.shop_wrapper.grid_4 .add_to_cart a {
  padding: 10px 30px;
}

/* shop page css end*/
/*shop fullwidth css here*/
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .shop_fullwidth {
    margin-bottom: 0;
  }
}
@media only screen and (max-width: 767px) {
  .shop_fullwidth {
    margin-bottom: 0;
  }
}

/* 15. product details css here */
#img-1 {
  border: 1px solid #ebebeb;
}

.header_product {
  border-bottom: 1px solid #ebebeb;
}

.product_d_right h1 {
  text-transform: capitalize;
  line-height: 20px;
  font-size: 22px;
  font-weight: 400;
  margin-bottom: 22px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_d_right h1 {
    font-size: 20px;
  }
}
@media only screen and (max-width: 767px) {
  .product_d_right h1 {
    margin-bottom: 17px;
    font-size: 18px;
  }
}
.product_d_right .product_ratting {
  margin-bottom: 17px;
}
@media only screen and (max-width: 767px) {
  .product_d_right .product_ratting {
    margin-bottom: 12px;
  }
}
.product_d_right .product_ratting ul li.review a {
  color: #5a5a5a;
  margin-left: 10px;
}
.product_d_right .product_ratting ul li.review a:hover {
  color: #1D1678;
}
.product_d_right .price_box {
  margin-bottom: 14px;
}
@media only screen and (max-width: 767px) {
  .product_d_right .price_box {
    margin-bottom: 9px;
  }
}
.product_d_right .price_box span.current_price {
  font-size: 23px;
}
@media only screen and (max-width: 767px) {
  .product_d_right .price_box span.current_price {
    font-size: 18px;
  }
}
.product_d_right .price_box span.old_price {
  font-size: 20px;
}
@media only screen and (max-width: 767px) {
  .product_d_right .price_box span.old_price {
    font-size: 17px;
  }
}
.product_d_right .product_desc {
  margin-bottom: 19px;
  padding-bottom: 24px;
  border-bottom: 1px solid #ebebeb;
}

.product_desc ul {
  margin-bottom: 20px;
}

.product_desc ul li {
  color: #39b93c;
  font-weight: 600;
  margin-bottom: 5px;
  position: relative;
  padding-left: 20px;
}

.product_desc ul li:before {
  position: absolute;
  left: 0;
  top: 0;
  color: #39b93c;
  content: "\f058";
  font-family: Fontawesome;
}


@media only screen and (max-width: 767px) {
  .product_d_right .product_desc {
    margin-bottom: 15px;
    padding-bottom: 18px;
  }
}
.product_d_right .product_desc::before {
  display: none;
}
.product_d_right .product_desc p {
  font-size: 14px;
  line-height: 26px;
}
.product_d_right .priduct_social ul li {
  display: inline-block;
  margin-right: 7px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_d_right .priduct_social ul li {
    margin-right: 3px;
  }
}
@media only screen and (max-width: 767px) {
  .product_d_right .priduct_social ul li {
    margin-right: 2px;
  }
}
.product_d_right .priduct_social ul li:last-child {
  margin-right: 0;
}
.product_d_right .priduct_social ul li a {
  color: #fff;
  font-size: 12px;
  line-height: 24px;
  padding: 0 8px;
  border-radius: 3px;
  text-transform: capitalize;
  display: block;
}
@media only screen and (max-width: 767px) {
  .product_d_right .priduct_social ul li a {
    padding: 0 4px;
  }
}
.product_d_right .priduct_social ul li a:hover {
  opacity: 0.8;
}
.product_d_right .priduct_social ul li a.facebook {
  background: #3B5999;
}
.product_d_right .priduct_social ul li a.twitter {
  background: #1DA1F2;
}
.product_d_right .priduct_social ul li a.pinterest {
  background: #CB2028;
}
.product_d_right .priduct_social ul li a.google-plus {
  background: #fe6d4c;
}
.product_d_right .priduct_social ul li a.linkedin {
  background: #010103;
}
.product_d_right .product_timing {
  position: inherit;
  margin-bottom: 22px;
  margin-top: 30px;
}
@media only screen and (max-width: 767px) {
  .product_d_right .product_timing {
    margin-bottom: 16px;
    margin-top: 25px;
  }
}
.product_d_right .countdown_area {
  max-width: 320px;
}
@media only screen and (max-width: 767px) {
  .product_d_right .countdown_area {
    max-width: 190px;
  }
}

.product_nav {
  float: right;
  position: relative;
  top: -46px;
}
@media only screen and (max-width: 767px) {
  .product_nav {
    display: none;
  }
}
.product_nav ul li {
  display: inline-block;
  margin-left: 3px;
}
.product_nav ul li:first-child {
  margin-left: 0;
}
.product_nav ul li a {
  background: #1D1678;
  border-radius: 3px;
  color: #ffffff;
  display: block;
  font-size: 15px;
  height: 30px;
  width: 30px;
  line-height: 28px;
  text-align: center;
}
.product_nav ul li a:hover {
  background: #242424;
}

.product_variant.quantity {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  align-items: center;
  margin-bottom: 20px;
}
@media only screen and (max-width: 767px) {
  .product_variant.quantity {
    margin-bottom: 16px;
  }
}
.product_variant.quantity label {
  font-weight: 600;
  text-transform: capitalize;
  font-size: 14px;
  margin-bottom: 0;
}
.product_variant.quantity input {
  width: 130px;
  border: 1px solid #ebebeb;
  background: none;
  height: 42px;
  padding: 0 12px;
  border-radius: 5px;
  margin-left: 15px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_variant.quantity input {
    width: 110px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_variant.quantity input {
    width: 80px;
  }
}
@media only screen and (max-width: 767px) {
  .product_variant.quantity input {
    width: 65px;
    margin-left: 10px;
  }
}
.product_variant.quantity button {
  border: 0;
  font-size: 16px;
  margin-left: 20px;
  background: #1D1678;
  height: 42px;
  line-height: 42px;
  text-transform: capitalize;
  min-width: 270px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_variant.quantity button {
    min-width: 240px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_variant.quantity button {
    min-width: 170px;
  }
}
@media only screen and (max-width: 767px) {
  .product_variant.quantity button {
    min-width: inherit;
    margin-left: 10px;
  }
}
.product_variant.quantity button:hover {
  background: #3E444A;
}
.product_variant.color {
  margin-bottom: 26px;
}
@media only screen and (max-width: 767px) {
  .product_variant.color {
    margin-bottom: 18px;
  }
}
.product_variant.color h3 {
  font-weight: 600;
  text-transform: capitalize;
  font-size: 18px;
  margin-bottom: 0;
  margin-right: 40px;
}
.product_variant.color label {
  font-size: 15px;
  font-weight: 600;
  text-transform: capitalize;
}
.product_variant.color ul li {
  display: inline-block;
  padding: 2px;
  border: 1px solid #ccc;
  margin-right: 5px;
}
.product_variant.color ul li:hover {
  border-color: #E88888;
}
.product_variant.color ul li:last-child {
  margin-right: 0;
}
.product_variant.color ul li a {
  width: 30px;
  height: 30px;
  display: block;
}
.product_variant.color ul li.color1 a {
  background: #000000;
}
.product_variant.color ul li.color2 a {
  background: #BEBEBE;
}
.product_variant.color ul li.color3 a {
  background: #FE0000;
}
.product_variant.color ul li.color4 a {
  background: #FFFF01;
}
.product_variant.size {
  margin-bottom: 30px;
}
.product_variant.size label {
  font-size: 15px;
  font-weight: 600;
  text-transform: capitalize;
}
.product_variant.size .niceselect_option {
  float: inherit;
  max-width: 200px;
}

.product_d_action {
  margin-bottom: 14px;
}
.product_d_action ul li a {
  font-size: 14px;
  line-height: 28px;
}
.product_d_action ul li a:hover {
  color: #1D1678;
}

.product_meta {
  margin-bottom: 24px;
}
@media only screen and (max-width: 767px) {
  .product_meta {
    margin-bottom: 20px;
  }
}
.product_meta span {
  font-weight: 600;
}
.product_meta span a {
  margin-left: 10px;
  font-weight: 400;
}
.product_meta span a:hover {
  color: #1D1678;
}

.product_info_button {
  border-bottom: 1px solid #ebebeb;
  padding-bottom: 15px;
  margin-bottom: 29px;
}
@media only screen and (max-width: 767px) {
  .product_info_button ul li {
    margin-bottom: 5PX;
  }
  .product_info_button ul li:last-child {
    margin-bottom: 0;
  }
}
.product_info_button ul li a {
  display: block;
  float: left;
  text-transform: capitalize;
  font-size: 20px;
  color: #555;
  font-weight: 600;
  margin-right: 35px;
  line-height: 26px;
  position: relative;
}
@media only screen and (max-width: 767px) {
  .product_info_button ul li a {
    margin-right: 25px;
    font-size: 17px;
  }
}
.product_info_button ul li a.active {
  color: #333333;
}
.product_info_button ul li a:hover {
  color: #333333;
}
.product_info_button ul li:last-child a {
  margin-right: 0;
}

.product_review_form button {
  border: none;
  background: #242424;
  color: #ffffff;
  text-transform: uppercase;
  font-weight: 600;
  padding: 5px 15px 3px;
  display: block;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  cursor: pointer;
  margin-top: 20px;
  border-radius: 5px;
  font-size: 13px;
}
.product_review_form button:hover {
  background: #1D1678;
  color: #ffffff;
}

.product_info_content p {
  line-height: 28px;
}

.product_d_table {
  padding: 10px 0 22px;
}
.product_d_table table {
  border-top: 1px solid #ddd;
  width: 100%;
}
.product_d_table table tbody tr {
  border-bottom: 1px solid #ddd;
}
.product_d_table table tbody tr td {
  padding: 7px 17px;
}
.product_d_table table tbody tr td:first-child {
  border-right: 1px solid #ddd;
  width: 30%;
  font-weight: 700;
}

.product_d_inner {
  padding: 20px 30px 27px;
  border: 1px solid #ebebeb;
}
@media only screen and (max-width: 767px) {
  .product_d_inner {
    padding: 20px 20px 27px;
  }
}

.product_info_inner {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  margin-top: 15px;
}
.product_info_inner .product_ratting {
  margin-bottom: 10px;
}
.product_info_inner .product_ratting p {
  margin-bottom: 5px;
}
.product_info_inner .product_ratting strong {
  margin-top: 10px;
  display: block;
  margin-bottom: 8px;
}

.reviews_wrapper h2 {
  font-size: 18px;
  font-weight: 600;
  text-transform: capitalize;
}
@media only screen and (max-width: 767px) {
  .reviews_wrapper h2 {
    font-size: 15px;
  }
}
.reviews_wrapper .product_ratting {
  margin-bottom: 20px;
}
.reviews_wrapper .product_ratting h3 {
  font-size: 14px;
  font-weight: 700;
  text-transform: capitalize;
}

.comment_title {
  margin-bottom: 20px;
}

.product_review_form input {
  border: 1px solid #ddd;
  background: none;
  width: 100%;
  height: 40px;
  padding: 0 20px;
}
.product_review_form textarea {
  border: 1px solid #ddd;
  background: none;
  height: 120px;
  resize: none;
  width: 100%;
  margin-bottom: 14px;
  padding: 0 20px;
}
.product_review_form p {
  margin-bottom: 7px;
}

.star_rating {
  float: right;
}
.star_rating ul li {
  display: inline-block;
}
.star_rating ul li a {
  color: #1D1678;
}

.reviews_comment_box {
  display: flex;
  margin-bottom: 22px;
}
.reviews_comment_box .comment_text {
  width: 100%;
  border: 1px solid #ebebeb;
  position: relative;
  margin-left: 21px;
  padding: 12px;
  border-radius: 3px;
}
.reviews_comment_box .comment_text::before {
  background: #fff;
  border-bottom: 1px solid #ebebeb;
  border-left: 1px solid #ebebeb;
  content: '';
  display: block;
  height: 10px;
  left: -6px;
  position: absolute;
  top: 10px;
  -webkit-transform: rotate(45deg);
  transform: rotate(45deg);
  width: 10px;
}

.reviews_meta p {
  font-size: 15px;
  margin-bottom: 15px;
}
.reviews_meta p strong {
  text-transform: uppercase;
  font-weight: 600;
  color: #242424;
}

.s-tab-zoom.owl-carousel .owl-nav {
  display: block;
}
.s-tab-zoom.owl-carousel .owl-nav div {
  position: absolute;
  background: #f2f2f2;
  border-radius: 3px;
  height: 32px;
  top: 50%;
  transform: translatey(-50%);
  width: 32px;
  text-align: center;
  line-height: 32px;
  left: -7px;
  font-size: 18px;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  opacity: 0;
  visibility: hidden;
}
.s-tab-zoom.owl-carousel .owl-nav div:hover {
  background: #1D1678;
  color: #ffffff;
}
.s-tab-zoom.owl-carousel .owl-nav div.owl-next {
  right: -7px;
  left: auto;
}

@media only screen and (max-width: 767px) {
  .product-details-tab {
    margin-bottom: 58px;
  }
}
.product-details-tab:hover .s-tab-zoom.owl-carousel .owl-nav div {
  opacity: 1;
  visibility: visible;
}

.single-zoom-thumb {
  margin-top: 20px !important;
  width: 80%;
  margin: 0 auto;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .single-zoom-thumb {
    width: 85%;
  }
}
@media only screen and (max-width: 767px) {
  .single-zoom-thumb {
    width: 101%;
  }
}
.single-zoom-thumb ul li {
  border: 1px solid #ddd;
}
.single-zoom-thumb ul li a {
  width: 100%;
}

.related_products {
  margin-bottom: 33px;
}

.upsell_products {
  margin-bottom: 34px;
}

/* 12. product grouped css here */
.grouped_form {
  border: 1px solid #ebebeb;
  margin-bottom: 25px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .grouped_form {
    margin-bottom: 20px;
  }
}
@media only screen and (max-width: 767px) {
  .grouped_form {
    margin-bottom: 17px;
  }
}
.grouped_form table {
  width: 100%;
}
.grouped_form table tbody tr {
  border-bottom: 1px solid #ebebeb;
}
.grouped_form table tbody tr td {
  border-right: 1px solid #ddd;
  padding: 11px 5px;
  text-align: center;
}
.grouped_form table tbody tr td input[type="checkbox"] {
  width: 20px;
  height: 21px;
}
.grouped_form table tbody tr td input[type="number"] {
  width: 50px;
  background: inherit;
  border: 1px solid #ebebeb;
  padding: 0 5px;
  height: 40px;
}
.grouped_form table tbody tr td.grouped-product-list.quantity {
  min-width: 80px;
  text-align: center;
  line-height: 12px;
}
.grouped_form table tbody tr td.grouped-product-list.label {
  min-width: 188px;
  font-weight: 600;
  font-size: 14px;
}
.grouped_form table tbody tr td.grouped-product-list.label a:hover {
  color: #1D1678;
}
.grouped_form table tbody tr td.grouped-product-list.price {
  font-size: 14px;
  font-weight: 600;
  min-width: 190px;
}
.grouped_form table tbody tr td.grouped-product-list.price p {
  font-size: 12px;
  font-weight: 600;
  position: relative;
}
.grouped_form table tbody tr td.grouped-product-list.price p::before {
  color: #1953b4;
  content: '\f058';
  display: inline-block;
  font-family: FontAwesome;
  font-size: 1em;
  position: absolute;
  top: 0;
  left: 40px;
}

.grouped_form table tbody tr td:last-child {
  border-right: 0;
}

.grouped_form table tbody tr:last-child {
  border-bottom: 0;
}

.box_quantity.group button {
  margin-left: 0;
}

/*product grouped css end*/
/*variabla product css here*/
.p_section1.related_product .slick-list {
  padding-bottom: 144px !important;
  margin-bottom: -135px;
}

.variable_product .niceselect_option .list {
  width: 100%;
}

.product_d_meta {
  margin-bottom: 20px;
}
.product_d_meta span {
  display: block;
  line-height: 18px;
  margin-bottom: 17px;
  font-size: 14px;
  font-weight: 400;
}
.product_d_meta span:last-child {
  margin-bottom: 0;
}
.product_d_meta span a:hover {
  color: #1D1678;
}

/*product sidebar css here*/
.product_sidebar {
  margin-bottom: 0;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_sidebar {
    margin-bottom: 60px;
  }
}
@media only screen and (max-width: 767px) {
  .product_sidebar {
    margin-bottom: 60px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_sidebar .row {
    flex-direction: column-reverse;
  }
}
@media only screen and (max-width: 767px) {
  .product_sidebar .row {
    flex-direction: column-reverse;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_sidebar .product_section .row {
    flex-direction: row;
  }
}
@media only screen and (max-width: 767px) {
  .product_sidebar .product_section .row {
    flex-direction: row;
  }
}
.product_sidebar .product_desc p {
  width: 100%;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_sidebar .action_button ul li a {
    width: 40px;
    height: 35px;
    line-height: 35px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_sidebar .quick_button {
    bottom: 12px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_sidebar .quick_button a {
    line-height: 35px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_sidebar .hover_action a {
    width: 40px;
    height: 35px;
    line-height: 35px;
  }
}
.product_sidebar .product_variant.quantity input {
  width: 90px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_sidebar .product_variant.quantity input {
    width: 60px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_sidebar .product_variant.quantity input {
    width: 60px;
  }
}
@media only screen and (max-width: 767px) {
  .product_sidebar .product_variant.quantity input {
    width: 60px;
  }
}
.product_sidebar .product_variant.quantity button {
  min-width: 200px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_sidebar .product_variant.quantity button {
    min-width: 140px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_sidebar .product_variant.quantity button {
    min-width: inherit;
  }
}
@media only screen and (max-width: 767px) {
  .product_sidebar .product_variant.quantity button {
    min-width: inherit;
  }
}
@media only screen and (max-width: 767px) {
  .product_sidebar .product-details-tab {
    margin-bottom: 0;
  }
}
.product_sidebar .price_box span.current_price {
  font-size: 16px;
}
.product_sidebar .price_box span.old_price {
  font-size: 15px;
}
.product_sidebar .price_box span.regular_price {
  font-size: 16px;
}

.footer_widgets.sidebar_widgets .footer_top {
  padding-bottom: 0;
  border-bottom: 0;
}
.footer_widgets.sidebar_widgets .footer_top_inner {
  padding: 56px 0 52px;
  border-top: 1px solid #ebebeb;
  border-bottom: 1px solid #ebebeb;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .footer_widgets.sidebar_widgets .footer_top_inner {
    padding: 56px 0 40px;
  }
}
@media only screen and (max-width: 767px) {
  .footer_widgets.sidebar_widgets .footer_top_inner {
    padding: 56px 0 35px;
  }
}

.product_right_sidebar {
  margin-bottom: 60px;
}
@media only screen and (max-width: 767px) {
  .product_right_sidebar .product-details-tab {
    margin-bottom: 45px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .product_right_sidebar .row {
    flex-direction: row;
  }
}
@media only screen and (max-width: 767px) {
  .product_right_sidebar .row {
    flex-direction: row;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_right_sidebar .priduct_social ul li {
    margin-right: 3px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .product_right_sidebar .product_d_right h1 {
    font-size: 20px;
  }
}

/* 13. cart page css here */
.header_cart_page {
  border-bottom: 1px solid #ebebeb;
}

.other_bread {
  padding-top: 41px;
  padding-bottom: 41px;
}

.table_desc {
  border: 1px solid #ebebeb;
  margin-bottom: 60px;
  margin-top: 2px;
}
.table_desc .cart_page table {
  width: 100%;
}
.table_desc .cart_page table thead tr th {
  border-bottom: 3px solid #1D1678;
  border-right: 1px solid #ebebeb;
  font-size: 16px;
  font-weight: 600;
  text-transform: capitalize;
  padding: 10px;
  text-align: center;
}
.table_desc .cart_page table tbody tr td {
  border-bottom: 1px solid #ebebeb;
  border-right: 1px solid #ebebeb;
  text-align: center;
  padding: 10px;
}
.table_desc .cart_page table tbody tr td.product_remove {
  min-width: 100px;
}
.table_desc .cart_page table tbody tr td.product_remove a {
  font-size: 20px;
  color: #242424;
}
.table_desc .cart_page table tbody tr td.product_remove a:hover {
  color: #1D1678;
}
.table_desc .cart_page table tbody tr td.product_thumb {
  max-width: 180px;
}
.table_desc .cart_page table tbody tr td.product_thumb a img {
  width: 100px;
}
.table_desc .cart_page table tbody tr td.product_name {
  min-width: 180px;
}
.table_desc .cart_page table tbody tr td.product_name a {
  color: #242424;
  text-transform: capitalize;
  font-size: 14px;
  font-weight: 400;
}
.table_desc .cart_page table tbody tr td.product_name a:hover {
  color: #1D1678;
}
.table_desc .cart_page table tbody tr td.product-price {
  min-width: 130px;
  color: #242424;
  font-size: 16px;
  font-weight: 600;
}
.table_desc .cart_page table tbody tr td.product_quantity {
  min-width: 180px;
}
.table_desc .cart_page table tbody tr td.product_quantity label {
  font-weight: 600;
  margin-right: 5px;
}
.table_desc .cart_page table tbody tr td.product_quantity input {
  width: 60px;
  height: 40px;
  padding: 0 5px 0 10px;
  background: none;
  border: 1px solid #ebebeb;
}
.table_desc .cart_page table tbody tr td .product_total {
  min-width: 120px;
}

.cart_page table thead tr:last-child th, .table_desc table tbody tr td:last-child {
  border-right: 0;
}

.cart_submit {
  text-align: right;
  padding: 12px;
}
@media only screen and (max-width: 767px) {
  .cart_submit {
    text-align: center;
  }
}
.cart_submit button {
  background: #1D1678;
  border: 0;
  color: #ffffff;
  display: inline-block;
  font-size: 12px;
  font-weight: 600;
  height: 38px;
  line-height: 18px;
  padding: 10px 15px;
  text-transform: uppercase;
  cursor: pointer;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  border-radius: 3px;
}
.cart_submit button:hover {
  background: #1D1678;
}

.coupon_inner {
  padding: 10px 20px 25px;
}
.coupon_inner p {
  font-size: 13px;
  margin-bottom: 20px;
}
.coupon_inner button {
  background: #1D1678;
  border: 0;
  color: #ffffff;
  display: inline-block;
  font-size: 12px;
  font-weight: 600;
  height: 38px;
  line-height: 18px;
  padding: 10px 15px;
  text-transform: uppercase;
  cursor: pointer;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  border-radius: 3px;
}
.coupon_inner button:hover {
  background: #1D1678;
}
.coupon_inner input {
  border: 1px solid #ebebeb;
  height: 42px;
  background: none;
  padding: 0 20px;
  margin-right: 20px;
  font-size: 12px;
  color: #242424;
}
@media only screen and (max-width: 767px) {
  .coupon_inner input {
    margin-bottom: 24px;
    width: 100%;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .coupon_inner input {
    margin-bottom: 24px;
    width: 100%;
  }
}
.coupon_inner a {
  display: block;
  text-align: right;
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 20px;
  border-bottom: 1px solid #ebebeb;
  padding-bottom: 10px;
  border-radius: 3px;
}
.coupon_inner a:hover {
  color: #1D1678;
}

.coupon_code {
  border: 1px solid #ebebeb;
}
@media only screen and (max-width: 767px) {
  .coupon_code.left {
    margin-bottom: 59px;
  }
}
.coupon_code h3 {
  color: #ffffff;
  line-height: 36px;
  padding: 5px 15px;
  background: #1D1678;
  text-transform: uppercase;
  font-size: 16px;
  font-weight: 600;
}
@media only screen and (max-width: 767px) {
  .coupon_code h3 {
    line-height: 28px;
    padding: 5px 15px;
    font-size: 15px;
  }
}

.cart_subtotal {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: justify;
  -ms-flex-pack: justify;
  justify-content: space-between;
}
.cart_subtotal p {
  font-weight: 600;
  font-size: 14px;
}
.cart_subtotal p.cart_amount {
  font-size: 18px;
  font-weight: 600;
}
@media only screen and (max-width: 767px) {
  .cart_subtotal p.cart_amount {
    font-size: 14px;
  }
}
.cart_subtotal p span {
  margin-right: 30px;
}

.checkout_btn {
  text-align: right;
}
.checkout_btn a {
  background: #1D1678;
  color: #ffffff;
  font-size: 15px;
  padding: 3px 14px;
  line-height: 30px;
  font-weight: 600;
  display: inline-block;
  text-transform: capitalize;
  margin-bottom: 0;
}
.checkout_btn a:hover {
  background: #242424;
  color: #ffffff;
}

.coupon_area {
  margin-bottom: 60px;
}

.footer_widgets.other_widgets .footer_top {
  padding-bottom: 0;
  border-bottom: 0;
}
.footer_widgets.other_widgets .footer_top_inner {
  padding: 55px 0 53px;
  border-top: 1px solid #ebebeb;
  border-bottom: 1px solid #ebebeb;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .footer_widgets.other_widgets .footer_top_inner {
    padding: 55px 0 59px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .footer_widgets.other_widgets .footer_top_inner {
    padding: 55px 0 40px;
  }
}
@media only screen and (max-width: 767px) {
  .footer_widgets.other_widgets .footer_top_inner {
    padding: 55px 0 35px;
  }
}

/*cart page css end*/
/* 14. checkout page css here */
.user-actions {
  margin-bottom: 20px;
}
.user-actions h3 {
  font-size: 13px;
  font-weight: 400;
  background-color: #f7f6f7;
  padding: 15px 10px;
  border-top: 3px solid #1D1678;
  margin-bottom: 0;
}
.user-actions h3 a {
  color: #1D1678;
}

.checkout_info {
  border: 1px solid #ebebeb;
  margin-top: 25px;
  padding: 20px 30px;
}
.checkout_info p {
  margin-bottom: 15px;
}
.checkout_info a {
  color: #1D1678;
  margin-top: 15px;
  display: block;
}

.form_group {
  margin-bottom: 20px;
}
.form_group label {
  font-size: 14px;
  display: block;
  line-height: 18px;
}
.form_group input {
  border: 1px solid #ebebeb;
  background: none;
  height: 45px;
  width: 350px;
  padding: 0 20px;
}
@media only screen and (max-width: 767px) {
  .form_group input {
    width: 100%;
  }
}
.form_group button {
  display: inline-block;
  width: 80px;
  background: #242424;
  border: 0;
  color: #ffffff;
  font-weight: 600;
  text-transform: uppercase;
  font-size: 13px;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  margin-right: 20px;
  cursor: pointer;
  height: 40px;
  line-height: 40px;
  border-radius: 3px;
}
.form_group button:hover {
  background: #1D1678;
}

.form_group input[type="checkbox"] {
  width: 15px;
  height: 15px;
  margin-right: 10px;
  position: relative;
  top: 3px;
}

.form_group.group_3 {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
}
.form_group.group_3 label {
  margin-bottom: 0;
  line-height: 34px;
  cursor: pointer;
}
.form_group.group_3 label:hover {
  color: #1D1678;
}

#checkout_coupon input {
  background: none;
  border: 1px solid #ebebeb;
  width: 200px;
  height: 45px;
  font-size: 12px;
  padding: 0 20px;
  color: #242424;
}
#checkout_coupon button {
  width: 130px;
  background: #242424;
  color: #ffffff;
  font-weight: 600;
  text-transform: uppercase;
  font-size: 13px;
  cursor: pointer;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  border: 0;
  height: 45px;
  line-height: 45px;
  border-radius: 3px;
  margin-left: 5px;
}
@media only screen and (max-width: 767px) {
  #checkout_coupon button {
    margin-top: 20px;
  }
}
#checkout_coupon button:hover {
  background: #1D1678;
}

.mb-20 {
  margin-bottom: 20px;
}

.checkout_form h3 {
  font-size: 16px;
  line-height: 30px;
  padding: 5px 10px;
  text-transform: uppercase;
  color: #ffffff;
  background: #1D1678;
  font-weight: 600;
}
.checkout_form input {
  border: 1px solid #ebebeb;
  background: none;
  height: 40px;
  width: 100%;
  padding: 0 20px;
  color: #242424;
}
.checkout_form .nice-select {
  width: 100%;
}
.checkout_form .nice-select ul.list {
  width: 100%;
  height: 180px;
  overflow: auto;
}
.checkout_form .nice-select::after {
  top: 56%;
}
.checkout_form label {
  font-weight: 600;
}
.checkout_form label span {
  color: #1D1678;
}
.checkout_form label.righ_0 {
  cursor: pointer;
  font-size: 15px;
  line-height: 27px;
  padding: 5px 10px;
  text-transform: capitalize;
  color: #ffffff;
  background: #242424;
  font-weight: 600;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  margin-bottom: 0;
  border-radius: 5px;
}
@media only screen and (max-width: 767px) {
  .checkout_form label.righ_0 {
    font-size: 13px;
    line-height: 25px;
    padding: 3px 10px;
  }
}
.checkout_form label.righ_0:hover {
  background: #757575;
}

.checkout_form input[type="checkbox"] {
  width: 15px;
  height: 15px;
  position: relative;
  top: 2px;
  margin-right: 10px;
}

.order_button button {
  cursor: pointer;
  font-size: 16px;
  line-height: 30px;
  padding: 5px 10px;
  text-transform: capitalize;
  color: #ffffff;
  background: #1D1678;
  font-weight: 600;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  margin-bottom: 0;
  border-radius: 5px;
}
@media only screen and (max-width: 767px) {
  .order_button button {
    font-size: 14px;
  }
}
.order_button button:hover {
  background: #242424;
}

@media only screen and (max-width: 767px) {
  .order-notes {
    margin-bottom: 58px;
  }
}
.order-notes textarea {
  border: 1px solid #e5e5e5;
  border-radius: 0;
  height: 45px;
  max-width: 100%;
  padding: 0 30px 0 20px;
  background: none;
  font-size: 13px;
  resize: none;
  line-height: 45px;
  width: 100%;
  color: #242424;
}
.order-notes label {
  line-height: 13px;
}

.Checkout_section {
  margin-bottom: 56px;
}
@media only screen and (max-width: 767px) {
  .Checkout_section {
    margin-bottom: 60px;
  }
}

.order_table {
  margin-bottom: 35px;
}
.order_table table {
  width: 100%;
}
.order_table table thead tr th {
  min-width: 50%;
  text-align: center;
  padding: 15px 0;
  border-bottom: 1px solid #ddd;
}
.order_table table tbody tr td {
  min-width: 50%;
  text-align: center;
  padding: 15px 0;
  border-bottom: 1px solid #ddd;
}
.order_table table tfoot tr th {
  min-width: 50%;
  text-align: center;
  padding: 15px 0;
  border-bottom: 1px solid #ddd;
}
.order_table table tfoot tr td {
  min-width: 50%;
  text-align: center;
  padding: 15px 0;
  border-bottom: 1px solid #ddd;
}

.panel-default input[type="radio"] {
  width: 15px;
  height: 15px;
  position: relative;
  top: 2px;
  margin-right: 10px;
}

.panel-default img {
  width: 160px;
}

.order_button button {
  border: 0;
}

.card-body1 {
  margin-bottom: 15px;
}

/*checkout page css end*/
/* 22. wishlist css here */
.table_desc.wishlist table tbody tr:last-child td {
  border-bottom: 0;
}

.table_desc.wishlist table tbody tr td.product_total a {
  background: #1D1678;
  font-size: 12px;
  font-weight: 600;
  height: 38px;
  line-height: 18px;
  padding: 10px 20px;
  color: #ffffff;
  text-transform: uppercase;
  border-radius: 3px;
}
.table_desc.wishlist table tbody tr td.product_total a:hover {
  background: #242424;
}

.wishlist_share {
  text-align: center;
  padding: 20px 0;
  border: 1px solid #ebebeb;
}
.wishlist_share h4 {
  font-size: 18px;
  font-weight: 600;
  text-transform: capitalize;
}
.wishlist_share ul li {
  display: inline-block;
}
.wishlist_share ul li a {
  padding: 0 10px;
  display: block;
}
.wishlist_share ul li a:hover {
  color: #1D1678;
}

.wishlist_area {
  padding-bottom: 60px;
}

/*wishlist css end*/
/* 15. contact page css here */
.contact_area {
  margin-bottom: 60px;
}

.contact_message h3 {
  font-size: 21px;
  text-transform: capitalize;
  font-weight: 600;
  line-height: 20px;
  margin-bottom: 25px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .contact_message h3 {
    margin-bottom: 20px;
  }
}
@media only screen and (max-width: 767px) {
  .contact_message h3 {
    font-size: 20px;
    margin-bottom: 20px;
  }
}
.contact_message p {
  font-size: 14px;
  line-height: 24px;
  margin-bottom: 20px;
}
.contact_message ul li {
  padding: 13px 0;
  border-top: 1px solid #ebebeb;
}
.contact_message ul li:last-child {
  padding-bottom: 0;
}
.contact_message ul li i {
  margin-right: 10px;
}
.contact_message ul li a:hover {
  color: #1D1678;
}
.contact_message label {
  line-height: 18px;
  font-weight: 600;
  margin-bottom: 10px;
}
.contact_message input {
  border: 1px solid #ebebeb;
  height: 55px;
  background: #ffffff;
  width: 100%;
  padding: 0 20px;
  color: #757575;
}
.contact_message textarea {
  height: 170px;
  border: 1px solid #ebebeb;
  background: #ffffff;
  resize: none;
  margin-bottom: 20px;
  width: 100%;
  padding: 10px 20px;
  color: #242424;
}
.contact_message button {
  font-weight: 400;
  height: 42px;
  line-height: 42px;
  padding: 0 30px;
  text-transform: capitalize;
  border: none;
  background: #242424;
  color: #ffffff;
  cursor: pointer;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  border-radius: 4px;
}
.contact_message button:hover {
  background: #1D1678;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .contact_message.content {
    margin-bottom: 52px;
  }
}
@media only screen and (max-width: 767px) {
  .contact_message.content {
    margin-bottom: 52px;
  }
}
.contact_message.form p.form-messege {
  margin-bottom: 0;
}

.contact_map {
  margin-bottom: 57px;
}

.map-area #googleMap {
  height: 460px;
  width: 100%;
}

/*contact page css end*/
/* 17. login page css here */
.account_form h2 {
  font-size: 28px;
  text-transform: capitalize;
  font-weight: 600;
  line-height: 22px;
  margin-bottom: 30px;
}
@media only screen and (max-width: 767px) {
  .account_form h2 {
    font-size: 24px;
    margin-bottom: 20px;
  }
}
.account_form form {
  border: 1px solid #ebebeb;
  padding: 23px 20px 29px;
  border-radius: 5px;
}
.account_form label {
  font-size: 15px;
  font-weight: 400;
  cursor: pointer;
  line-height: 12px;
  margin-bottom: 12px;
}
.account_form label:hover {
  color: #1D1678;
}
.account_form input {
  border: 1px solid #ebebeb;
  height: 40px;
  max-width: 100%;
  padding: 0 20px;
  background: none;
  width: 100%;
}
.account_form button {
  background: #1D1678;
  border: 0;
  color: #ffffff;
  display: inline-block;
  font-size: 12px;
  font-weight: 700;
  height: 34px;
  line-height: 21px;
  padding: 5px 20px;
  text-transform: uppercase;
  cursor: pointer;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  margin-left: 20px;
  border-radius: 20px;
}
.account_form button:hover {
  background: #242424;
}

.login_submit label input[type="checkbox"] {
  width: 15px;
  height: 13px;
  margin-right: 3px;
}

.login_submit {
  text-align: right;
}
.login_submit a {
  font-size: 13px;
  float: left;
  line-height: 39px;
}
.login_submit a:hover {
  color: #1D1678;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .login_submit a {
    float: none;
    line-height: 18px;
    display: block;
    margin-bottom: 20px;
  }
}
@media only screen and (max-width: 767px) {
  .login_submit a {
    float: none;
    line-height: 18px;
    display: block;
    margin-bottom: 20px;
  }
}

.customer_login {
  padding-bottom: 60px;
}
@media only screen and (max-width: 767px) {
  .customer_login {
    margin-top: 57px;
  }
}

.account_form p {
  margin-bottom: 20px;
}

@media only screen and (max-width: 767px) {
  .account_form.register {
    margin-top: 58px;
  }
}

/*login page css end */
/* 16. faq page css here */
.faq_content_area {
  margin-top: 58px;
  padding-bottom: 55px;
}
@media only screen and (max-width: 767px) {
  .faq_content_area {
    margin-top: 54px;
  }
}

.accordion_area {
  padding-bottom: 60px;
}
.accordion_area .card-header {
  background: #1D1678;
}
.accordion_area .card-header:first-child {
  border-radius: inherit;
}

.card.card_dipult {
  border: none;
  margin-bottom: 10px;
}

.card.card_dipult:last-child {
  margin-bottom: 0;
}

.card-header.card_accor {
  padding: 0;
  border: none;
}
.card-header.card_accor button {
  height: 45px;
  text-decoration: none;
  cursor: pointer;
  position: relative;
  white-space: initial;
}
@media only screen and (max-width: 767px) {
  .card-header.card_accor button {
    height: 60px;
  }
}
.card-header.card_accor button i {
  position: absolute;
  top: 50%;
  -webkit-transform: translatey(-50%);
  transform: translatey(-50%);
  right: 20px;
}
@media only screen and (max-width: 767px) {
  .card-header.card_accor button i {
    right: 10px;
  }
}
.card-header.card_accor button.btn-link {
  border: 1px solid #1D1678;
  width: 100%;
  text-align: left;
  font-size: 14px;
  font-weight: 600;
  color: #ffffff;
}
.card-header.card_accor button.btn-link.collapsed {
  background: #f2f2f2;
  border: 1px solid #ebebeb;
  width: 100%;
  text-align: left;
  color: #242424;
}

.card-header.card_accor button.btn-link i.fa-plus {
  display: none;
}

.card-header.card_accor button.btn-link.collapsed i.fa-plus {
  display: block;
}

.card-header.card_accor button.btn-link.collapsed i.fa-minus {
  display: none;
}

.faq_content_wrapper h4 {
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 15px;
  line-height: 18px;
}
@media only screen and (max-width: 767px) {
  .faq_content_wrapper h4 {
    font-size: 14px;
    line-height: 24px;
  }
}

/*faq page css end*/
/*  18. my account css here */
@media only screen and (max-width: 767px) {
  .dashboard_tab_button {
    margin-bottom: 20px;
  }
}
.dashboard_tab_button ul li {
  margin-bottom: 5px;
}
.dashboard_tab_button ul li a {
  font-size: 14px;
  color: #ffffff;
  font-weight: 600;
  text-transform: capitalize;
  background: #242424;
  border-radius: 3px;
}
.dashboard_tab_button ul li a:hover {
  background: #1D1678;
  color: #ffffff;
}
.dashboard_tab_button ul li a.active {
  background: #1D1678;
}

.main_content_area {
  padding: 60px 0 55px;
}

.dashboard_content h3 {
  font-size: 22px;
  text-transform: capitalize;
  font-weight: 600;
  margin-bottom: 15px;
}
.dashboard_content h4 {
  font-size: 20px;
  text-transform: capitalize;
  font-weight: 600;
  margin-bottom: 10px;
  margin-top: 10px;
}
.dashboard_content button {
  color: #ffffff;
  font-weight: 600;
  border: 0;
  background: #242424;
  padding: 0 20px;
  height: 30px;
  line-height: 30px;
  border-radius: 4px;
  margin-top: 10px;
}
.dashboard_content button:hover {
  background: #1D1678;
}
.dashboard_content p a {
  color: #1D1678;
  font-weight: 600;
}

.table-responsive table thead {
  background: #1D1678;
  color: #fff;
}
.table-responsive table thead tr th {
  text-align: center;
}
.table-responsive table tbody tr td {
  border-right: 1px solid #ebebeb;
  font-weight: 600;
  text-transform: capitalize;
  font-size: 14px;
  text-align: center;
  min-width: 150px;
}
.table-responsive table tbody tr td:last-child a {
  color: #1D1678;
}
.table-responsive .table {
  border-left: 1px solid #ebebeb;
  border-bottom: 1px solid #ebebeb;
  border-right: 1px solid #ebebeb;
}

.dashboard_content address {
  font-weight: 600;
}

.input-radio span input[type="radio"], .account_login_form form span input[type="checkbox"] {
  width: 15px;
  height: 15px;
  margin-right: 2px;
  position: relative;
  top: 2px;
}

.input-radio span {
  font-weight: 600;
  padding-right: 10px;
}

.account_login_form form > input {
  border: 1px solid #ddd;
  background: none;
  height: 40px;
  margin-bottom: 20px;
  width: 100%;
  padding: 0 20px;
  color: #242424;
}
.account_login_form form span.custom_checkbox {
  display: flex;
}
.account_login_form form span.custom_checkbox input {
  vertical-align: middle;
  top: 4px;
  margin-right: 7px;
}
.account_login_form form span.custom_checkbox label {
  margin-bottom: 0;
}

/*my account css end*/
/* 10. about page css here */
.about_section {
  padding-bottom: 54px;
}
@media only screen and (max-width: 767px) {
  .about_section {
    padding-bottom: 45px;
  }
}

.about_content {
  text-align: center;
}
.about_content h1 {
  display: inline-block;
  font-size: 24px;
  line-height: 24px;
  text-transform: capitalize;
  font-weight: 600;
  margin-bottom: 14px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .about_content h1 {
    font-size: 20px;
    margin-bottom: 14px;
  }
}
@media only screen and (max-width: 767px) {
  .about_content h1 {
    font-size: 18px;
    line-height: 27px;
    margin-bottom: 11px;
  }
}
.about_content p {
  font-size: 14px;
  line-height: 26px;
  max-width: 890px;
  margin: 0 auto;
}
@media only screen and (max-width: 767px) {
  .about_content p {
    margin-bottom: 8px;
  }
}

.about_thumb {
  margin-bottom: 20px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .about_thumb {
    margin-bottom: 20px;
  }
}
@media only screen and (max-width: 767px) {
  .about_thumb {
    margin-bottom: 20px;
  }
}

.chose_content h3 {
  font-size: 18px;
  text-transform: capitalize;
  font-weight: 600;
  line-height: 24px;
  margin-bottom: 23px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .chose_content h3 {
    font-size: 16px;
    margin-bottom: 13px;
  }
}
@media only screen and (max-width: 767px) {
  .chose_content h3 {
    font-size: 16px;
    line-height: 20px;
    margin-bottom: 11px;
  }
}

.choseus_area {
  margin-bottom: 60px;
  background: #f9f9f9;
  padding: 60px 0 54px;
}
@media only screen and (max-width: 767px) {
  .choseus_area {
    padding: 60px 0 28px;
  }
}

.single_chose {
  text-align: center;
}
@media only screen and (max-width: 767px) {
  .single_chose {
    margin-bottom: 25px;
  }
}
.single_chose:hover .chose_icone {
  transform: rotatey(360deg);
}

.chose_icone {
  margin-bottom: 29px;
  -webkit-transition: 0.8s;
  transition: 0.8s;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .chose_icone {
    margin-bottom: 20px;
  }
}
@media only screen and (max-width: 767px) {
  .chose_icone {
    margin-bottom: 14px;
  }
}

@media only screen and (max-width: 767px) {
  .single_gallery_section {
    margin-bottom: 25px;
  }
}

.about_gallery_section {
  margin-bottom: 55px;
}
@media only screen and (max-width: 767px) {
  .about_gallery_section {
    margin-bottom: 29px;
  }
}

.gallery_thumb {
  margin-bottom: 20px;
}
@media only screen and (max-width: 767px) {
  .gallery_thumb {
    margin-bottom: 15px;
  }
}
@media only screen and (max-width: 767px) {
  .gallery_thumb img {
    width: 100%;
  }
}

.about_gallery_content h3 {
  font-size: 18px;
  text-transform: capitalize;
  font-weight: 600;
  line-height: 24px;
  margin-bottom: 12px;
}
@media only screen and (max-width: 767px) {
  .about_gallery_content h3 {
    font-size: 16px;
    margin-bottom: 7px;
  }
}
.about_gallery_content p {
  line-height: 26px;
}

.team_area {
  margin-bottom: 54px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .team_area {
    margin-bottom: 27px;
  }
}
@media only screen and (max-width: 767px) {
  .team_area {
    margin-bottom: 27px;
  }
}

.team_member {
  text-align: center;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .team_member {
    margin-bottom: 28px;
  }
}
@media only screen and (max-width: 767px) {
  .team_member {
    margin-bottom: 28px;
  }
}

.team_thumb {
  margin-bottom: 24px;
}

.team_thumb img {
  border-radius: 50%;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .team_thumb {
    margin-bottom: 18px;
  }
}
@media only screen and (max-width: 767px) {
  .team_thumb {
    margin-bottom: 18px;
  }
}

.team_content h3 {
  font-size: 18px;
  line-height: 24px;
  font-weight: 600;
  margin-bottom: 5px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .team_content h3 {
    line-height: 18px;
    margin-bottom: 4px;
  }
}
@media only screen and (max-width: 767px) {
  .team_content h3 {
    line-height: 18px;
    margin-bottom: 4px;
    font-size: 17px;
  }
}
.team_content h5 {
  font-size: 13px;
  line-height: 17px;
  margin-bottom: 12px;
  padding-bottom: 14px;
  position: relative;
  display: inline-block;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .team_content h5 {
    margin-bottom: 11px;
    padding-bottom: 11px;
  }
}
@media only screen and (max-width: 767px) {
  .team_content h5 {
    margin-bottom: 11px;
    padding-bottom: 11px;
  }
}
.team_content h5::before {
  position: absolute;
  content: "";
  width: 37px;
  height: 2px;
  background: #1D1678;
  bottom: 0;
  left: 50%;
  transform: translatex(-50%);
}
.team_content p {
  font-size: 14px;
  line-height: 25px;
}

/*about page css end*/
/* 20. services page css here */
.services_gallery {
  padding-bottom: 28px;
}

.services_content h3 {
  font-size: 15px;
  text-transform: capitalize;
  font-weight: 600;
  margin-bottom: 11px;
  line-height: 14px;
}
.services_content p {
  font-size: 14px;
  font-weight: 400;
  line-height: 24px;
  margin-bottom: 0;
}

.services_thumb {
  margin-bottom: 20px;
}
@media only screen and (max-width: 767px) {
  .services_thumb img {
    width: 100%;
  }
}

.single_services {
  margin-bottom: 25px;
}

.our_services {
  padding: 50px 0 25px;
  background: #ECECEC;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .our_services {
    margin-bottom: 60px;
    padding: 50px 0 27px;
  }
}
@media only screen and (max-width: 767px) {
  .our_services {
    padding: 49px 0 25px;
    margin-bottom: 60px;
  }
}

.services_item {
  margin-bottom: 27px;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
}

.services_title {
  text-align: center;
  margin-bottom: 35px;
}
.services_title h2 {
  font-size: 25px;
  text-transform: uppercase;
  font-weight: 600;
  margin-bottom: 11px;
}

.services_icone {
  margin-right: 15px;
}
.services_icone i {
  font-size: 35px;
  line-height: 46px;
  color: #1D1678;
}

.services_desc h3 {
  font-size: 13px;
  font-weight: 600;
}
.services_desc p {
  font-size: 13px;
  font-weight: 400;
  line-height: 24px;
  margin-bottom: 0;
}

@media only screen and (min-width: 768px) and (max-width: 991px) {
  .services_section_thumb {
    margin-bottom: 28px;
  }
}
@media only screen and (max-width: 767px) {
  .services_section_thumb {
    margin-bottom: 28px;
  }
}

@media only screen and (min-width: 768px) and (max-width: 991px) {
  .unlimited_services {
    margin-bottom: 59px;
  }
}
@media only screen and (max-width: 767px) {
  .unlimited_services {
    margin-bottom: 59px;
  }
}

.unlimited_services_content h1 {
  font-weight: 600;
  line-height: 40px;
  text-transform: uppercase;
  font-size: 25px;
  margin-bottom: 20px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .unlimited_services_content h1 {
    line-height: 25px;
    font-size: 20px;
    margin-bottom: 12px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .unlimited_services_content h1 {
    line-height: 21px;
    font-size: 20px;
    margin-bottom: 6px;
  }
}
@media only screen and (max-width: 767px) {
  .unlimited_services_content h1 {
    line-height: 20px;
    font-size: 18px;
    margin-bottom: 6px;
  }
}
.unlimited_services_content p {
  font-size: 14px;
  line-height: 28px;
  margin-bottom: 25px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .unlimited_services_content p {
    font-size: 14px;
    margin-bottom: 15px;
  }
}
@media only screen and (max-width: 767px) {
  .unlimited_services_content p {
    font-size: 13px;
    margin-bottom: 15px;
  }
}
.unlimited_services_content a {
  font-size: 14px;
  padding: 6px 20px;
  display: inline-block;
  border: 1px solid #242424;
  border-radius: 30px;
}
.unlimited_services_content a:hover {
  background: #1D1678;
  border-color: #1D1678;
  color: #fff;
}

.priceing_table {
  background: #ECECEC;
  padding: 60px 0 30px;
}

.single_priceing {
  background: #fff;
  border-radius: 3px;
  -webkit-box-shadow: 0 1px #FFFFFF inset, 0 1px 3px rgba(34, 25, 25, 0.4);
  box-shadow: 0 1px #FFFFFF inset, 0 1px 3px rgba(34, 25, 25, 0.4);
  text-align: center;
  margin-bottom: 30px;
}

.priceing_title {
  padding: 20px;
  background: #1D1678;
}
.priceing_title h1 {
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  text-transform: uppercase;
  margin-bottom: 0;
}

.priceing_list {
  padding: 0 20px 30px;
}
.priceing_list h1 {
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  padding: 36px 0 24px;
  margin: 0;
  line-height: 20px;
}
.priceing_list h1 span {
  font-size: 40px;
}
.priceing_list ul li {
  padding: 15px 0;
  border-bottom: 1px solid #ebebeb;
  line-height: 24px;
}
.priceing_list ul li:first-child {
  border-top: 1px solid #ebebeb;
}
.priceing_list a {
  margin: 30px 0 0;
  line-height: 38px;
  padding: 0 20px;
  border: 1px solid #242424;
  color: #242424;
  display: inline-block;
  font-size: 12px;
  font-weight: 600;
  border-radius: 30px;
  text-transform: uppercase;
}

.priceing_list a.list_button, .priceing_list a:hover {
  background: #1D1678;
  border-color: #1D1678;
  color: #fff;
}

.advantages_ecommerce {
  padding: 54px 0;
}
@media only screen and (max-width: 767px) {
  .advantages_ecommerce {
    padding: 55px 0 60px;
  }
}

@media only screen and (max-width: 767px) {
  .advantages_content {
    text-align: center;
  }
}
.advantages_content h3 {
  font-size: 25px;
  font-weight: 600;
  text-transform: capitalize;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .advantages_content h3 {
    font-size: 20px;
    line-height: 20px;
  }
}
@media only screen and (max-width: 767px) {
  .advantages_content h3 {
    font-size: 16px;
    line-height: 20px;
  }
}
.advantages_content p {
  font-size: 14px;
  font-style: italic;
  font-weight: 400;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .advantages_content p {
    font-size: 13px;
  }
}
@media only screen and (max-width: 767px) {
  .advantages_content p {
    font-size: 13px;
  }
}

.advantages_button {
  text-align: center;
}
.advantages_button a {
  font-size: 14px;
  padding: 6px 20px;
  display: inline-block;
  border-radius: 30px;
  border: 1px solid #242424;
}
.advantages_button a:hover {
  background: #1D1678;
  color: #fff;
  border-color: #1D1678;
}
@media only screen and (max-width: 767px) {
  .advantages_button a {
    padding: 5px 11px;
    font-size: 13px;
    margin-top: 20px;
  }
}

/*services page css end*/
/* 11. blog page css here */
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .blog_page_section {
    margin-bottom: 60px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_page_section {
    margin-top: 57px;
  }
}
@media only screen and (max-width: 767px) {
  .blog_page_section {
    margin-top: 56px;
  }
}

.blog_header {
  text-align: center;
  margin-bottom: 40px;
}
@media only screen and (max-width: 767px) {
  .blog_header {
    margin-bottom: 32px;
  }
}
.blog_header h1 {
  font-size: 42px;
  line-height: 38px;
  margin-bottom: 0;
  font-weight: 600;
}
@media only screen and (max-width: 767px) {
  .blog_header h1 {
    font-size: 35px;
    line-height: 35px;
  }
}

.blog_wrapper .blog_thumb iframe {
  height: 248px;
  width: 100%;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .blog_wrapper .blog_thumb iframe {
    height: 200px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_wrapper .blog_thumb iframe {
    height: 200px;
  }
}
@media only screen and (max-width: 767px) {
  .blog_wrapper .blog_thumb a {
    width: 100%;
  }
}
@media only screen and (max-width: 767px) {
  .blog_wrapper .blog_thumb a img {
    width: 100%;
  }
}
.blog_wrapper .blog_content {
  padding-top: 22px;
  text-align: left;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .blog_wrapper .blog_content {
    padding-top: 26px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_wrapper .blog_content {
    padding-top: 25px;
  }
}
@media only screen and (max-width: 767px) {
  .blog_wrapper .blog_content {
    padding-top: 20px;
  }
}
.blog_wrapper .blog_content h3 {
  font-size: 27px;
  line-height: 36px;
  font-weight: 600;
  padding: 0;
  margin-bottom: 2px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .blog_wrapper .blog_content h3 {
    font-size: 18px;
    line-height: 22px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_wrapper .blog_content h3 {
    font-size: 17px;
    line-height: 24px;
  }
}
@media only screen and (max-width: 767px) {
  .blog_wrapper .blog_content h3 {
    font-size: 17px;
    line-height: 24px;
  }
}
.blog_wrapper .blog_content h3::before {
  display: none;
}
.blog_wrapper .blog_meta {
  margin-bottom: 17px;
}
@media only screen and (max-width: 767px) {
  .blog_wrapper .blog_meta {
    margin-bottom: 13px;
  }
}
.blog_wrapper .blog_meta span {
  font-size: 14px;
  line-height: 24px;
}
.blog_wrapper .blog_meta span a {
  color: #1D1678;
}
.blog_wrapper .blog_meta span a:hover {
  text-decoration: underline;
}
.blog_wrapper .blog_meta span.author {
  margin-right: 8px;
}
.blog_wrapper .blog_meta span.author a {
  margin-right: 5px;
}
.blog_wrapper .blog_desc {
  margin-bottom: 25px;
}
@media only screen and (max-width: 767px) {
  .blog_wrapper .blog_desc {
    margin-bottom: 20px;
  }
}
.blog_wrapper .blog_desc p {
  font-size: 14px;
  line-height: 24px;
  margin-bottom: 0;
}

.blog_bidio .blog_content {
  padding-top: 16px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .blog_bidio .blog_content {
    padding-top: 19px;
  }
}
@media only screen and (max-width: 767px) {
  .blog_bidio .blog_content {
    padding-top: 13px;
  }
}

.readmore_button a {
  height: 38px;
  line-height: 40px;
  background: #1D1678;
  border: 0;
  color: #fff;
  display: block;
  text-align: center;
  padding: 0 20px;
  font-size: 12px;
  text-transform: uppercase;
  font-weight: 600;
  font-style: normal;
  border-radius: 3px;
  max-width: 170px;
}
.readmore_button a:hover {
  background: #242424;
}
@media only screen and (max-width: 767px) {
  .readmore_button a {
    max-width: 130px;
  }
}

.blog_sidebar_widget {
  background: #f8f8f8;
  border: 1px solid #ebebeb;
  padding: 57px 20px 54px 20px;
  border-radius: 4px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_sidebar_widget {
    margin-bottom: 60px;
  }
}
@media only screen and (max-width: 767px) {
  .blog_sidebar_widget {
    margin-bottom: 60px;
  }
}
.blog_sidebar_widget .widget_list > h3 {
  font-size: 20px;
  line-height: 20px;
  font-weight: 600;
  margin-bottom: 20px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .blog_sidebar_widget .widget_list > h3 {
    font-size: 18px;
  }
}
.blog_sidebar_widget .widget_list.comments .post_thumb a img {
  border-radius: 50%;
}
.blog_sidebar_widget .widget_list.comments .post_info span a {
  color: #1D1678;
}
.blog_sidebar_widget .widget_categories ul li a {
  margin-left: 0;
}

.widget_search input {
  height: 35px;
  border: 1px solid #ebebeb;
  background: #fff;
  color: #242424;
  width: 100%;
  margin-bottom: 20px;
  padding: 0 15px;
}
.widget_search button {
  color: #fff;
  display: inline-block;
  background: #242424;
  border: none;
  padding: 0 20px;
  height: 34px;
  line-height: 35px;
  text-transform: uppercase;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  -webkit-transition: .3s;
  transition: .3s;
  border-radius: 3px;
}
.widget_search button:hover {
  background: #1D1678;
}

.tag_widget ul li {
  display: inline-block;
}
.tag_widget ul li a {
  margin: 0 6px 5px 0;
  display: block;
  font-size: 12px;
  font-weight: 400;
  border: 1px solid #ebebeb;
  background: #fff;
  padding: 0 15px;
  line-height: 29px;
  border-radius: 3px;
}
.tag_widget ul li a:hover {
  background: #1D1678;
  border-color: #1D1678;
  color: #fff;
}

.post_thumb {
  width: 55px;
  float: left;
  margin-right: 10px;
}

.post_wrapper {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  padding-bottom: 15px;
  border-bottom: 1px solid #ddd;
  margin-bottom: 15px;
}
.post_wrapper:last-child {
  padding-bottom: 0;
  margin-bottom: 0;
  border-bottom: 0;
}

.post_info h3 {
  font-size: 14px;
  font-weight: 600;
  text-transform: capitalize;
  line-height: 14px;
  margin-bottom: 5px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .post_info h3 {
    font-size: 13px;
  }
}
.post_info h3 a:hover {
  color: #1D1678;
}
.post_info span {
  font-size: 12px;
}

.blog_categories ul li {
  border-top: 1px solid #ddd;
}
.blog_categories ul li a {
  padding: 10px 0;
  text-transform: capitalize;
  display: inline-block;
  margin-left: 0;
}
.blog_categories ul li a:hover {
  color: #1D1678;
}
.blog_categories ul li:last-child a {
  padding-bottom: 0;
}

.shipping_area.shipping_contact.blog_shipping {
  margin-top: 94px;
}

.blog_pagination {
  margin-bottom: 60px;
}
.blog_pagination .pagination {
  border: 1px solid #ebebeb;
  justify-content: center;
  padding: 10px 0;
}
@media only screen and (max-width: 767px) {
  .blog_pagination .pagination {
    margin-top: 0;
  }
}

/*blog page css end*/
/*blog fullwidth css here*/
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .blog_fullwidth {
    margin-bottom: 0;
  }
}
.blog_fullwidth .blog_thumb iframe {
  height: 550px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .blog_fullwidth .blog_thumb iframe {
    height: 440px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_fullwidth .blog_thumb iframe {
    height: 440px;
  }
}
@media only screen and (max-width: 767px) {
  .blog_fullwidth .blog_thumb iframe {
    height: 200px;
  }
}

.blog_thumb_active:hover .owl-nav > div {
  left: 20px;
  opacity: 1;
  visibility: visible;
}
.blog_thumb_active:hover .owl-nav > div.owl-next {
  right: 20px;
}
.blog_thumb_active .owl-nav > div {
  position: absolute;
  top: 50%;
  transform: translatey(-50%);
  background: rgba(0, 99, 209, 0.6);
  width: 30px;
  height: 30px;
  line-height: 30px;
  font-size: 20px;
  color: #fff;
  text-align: center;
  border-radius: 50%;
  left: 40px;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  opacity: 0;
  visibility: hidden;
}
.blog_thumb_active .owl-nav > div.owl-next {
  right: 40px;
  left: auto;
}

.blog_aduio_icone {
  margin-bottom: 14px;
  margin-top: 23px;
}
@media only screen and (max-width: 767px) {
  .blog_aduio_icone {
    margin-bottom: 11px;
    margin-top: 16px;
  }
}
.blog_aduio_icone audio {
  width: 100%;
}

@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_reverse .row {
    flex-direction: column-reverse;
  }
}
@media only screen and (max-width: 767px) {
  .blog_reverse .row {
    flex-direction: column-reverse;
  }
}

@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_wrapper_sidebar .row {
    flex-direction: row;
  }
}
@media only screen and (max-width: 767px) {
  .blog_wrapper_sidebar .row {
    flex-direction: row;
  }
}

@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .blog_nosidebar {
    margin-bottom: 0;
  }
}
.blog_nosidebar .single_blog {
  overflow: hidden;
}
.blog_nosidebar .single_blog_gallery {
  overflow: hidden;
}
.blog_nosidebar .blog_thumb {
  float: left;
  width: 30%;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_nosidebar .blog_thumb {
    width: 35%;
  }
}
@media only screen and (max-width: 767px) {
  .blog_nosidebar .blog_thumb {
    width: 100%;
  }
}
.blog_nosidebar .blog_thumb_active {
  float: left;
  width: 30%;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_nosidebar .blog_thumb_active {
    width: 35%;
  }
}
@media only screen and (max-width: 767px) {
  .blog_nosidebar .blog_thumb_active {
    width: 100%;
  }
}
.blog_nosidebar .blog_content {
  float: left;
  width: 70%;
  padding-top: 0;
  padding-left: 25px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_nosidebar .blog_content {
    width: 65%;
  }
}
@media only screen and (max-width: 767px) {
  .blog_nosidebar .blog_content {
    width: 100%;
    padding-left: 0;
    padding-top: 20px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_nosidebar .blog_content h3 {
    line-height: 20px;
    margin-bottom: 9px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_nosidebar .blog_meta {
    margin-bottom: 9px;
  }
}

/* 12. blog details css here */
.post_header {
  margin-bottom: 28px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .post_header {
    margin-bottom: 25px;
  }
}
@media only screen and (max-width: 767px) {
  .post_header {
    margin-bottom: 22px;
  }
}
.post_header h3 {
  font-size: 35px;
  line-height: 35px;
  font-weight: 600;
  margin-bottom: 15px;
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .post_header h3 {
    font-size: 30px;
    line-height: 30px;
    margin-bottom: 13px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .post_header h3 {
    font-size: 25px;
    line-height: 25px;
    margin-bottom: 12px;
  }
}
@media only screen and (max-width: 767px) {
  .post_header h3 {
    font-size: 20px;
    line-height: 22px;
    margin-bottom: 12px;
  }
}

.blog_details {
  margin-bottom: 60px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_details {
    margin-top: 57px;
    margin-bottom: 0;
  }
}
@media only screen and (max-width: 767px) {
  .blog_details {
    margin-top: 58px;
    margin-bottom: 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_details .blog_sidebar {
    margin-bottom: 0;
  }
}
@media only screen and (max-width: 767px) {
  .blog_details .blog_sidebar {
    margin-bottom: 0;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .blog_details .blog_wrapper {
    margin-bottom: 60px;
  }
}
@media only screen and (max-width: 767px) {
  .blog_details .blog_wrapper {
    margin-bottom: 60px;
  }
}
.blog_details .blog_meta {
  margin-bottom: 0;
}
.blog_details .blog_thumb::before {
  display: none;
}
.blog_details .post_content > p {
  line-height: 24px;
  margin-bottom: 10px;
  font-size: 15px;
}
@media only screen and (max-width: 767px) {
  .blog_details .post_content > p {
    font-size: 14px;
  }
}
.blog_details .post_content blockquote {
  margin: 31px 0 31px 40px;
  font-style: italic;
  padding: 30px 45px;
  background: #f6f6f6;
  border: 1px solid #ebebeb;
  border-left: 4px solid #1D1678;
}
.blog_details .post_content blockquote p {
  font-size: 16px;
}
@media only screen and (max-width: 767px) {
  .blog_details .post_content blockquote p {
    font-size: 15px;
  }
}
@media only screen and (max-width: 767px) {
  .blog_details .post_content blockquote {
    margin: 23px 0 23px 0;
    padding: 20px 12px 15px;
  }
}
.blog_details .social_sharing {
  display: flex;
  align-items: center;
}
.blog_details .social_sharing p {
  font-size: 14px;
  text-transform: capitalize;
  margin-right: 20px;
  margin-bottom: 0;
  line-height: 20px;
  font-weight: 700;
}
@media only screen and (max-width: 767px) {
  .blog_details .social_sharing p {
    font-size: 13px;
    margin-right: 10px;
  }
}
.blog_details .social_sharing ul li {
  display: inline-block;
}
.blog_details .social_sharing ul li a {
  background: #e6e6e6;
  border-radius: 100%;
  display: inline-block;
  font-size: 12px;
  height: 26px;
  line-height: 26px;
  margin-right: 5px;
  text-align: center;
  width: 26px;
}
.blog_details .social_sharing ul li a:hover {
  color: #ffffff;
  background: #1D1678;
}
@media only screen and (max-width: 767px) {
  .blog_details .social_sharing ul li a {
    margin-right: 2px;
  }
}
.blog_details .social_sharing ul li:first-child a {
  padding-left: 0;
  border-left: 0;
}

.entry_content {
  padding-bottom: 26px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
@media only screen and (max-width: 767px) {
  .entry_content {
    flex-direction: column;
    text-align: left;
    align-items: inherit;
  }
}
.entry_content .post_meta {
  margin-bottom: 0;
}
@media only screen and (max-width: 767px) {
  .entry_content .post_meta {
    margin-bottom: 10px;
  }
}
.entry_content .post_meta span {
  font-weight: 700;
}
.entry_content .post_meta span:hover {
  color: #1D1678;
}

.comments_box {
  margin-bottom: 54px;
}
.comments_box h3 {
  font-size: 20px;
  margin: 0 0 20px;
  font-weight: 600;
  line-height: 28px;
}

.comment_list {
  overflow: hidden;
  margin-bottom: 30px;
}
.comment_list:last-child {
  margin-bottom: 0;
}
.comment_list .comment_thumb {
  display: inline-block;
}
@media only screen and (max-width: 767px) {
  .comment_list .comment_thumb {
    width: 40px;
  }
}
.comment_list .comment_content {
  margin-left: 70px;
  position: relative;
  border: 1px solid #ebebeb;
  border-radius: 3px;
  padding: 15px;
}
@media only screen and (max-width: 767px) {
  .comment_list .comment_content {
    margin-left: 55px;
  }
}
.comment_list .comment_content h5 {
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  margin-bottom: 5px;
}
.comment_list .comment_content h5 a:hover {
  color: #1D1678;
}
.comment_list .comment_content span {
  line-height: 18px;
  margin-bottom: 8px;
  font-size: 13px;
  font-style: italic;
  display: inline-block;
}
.comment_list .comment_content p {
  margin-bottom: 0;
  font-size: 14px;
}

.comment_reply {
  position: absolute;
  top: 20px;
  right: 12px;
}
@media only screen and (max-width: 767px) {
  .comment_reply {
    top: 15px;
  }
}
.comment_reply a {
  padding: 2px 10px;
  border-radius: 3px;
  color: #fff;
  background: #242424;
  display: block;
}
.comment_reply a:hover {
  background: #1D1678;
}

.comments_form h3 {
  font-size: 20px;
  margin: 0 0 20px;
  font-weight: 600;
  line-height: 28px;
}
.comments_form p {
  font-size: 14px;
  line-height: 17px;
  margin-bottom: 12px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .comments_form form .row {
    flex-direction: row;
  }
}
.comments_form form label {
  font-size: 14px;
  line-height: 20px;
  font-weight: 600;
  margin-bottom: 10px;
}
.comments_form form textarea {
  width: 100%;
  height: 200px;
  background: #ffffff;
  border: 1px solid #ebebeb;
  margin-bottom: 10px;
  resize: none;
  padding: 10px;
}
.comments_form form input {
  width: 100%;
  height: 40px;
  border: 1px solid #ebebeb;
  margin-bottom: 15px;
  padding: 0 20px;
}
.comments_form form button {
  border: 0;
  line-height: 36px;
  background: #242424;
  font-weight: 600;
}
.comments_form form button:hover {
  background: #1D1678;
}
@media only screen and (max-width: 767px) {
  .comments_form form button {
    line-height: 38px;
    height: 38px;
    padding: 0 10px;
  }
}

.comment_list.list_two {
  padding-left: 50px;
}
@media only screen and (max-width: 767px) {
  .comment_list.list_two {
    padding-left: 0;
  }
}

.related_posts {
  border-top: 1px solid #ebebeb;
  padding: 54px 0 50px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .related_posts {
    padding: 54px 0 22px;
  }
}
@media only screen and (max-width: 767px) {
  .related_posts {
    padding: 53px 0 24px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .related_posts .row {
    flex-direction: row !important;
  }
}
.related_posts h3 {
  font-size: 20px;
  margin: 0 0 20px;
  font-weight: 600;
  line-height: 28px;
}

.related_thumb {
  margin-bottom: 15px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .related_thumb img {
    width: 100%;
  }
}
@media only screen and (max-width: 767px) {
  .related_thumb img {
    width: 100%;
  }
}

.related_content {
  text-align: center;
}
.related_content h4 {
  font-size: 16px;
  font-weight: 600;
  line-height: 19px;
  margin-bottom: 0;
}
.related_content h4 a {
  color: #242424;
}
.related_content h4 a:hover {
  color: #1D1678;
}
.related_content span {
  font-size: 13px;
  line-height: 17px;
}
.related_content span i {
  margin-right: 3px;
}
.related_content .blog_meta {
  margin-bottom: 10px;
}
.related_content .blog_meta span {
  font-size: 12px;
  line-height: 22px;
}

@media only screen and (min-width: 768px) and (max-width: 991px) {
  .single_related {
    margin-bottom: 28px;
  }
}
@media only screen and (max-width: 767px) {
  .single_related {
    margin-bottom: 25px;
  }
}

/*blog details css end*/
/*  24. modal css here */
.modal-dialog.modal-dialog-centered {
  min-width: 1100px;
}
@media only screen and (min-width: 1200px) and (max-width: 1600px) {
  .modal-dialog.modal-dialog-centered {
    min-width: 1000px;
  }
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .modal-dialog.modal-dialog-centered {
    min-width: 950px;
  }
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .modal-dialog.modal-dialog-centered {
    min-width: 730px;
  }
}
@media only screen and (max-width: 767px) {
  .modal-dialog.modal-dialog-centered {
    min-width: 90%;
  }
}

.modal_tab_img {
  text-align: center;
  margin-bottom: 10px;
}
.modal_tab_img img {
  margin: 0 auto;
}

.modal_tab_button ul li a {
  padding: 0;
  border: 1px solid #ebebeb;
  margin: 0 2px;
}
.modal_tab_button ul li a img {
  width: 100%;
}

.modal_title h2 {
  font-size: 16px;
  text-transform: uppercase;
  font-weight: 600;
  margin-bottom: 14px;
  line-height: 26px;
}

.modal_social h2 {
  font-size: 16px;
  text-transform: uppercase;
  font-weight: 600;
  margin-bottom: 15px;
  line-height: 20px;
}
.modal_social ul li {
  display: inline-block;
  margin-right: 3px;
}
.modal_social ul li a {
  text-transform: uppercase;
  display: inline-block;
  width: 38px;
  height: 38px;
  text-align: center;
  line-height: 38px;
  border-radius: 50%;
  font-size: 15px;
  color: #ffffff;
  font-weight: 400;
}
.modal_social ul li.facebook a {
  background: #3c5b9b;
}
.modal_social ul li.facebook a:hover {
  background: #1D1678;
}
.modal_social ul li.twitter a {
  background: #1DA1F2;
}
.modal_social ul li.twitter a:hover {
  background: #1D1678;
}
.modal_social ul li.pinterest a {
  background: #BD081B;
}
.modal_social ul li.pinterest a:hover {
  background: #1D1678;
}
.modal_social ul li.google-plus a {
  background: #DC5043;
}
.modal_social ul li.google-plus a:hover {
  background: #1D1678;
}
.modal_social ul li.linkedin a {
  background: #010103;
}
.modal_social ul li.linkedin a:hover {
  background: #1D1678;
}

.modal_price {
  margin-bottom: 12px;
}
.modal_price span {
  font-weight: 600;
  color: #1D1678;
  font-size: 16px;
}
.modal_price span.old_price {
  color: #242424;
  font-size: 14px;
  font-weight: 400;
  text-decoration: line-through;
  margin-left: 5px;
}

.modal_description p {
  line-height: 24px;
  font-size: 15px;
  margin: 0;
}

.variants_size h2, .variants_color h2 {
  font-size: 13px;
  font-weight: 600;
  text-transform: uppercase;
  margin-bottom: 7px;
  line-height: 20px;
}
.variants_size.mb-15, .mb-15.variants_color {
  margin-bottom: 24px;
}
.variants_size .select_option, .variants_color .select_option {
  width: 100%;
  border-radius: 0;
  margin-bottom: 25px;
}
.variants_size .select_option .list, .variants_color .select_option .list {
  width: 100%;
  border-radius: 0;
}

.modal_add_to_cart {
  margin-bottom: 25px;
}
.modal_add_to_cart form input {
  width: 95px;
  border: 1px solid #ebebeb;
  background: none;
  padding: 0 10px;
  height: 45px;
}
@media only screen and (max-width: 767px) {
  .modal_add_to_cart form input {
    width: 75px;
  }
}
.modal_add_to_cart form button {
  background: none;
  border: 1px solid #242424;
  margin-left: 10px;
  font-size: 12px;
  font-weight: 700;
  height: 45px;
  width: 230px;
  line-height: 18px;
  padding: 10px 15px;
  text-transform: uppercase;
  background: #242424;
  color: #ffffff;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  cursor: pointer;
}
@media only screen and (max-width: 767px) {
  .modal_add_to_cart form button {
    width: 130px;
  }
}
.modal_add_to_cart form button:hover {
  background: #1D1678;
  color: #ffffff;
  border-color: #1D1678;
}

.modal_body {
  padding: 29px 6px 38px;
}
@media only screen and (max-width: 767px) {
  .modal_body .modal_tab {
    margin-bottom: 60px;
  }
}

.modal-content {
  border-radius: 0;
}

.modal-content button.close {
  position: absolute;
  left: 94%;
  width: 35px;
  height: 35px;
  display: block;
  border: 1px solid #ebebeb;
  top: 10px;
  border-radius: 50%;
  cursor: pointer;
  font-size: 20px;
  z-index: 9;
}
@media only screen and (max-width: 767px) {
  .modal-content button.close {
    left: 83%;
    width: 29px;
    height: 32px;
    top: 4px;
    margin-bottom: 14px;
  }
}
.modal-content button.close:hover {
  color: #1D1678;
}

.modal_add_to_cart.mb-15 {
  margin-bottom: 23px;
}

.modal_description.mb-15 {
  margin-bottom: 20px;
}

.product_navactive.owl-carousel:hover .owl-nav div {
  opacity: 1;
  visibility: visible;
}
.product_navactive.owl-carousel .owl-nav {
  display: block;
}
.product_navactive.owl-carousel .owl-nav div {
  position: absolute;
  background: #f2f2f2;
  border-radius: 3px;
  color: #333;
  height: 32px;
  top: 50%;
  transform: translatey(-50%);
  width: 32px;
  text-align: center;
  line-height: 32px;
  left: -7px;
  font-size: 18px;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  opacity: 0;
  visibility: hidden;
}
.product_navactive.owl-carousel .owl-nav div:hover {
  background: #1D1678;
  color: #ffffff;
}
.product_navactive.owl-carousel .owl-nav div.owl-next {
  right: -7px;
  left: auto;
}

/*modal css end*/
/*  23. newsletter popup css here */
.newletter-popup {
  background: #fff;
  top: 50% !important;
  margin-top: -179px;
  position: fixed !important;
  padding: 50px;
  text-align: center;
  display: none;
}
@media only screen and (max-width: 767px) {
  .newletter-popup {
    padding: 30px 20px;
    width: 95%;
  }
}

#boxes .newletter-title h2 {
  font-size: 30px;
  text-transform: uppercase;
  margin: 0 0 30px;
}
@media only screen and (max-width: 767px) {
  #boxes .newletter-title h2 {
    font-size: 22px;
    margin: 0 0 10px;
  }
}

#boxes .box-content label {
  font-weight: 400;
  font-size: 14px;
}

#boxes .box-content .newletter-label {
  width: 70%;
  margin-bottom: 36px;
}
@media only screen and (max-width: 767px) {
  #boxes .box-content .newletter-label {
    width: 100%;
  }
}

#frm_subscribe form {
  width: 340px;
  margin: 0 auto;
  position: relative;
}
@media only screen and (max-width: 767px) {
  #frm_subscribe form {
    width: 100%;
  }
}
#frm_subscribe form input {
  background: #EBEBEB;
  padding: 0 127px 0 20px;
  height: 45px;
  border: 0;
  width: 100%;
  color: #747474;
  margin-bottom: 0;
}
@media only screen and (max-width: 767px) {
  #frm_subscribe form input {
    padding: 0 104px 0 20px;
  }
}
#frm_subscribe form a.theme-btn-outlined {
  position: absolute;
  top: 0;
  right: 0;
  height: 100%;
  width: 110px;
  background: #242424;
  cursor: pointer;
  color: #ffffff;
  text-transform: uppercase;
  font-size: 12px;
  font-weight: 600;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  line-height: 45px;
}
#frm_subscribe form a.theme-btn-outlined:hover {
  background: #1D1678;
}
@media only screen and (max-width: 767px) {
  #frm_subscribe form a.theme-btn-outlined {
    width: 90px;
  }
}

#boxes .box-content .subscribe-bottom {
  margin-top: 20px;
}

#boxes .box-content .subscribe-bottom label {
  margin: 0;
  font-size: 13px;
}

#boxes .box-content .subscribe-bottom #newsletter_popup_dont_show_again {
  display: inline-block;
  margin: 0;
  vertical-align: middle;
}

#boxes #frm_subscribe #notification {
  color: #f00;
}

#boxes #frm_subscribe #notification .success {
  color: #67D7BB;
}

#popup2 {
  position: absolute;
  right: 1px;
  top: 1px;
  text-align: center;
  cursor: pointer;
  font-size: 13px;
  text-transform: capitalize;
  padding: 6px 12px;
  background: #242424;
  font-weight: 600;
  line-height: 17px;
  color: #ffffff;
  display: block;
  transition: 0.3s;
}
#popup2:hover {
  background: #1D1678;
}

/*newsletter popup css end*/
/* 09. error page css here   */
.header_error {
  border-bottom: 1px solid #ebebeb;
}

.error_form {
  text-align: center;
}
.error_form h1 {
  font-size: 200px;
  font-weight: 700;
  color: #1D1678;
  letter-spacing: 10px;
  line-height: 160px;
  margin: 0 0 54px;
}
@media only screen and (max-width: 767px) {
  .error_form h1 {
    font-size: 130px;
    line-height: 120px;
    letter-spacing: 4px;
    margin: 0 0 40px;
  }
}
.error_form h2 {
  font-size: 24px;
  text-transform: uppercase;
  font-weight: 600;
  line-height: 30px;
  margin-bottom: 20px;
}
@media only screen and (max-width: 767px) {
  .error_form h2 {
    font-size: 18px;
    line-height: 22px;
    margin-bottom: 14px;
  }
}
.error_form p {
  font-size: 17px;
  font-weight: 400;
  line-height: 26px;
  margin-bottom: 30px;
}
@media only screen and (max-width: 767px) {
  .error_form p {
    font-size: 14px;
    margin-bottom: 22px;
    line-height: 23px;
  }
}
.error_form form {
  width: 450px;
  margin: 0 auto;
  position: relative;
}
@media only screen and (max-width: 767px) {
  .error_form form {
    width: 100%;
  }
}
.error_form form input {
  padding: 0 60px 0 30px;
  background: #f8f8f8;
  border: 1px solid #ddd;
  color: #242424;
  height: 40px;
  width: 100%;
  border-radius: 3px;
}
.error_form form button {
  position: absolute;
  right: 0;
  height: 100%;
  border: none;
  background: no-repeat;
  font-size: 20px;
  cursor: pointer;
  -webkit-transition: .3s;
  transition: .3s;
  top: 0;
  text-transform: uppercase;
  padding: 0 15px;
  font-weight: 600;
}
.error_form form button:hover {
  color: #1D1678;
}
.error_form a {
  color: #fff;
  display: inline-block;
  background: #1D1678;
  font-size: 12px;
  font-weight: bold;
  height: 40px;
  line-height: 42px;
  padding: 0 30px;
  text-transform: uppercase;
  margin-top: 35px;
  border-radius: 3px;
}
@media only screen and (max-width: 767px) {
  .error_form a {
    padding: 0 20px;
    margin-top: 25px;
  }
}
.error_form a:hover {
  background: #242424;
}

.error_section {
  padding-bottom: 70px;
  padding-top: 61px;
}
@media only screen and (min-width: 768px) and (max-width: 991px) {
  .error_section {
    padding-top: 31px;
  }
}
@media only screen and (max-width: 767px) {
  .error_section {
    padding-bottom: 60px;
    padding-top: 21px;
  }
}

/*404 page css end*/
/*privacy policy css here*/
.privacy_policy_main_area {
  padding: 53px 0 10px;
}
@media only screen and (max-width: 767px) {
  .privacy_policy_main_area {
    padding: 57px 0 6px;
  }
}

.privacy_policy_header {
  text-align: center;
  margin-bottom: 50px;
}
@media only screen and (max-width: 767px) {
  .privacy_policy_header {
    margin-bottom: 53px;
  }
}
.privacy_policy_header h1 {
  font-size: 42px;
  line-height: 45px;
  font-weight: 600;
  margin-bottom: 0;
}
@media only screen and (max-width: 767px) {
  .privacy_policy_header h1 {
    font-size: 25px;
    line-height: 25px;
  }
}

.privacy_content {
  margin-bottom: 44px;
}
@media only screen and (max-width: 767px) {
  .privacy_content {
    margin-bottom: 46px;
  }
}
.privacy_content h2 {
  font-size: 25px;
  line-height: 33px;
  font-weight: 600;
}
@media only screen and (max-width: 767px) {
  .privacy_content h2 {
    font-size: 18px;
    line-height: 26px;
  }
}
.privacy_content h3 {
  font-size: 21px;
  line-height: 28px;
  font-weight: 600;
  margin-bottom: 10px;
}
@media only screen and (max-width: 767px) {
  .privacy_content h3 {
    font-size: 18px;
    line-height: 24px;
  }
}
.privacy_content p {
  font-size: 16px;
  line-height: 29px;
  margin-bottom: 15px;
}
@media only screen and (max-width: 767px) {
  .privacy_content p {
    font-size: 15px;
    line-height: 28px;
  }
}
.privacy_content p a {
  color: #a43d21;
}
.privacy_content p a:hover {
  color: #1D1678;
}
.privacy_content.section_1 h2 {
  margin-bottom: 14px;
}
@media only screen and (max-width: 767px) {
  .privacy_content.section_1 h2 {
    margin-bottom: 9px;
  }
}
.privacy_content.section_2 h2 {
  margin-bottom: 20px;
}
@media only screen and (max-width: 767px) {
  .privacy_content.section_2 h2 {
    margin-bottom: 16px;
  }
}
.privacy_content.section_3 h2 {
  margin-bottom: 18px;
}
@media only screen and (max-width: 767px) {
  .privacy_content.section_3 h2 {
    margin-bottom: 12px;
  }
}

/*privacy policy css end*/

/*# sourceMappingURL=style.css.map */


</style>


	<br>		
<div class="checkout_form">
				<div class="row">
					<div class="col-lg-6 col-md-6">
						 <form  method="post" enctype="multipart/form-data" role="form">
                            <h3>Car Information</h3>
							 <div class="row">

                                <div class="col-lg-6 mb-20">
							
							      <label>Car Model </label>
								<input id="model" input type="text" class="form-control" placeholder="Car's Model">
								
								<label>Car No</label>
								<input id="carno" input type="text" class="form-control" placeholder="Car's No">
								
								<label>Passenger Capacity</label>
								<input id="passenger" input type="text" class="form-control" placeholder="passenger capacity">
								
								<label>Pick-Up*</label>
									<input type="date" id="pickup" class="form-control" name="pickup"/>
									
									<label>Return*</label>
									<input type="date" id="return" class="form-control" name="return"/>
									
								<label>Total Rent</label>
								<input id="price" input type="price" placeholder="Rent">
								</div>
								</div>
							</form>
							
						</div>
				
					<div class="col-lg-6 col-md-6">
						<form  method="post" enctype="multipart/form-data" role="form">    
                            <h3>Book Now</h3>
							
								<form>
							        <label>  Email*</label>
									<input type="text" placeholder="Enter Your Email" class="form-control">
									
									<label>First Name*</label>
									<input type="text" placeholder=" Enter Your First Name " class="form-control">
									
									
									
									<label>Last Name*</label>
									<input type="text" placeholder="Enter Your Last Name " class="form-control">
									
									<label> Address*</label>
									<input type="text" placeholder=" Enter Your Address" class="form-control">
									
									
									
									
									<label>License*</label>
									<input type="file" class="form-control">
									
									<label>Aadhaar Card*</label>
									<input type="file" class="form-control">
								
								
									<label>Pin Code*</label>
									<input type="text" placeholder="Pin Code " class="form-control">
									
									
									
										 <label for="countru_name">City*</label><br> 
									<select class="niceselect_option form-control">
										<option>City</option>
										<option value="Ahmedabad"> Ahmedabad </option>
										<option value="Surat"> Surat </option>
										<option value="Vadodara"> Vadodara </option>
										<option value="Anand"> Dahod </option>
										<option value="Gandhinagar"> Gandhinagar </option>
										<option value="Rajkot"> Rajkot </option>
									</select>
									
									
									<label>Mobile No* </label>
									<input type="text" placeholder="Enter Your Mobile " class="form-control">
									
								</form><br>
								<div class="order_button">
                                    <button  type="submit">Book Car</button> 
                                </div> 
							</div>
						</div>
					</div>

				</div>
			</div>
			 <?php
    include_once('footer.php');
?>