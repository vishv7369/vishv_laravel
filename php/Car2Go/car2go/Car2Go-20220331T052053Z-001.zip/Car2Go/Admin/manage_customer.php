<?php 
include_once('header.php');
?>


      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Manage Customer
          
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Manage Customer</a></li>
            <li class="active">Manage Customer</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Manage Customer</h3>
                </div><!-- /.box-header -->
                <div class="box-body" style="overflow-x:auto;">
                  <table id="example2" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                         <tr>
                        <th>Customer_id</th>
                        <th>Profile_img</th>
						<th>Name</th>
                        
						 <th>Username</th>
						 <th>Password</th>
						 <th>Gender</th>
                        <th>Email</th>
                        <th>Address</th>
						<th>Pin_code</th>
						<th>City</th>
						<th>License</th>
						<th>Adhaarcard</th>
						<th>Mobile_no</th>
						<th>Created_dt/Updated_dt</th>
						<th>Delete</th>
						<th>status</th>
						
                      </tr>
                    </thead>
                    <tbody>
                       <?php
					  foreach($customer_arr as $data)
					  {
						?>
                            <tr>
							<td><?php echo $data->Customer_id?></td>
							<td><img src="../CAR/upload/customer/<?php echo $data->Profile_img?>" width="50px" height="50px"></td>
							<td><?php echo $data->Name?></td>
							
							<td><?php echo $data->Username?></td>
							<td><?php echo $data->Password?></td>
							
							<td><?php echo $data->Gender?></td>
							<td><?php echo $data->Email?></td>
							<td><?php echo $data->Address?></td>
							<td><?php echo $data->Pin_code?></td>
							<td><?php echo $data->City?></td>
							<td><?php echo $data->License?></td>
							<td><?php echo $data->Adhaarcard?></td>
							<td><?php echo $data->Mobile_no?></td>
							<td><?php echo $data->Created_dt?>/<?php echo $data->Updated_dt?></td>
						<td><a href="delete?del_Customer_id=<?php echo $data->Customer_id?>" class="btn btn-danger">Delete</a></td>
						<td><a href="status?status_Customer_id=<?php echo $data->Customer_id?>" class="btn btn-primary"><?php echo $data->status?></a></a></td>
                      	
                            </tr>	
                       <?php							
					  }
					  ?>
                    </tbody>
                    
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
    <?php
	include_once('footer.php');
	?>