 	
<?php $__env->startSection('main_container'); ?>
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">
					
					<div class="row">
						<div class="col-md-8 offset-md-2">
								
							<!-- Register Content -->
							<div class="account-content">
								<div class="row align-items-center justify-content-center">
									<div class="col-md-7 col-lg-6 login-left">
										<img src="<?php echo e(url('Frontend/assets/img/login-banner.png')); ?>" class="img-fluid" alt="Doccure Register">	
									</div>
									<div class="col-md-12 col-lg-6 login-right">
										<div class="login-header">
											<h3>Patient Register <a href="<?php echo e(url('/doctor-register')); ?>">Are you a Doctor?</a></h3>
										</div>
										
										<!-- Register Form -->
										<form action="<?php echo e(url('/register')); ?>" method="post" enctype="multipart/form-data">
											<?php echo csrf_field(); ?>
											<div class="form-group form-focus">
												<input type="text" class="form-control floating" value="<?php echo e(old('name')); ?>" name="name">
												
												<label class="focus-label">Name</label>
												<?php if($errors->has('name')): ?>
            										<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
       											<?php endif; ?>
											</div>
											<div class="form-group form-focus">
												<input type="text" class="form-control floating" value="<?php echo e(old('email')); ?>" name="email">
												<label class="focus-label">Email</label>
												<?php if($errors->has('email')): ?>
            										<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
       											<?php endif; ?>
											</div>
											<div class="form-group form-focus">
												<input type="text" class="form-control floating" value="<?php echo e(old('mobileno')); ?>" name="mobileno">
												<label class="focus-label">Mobile no</label>
												<?php if($errors->has('mobileno')): ?>
            										<span class="text-danger"><?php echo e($errors->first('mobileno')); ?></span>
       											<?php endif; ?>
											</div>
											<div class="form-group form-focus">
												<select class="form-control floating" name="gender">
													<option value="">Select Gender</option>
													<option value="Male">Male</option>
													<option value="Female">Female</option>
												</select>
												<?php if($errors->has('gender')): ?>
            										<span class="text-danger"><?php echo e($errors->first('gender')); ?></span>
       											<?php endif; ?>
												<label class="focus-label">Gender</label>
												
											</div>
											<div class="form-group form-focus">
												<input type="password" class="form-control floating" value="<?php echo e(old('password')); ?>" name="password">
												<label class="focus-label">Create Password</label>
												<?php if($errors->has('password')): ?>
            										<span class="text-danger"><?php echo e($errors->first('password')); ?></span>
       											<?php endif; ?>
											</div>
											<div class="text-right">
												<a class="forgot-link" href="<?php echo e(url('/login')); ?>">Already have an account?</a>
											</div>
											<button class="btn btn-primary btn-block btn-lg login-btn" type="submit" name="submit" value="send">Signup</button>
											
											
										</form>
										<!-- /Register Form -->
										
									</div>
								</div>
							</div>
							<!-- /Register Content -->
								
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<?php $__env->stopSection(); ?>	
		   
		</div>
		<!-- /Main Wrapper -->
	 
	  
		<!-- jQuery -->
		<script src="<?php echo e(url('Frontend/assets/js/jquery.min.js')); ?>"></script>
		
		<!-- Bootstrap Core JS -->
		<script src="<?php echo e(url('Frontend/assets/js/popper.min.js')); ?>"></script>
		<script src="<?php echo e(url('Frontend/assets/js/bootstrap.min.js')); ?>"></script>
		
		<!-- Custom JS -->
		<script src="<?php echo e(url('Frontend/assets/js/script.js')); ?>"></script>
		
		
	</body>

<!-- doccure/<?php echo e(url('/login')); ?>  30 Nov 2019 04:12:20 GMT -->
</html>

<?php echo $__env->make('patient.Layout.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mohini\ADMP\resources\views/patient/register.blade.php ENDPATH**/ ?>