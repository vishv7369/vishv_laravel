 	
<?php $__env->startSection('main_container'); ?>
			
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<h3 class="page-title">List of Doctors</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
									<li class="breadcrumb-item"><a href="javascript:(0);">Users</a></li>
									<li class="breadcrumb-item active">Doctor</li>
								</ul>
								
							</div>
							<?php if(session()->has('success')): ?>
												
									<i class="alert alert-success"><?php echo e(session('success')); ?></i>
												
								<?php endif; ?>
						</div>
						
					</div>
					<!-- /Page Header -->
					
					<div class="row">
						<div class="col-sm-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="table" class=" table table-hover table-center mb-0">
											<thead>
												<tr>
													<th>Doctor ID</th>
													<th>Profile Img</th>
													<th>Specialist</th>
													<th>First Name</th>
													<th>Last Name</th>
												    <th class="text-right">Actions</th>
													
													
												</tr>
											</thead>
											<tbody>
												<?php
													foreach($doctor_arr as $data) 
													{
												?>
												<tr>
												<td><?php echo $data->id?></td>
												<td><img src="<?php echo e(asset('upload/doctor/' . $data->profile_img)); ?>" height="50px" width="50px"/></td>
												<td><?php echo $data->name?></td>
												<td><?php echo $data->first_name?></td>
												<td><?php echo $data->last_name?></td>
												<td class="text-right">
														<div class="actions">
															<a class="btn btn-sm bg-success-light"  href="<?php echo e(url('edit/'.$data->id)); ?>">
																<i class="fe fe-pencil"></i> Edit
															</a>
															<a  href="<?php echo e(url('admin-add-doctor/'. $data->id)); ?>" class="btn btn-sm bg-danger-light">
																<i class="fe fe-trash"></i> Delete
															</a>
														</div>
												</td>
												
												</tr>
												<?php
												}
												?>
												
											
													
													
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>			
					</div>
					
				</div>			
			</div>
			<!-- /Page Wrapper -->
		
        </div>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
        <script src="<?php echo e(url('Backend/assets/js/jquery-3.2.1.min.js')); ?>"></script>

			
		<!-- Bootstrap Core JS -->
        <script src="<?php echo e(url('Backend/assets/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(url('Backend/assets/js/bootstrap.min.js')); ?>"></script>
		
		<!-- Slimscroll JS -->
        <script src="<?php echo e(url('Backend/assets/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>
		
		<!-- Datatables JS -->
		<script src="<?php echo e(url('Backend/assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
		<script src="<?php echo e(url('Backend/assets/plugins/datatables/datatables.min.js')); ?>"></script>
		
		<!-- Custom JS -->
		<script  src="<?php echo e(url('Backend/assets/js/script.js')); ?>"></script>
		
    </body>

<!-- Mirrored from dreamguys.co.in/demo/doccure/admin/<?php echo e(url('/admin-doctor-list')); ?> by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Nov 2019 04:12:51 GMT -->
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.Layout.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mohini\ADMP\resources\views/admin/doctor-list.blade.php ENDPATH**/ ?>