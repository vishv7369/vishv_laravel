<?php echo $__env->make('company.Layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('main_container'); ?>

<?php /**PATH C:\xampp\htdocs\Mohini\ADMP\resources\views/company/Layout/main_layout.blade.php ENDPATH**/ ?>