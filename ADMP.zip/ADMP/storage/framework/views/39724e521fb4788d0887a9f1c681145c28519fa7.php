<?php echo $__env->make('patient.Layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('main_container'); ?>
<?php echo $__env->make('patient.Layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\Mohini\ADMP\resources\views/patient/Layout/main_layout.blade.php ENDPATH**/ ?>