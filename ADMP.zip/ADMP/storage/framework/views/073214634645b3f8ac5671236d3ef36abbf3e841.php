 	
<?php $__env->startSection('main_container'); ?>
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo e(url('/index')); ?>">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Developer</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Developer</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content" >
				<div class="container-fluid" >

					<div class="row" align="center">
						
						<div class="col-md-7 col-lg-8 col-xl-9">
						<br>
							<div class="myclass row row-grid">
							
								<div class="col-md-6 col-lg-4 col-xl-3">
									<div class="card widget-profile pat-widget-profile">
										<div class="card-body">
											<div class="pro-widget-content">
												<div class="profile-info-widget">
												<a href="#" class="booking-doc-img">
														<img src="<?php echo e(url('Frontend/assets/img/specialities/d/mohini.jpeg')); ?>" alt="User Image">
													</a>
													<div class="profile-det-info">
														<h3><a href="">Miss. Mohini Maurya</a></h3>
														
														<div class="patient-details">
															<h5 class="mb-0"></i> mohinimaurya622001@gmail.com</h5>
														</div>
													</div>
												</div>
											</div>
											<div class="patient-info">
												<ul>
													<li>Phone : 9974224366</li>
												</ul>
											</div>
										</div>
									</div>
								</div>

                                <div class="col-md-6 col-lg-4 col-xl-3">
									<div class="card widget-profile pat-widget-profile">
										<div class="card-body">
											<div class="pro-widget-content">
												<div class="profile-info-widget">
												<a href="#" class="booking-doc-img">
														<img src="<?php echo e(url('Frontend/assets/img/specialities/d/vishv.jpeg')); ?>" alt="User Image">
													</a>
													<div class="profile-det-info">
														<h3><a href="">Mr. Vishv Unjiya</a></h3>
														
														<div class="patient-details">
															<h5 class="mb-0"></i> vishvunjiya3058822@gmail.com</h5>
														</div>
													</div>
												</div>
											</div>
											<div class="patient-info">
												<ul>
													<li>Phone : 8264830498</span></li>
												</ul>
											</div>
										</div>
									</div>
								</div>

                                <div class="col-md-6 col-lg-4 col-xl-3">
									<div class="card widget-profile pat-widget-profile">
										<div class="card-body">
											<div class="pro-widget-content">
												<div class="profile-info-widget">
												<a href="#" class="booking-doc-img">
														<img src="<?php echo e(url('Frontend/assets/img/specialities/d/reena.jpeg')); ?>" alt="User Image">
													</a>
													<div class="profile-det-info">
														<h3><a href="">Miss. Reena Valekar</a></h3>
														
														<div class="patient-details">
															<h5 class="mb-0"></i> riyavalekar19@gmail.com</h5>
														</div>
													</div>
												</div>
											</div>
											<div class="patient-info">
												<ul>
													<li>Phone : 7990235200</span></li>	
												</ul>
											</div>
										</div>
									</div>
								</div>
								
						
								
							</div>

						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->

			<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $(".myclass .card").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

   
			<!-- Footer -->
			<footer class="footer">
				
				<!-- Footer Top -->
				<div class="footer-top">
					<div class="container-fluid">
						<div class="row">
							<div class="col-lg-3 col-md-6">
							
								<!-- Footer Widget -->
								<div class="footer-widget footer-about">
									<div class="footer-logo">
										<img src="<?php echo e(url('Frontend/assets/img/footer-logo.png')); ?>" alt="logo">
									</div>
									<div class="footer-about-content">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
										<div class="social-icon">
											<ul>
												<li>
													<a href="#" target="_blank"><i class="fab fa-facebook-f"></i> </a>
												</li>
												<li>
													<a href="#" target="_blank"><i class="fab fa-twitter"></i> </a>
												</li>
												<li>
													<a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
												</li>
												<li>
													<a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
												</li>
												<li>
													<a href="#" target="_blank"><i class="fab fa-dribbble"></i> </a>
												</li>
											</ul>
										</div>
									</div>
								</div>
								<!-- /Footer Widget -->
								
							</div>
							
							<div class="col-lg-3 col-md-6">
							
								<!-- Footer Widget -->
								<div class="footer-widget footer-menu">
									<h2 class="footer-title">For Patients</h2>
									<ul>
										<li><a href="<?php echo e(url('/search')); ?>"><i class="fas fa-angle-double-right"></i> Search for Doctors</a></li>
										<li><a href="<?php echo e(url('/login')); ?>"><i class="fas fa-angle-double-right"></i> Login</a></li>
										<li><a href="<?php echo e(url('/login')); ?>"><i class="fas fa-angle-double-right"></i> Register</a></li>
										<li><a href="<?php echo e(url('/booking')); ?>"><i class="fas fa-angle-double-right"></i> Booking</a></li>
										<li><a href="<?php echo e(url('/patient-dashboard')); ?>"><i class="fas fa-angle-double-right"></i> Patient Dashboard</a></li>
									</ul>
								</div>
								<!-- /Footer Widget -->
								
							</div>
							
							<div class="col-lg-3 col-md-6">
							
								<!-- Footer Widget -->
								<div class="footer-widget footer-menu">
									<h2 class="footer-title">For Doctors</h2>
									<ul>
										<li><a href="<?php echo e(url('/appointments')); ?>"><i class="fas fa-angle-double-right"></i> Appointments</a></li>
										<li><a href="<?php echo e(url('/chat')); ?>"><i class="fas fa-angle-double-right"></i> Chat</a></li>
										<li><a href="<?php echo e(url('/login')); ?>"><i class="fas fa-angle-double-right"></i> Login</a></li>
										<li><a href="<?php echo e(url('/doctor-register')); ?>"><i class="fas fa-angle-double-right"></i> Register</a></li>
										<li><a href="<?php echo e(url('/doctor-dashboard')); ?>"><i class="fas fa-angle-double-right"></i> Doctor Dashboard</a></li>
									</ul>
								</div>
								<!-- /Footer Widget -->
								
							</div>
							
							<div class="col-lg-3 col-md-6">
							
								<!-- Footer Widget -->
								<div class="footer-widget footer-contact">
									<h2 class="footer-title">Contact Us</h2>
									<div class="footer-contact-info">
										<div class="footer-address">
											<span><i class="fas fa-map-marker-alt"></i></span>
											<p> 3556  Beech Street, San Francisco,<br> California, CA 94108 </p>
										</div>
										<p>
											<i class="fas fa-phone-alt"></i>
											+1 315 369 5943
										</p>
										<p class="mb-0">
											<i class="fas fa-envelope"></i>
											doccure@example.com
										</p>
									</div>
								</div>
								<!-- /Footer Widget -->
								
							</div>
							
						</div>
					</div>
				</div>
				<!-- /Footer Top -->
				
				<!-- Footer Bottom -->
                <div class="footer-bottom">
					<div class="container-fluid">
					
						<!-- Copyright -->
						<div class="copyright">
							<div class="row">
								<div class="col-md-6 col-lg-6">
									<div class="copyright-text">
										<p class="mb-0"><a href="templateshub.net">Templates Hub</a></p>
									</div>
								</div>
								<div class="col-md-6 col-lg-6">
								
									<!-- Copyright Menu -->
									<div class="copyright-menu">
										<ul class="policy-menu">
											<li><a href="<?php echo e(url('/term-condition')); ?>">Terms and Conditions</a></li>
											<li><a href="<?php echo e(url('/privacy-policy')); ?>">Policy</a></li>
										</ul>
									</div>
									<!-- /Copyright Menu -->
									
								</div>
							</div>
						</div>
						<!-- /Copyright -->
						
					</div>
				</div>
				<!-- /Footer Bottom -->
				
			</footer>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  
		<!-- jQuery -->
		<script src="<?php echo e(url('Frontend/assets/js/jquery.min.js')); ?>"></script>

		
		
		<!-- Bootstrap Core JS -->
		<script src="<?php echo e(url('Frontend/assets/js/popper.min.js')); ?>"></script>
		<script src="<?php echo e(url('Frontend/assets/js/bootstrap.min.js')); ?>"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="<?php echo e(url('Frontend/assets/plugins/theia-sticky-sidebar/ResizeSensor.js')); ?>"></script>
        <script src="<?php echo e(url('Frontend/assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js')); ?>"></script>
		
		<!-- Custom JS -->
		<script src="<?php echo e(url('Frontend/assets/js/script.js')); ?>"></script>
		
	</body>

<!-- doccure/<?php echo e(url('/my-patients')); ?>  30 Nov 2019 04:12:09 GMT -->
</html>
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('patient.Layout.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mohini\ADMP\resources\views/patient/developer.blade.php ENDPATH**/ ?>