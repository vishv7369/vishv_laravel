 	
<?php $__env->startSection('main_container'); ?>
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo e(url('/index')); ?>">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Appointments</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">Appointments</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">

					<div class="row">
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						
							<!-- Profile Sidebar -->
							<div class="profile-sidebar">
								
								<?php echo $__env->make('doctor/Layout/doctor-widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
								
							</div>
							<!-- /Profile Sidebar -->
							
						</div>
						
						<div class="col-md-7 col-lg-8 col-xl-9">
						
						<div class="card">
								<div class="card-body pt-0">
								
									<!-- Tab Menu -->
									<nav class="user-tabs mb-4">
										<ul class="nav nav-tabs nav-tabs-bottom nav-justified">
											<li class="nav-item">
												<a class="nav-link active" href="#pat_appointments" data-toggle="tab">Pending Appointments</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="#pat_prescriptions" data-toggle="tab">Completed Appointments</a>
											</li>
											
										</ul>
									</nav>
									<!-- /Tab Menu -->
									
									<!-- Tab Content -->
									<div class="tab-content pt-0">
										
										<!-- Appointment Tab -->
										<div id="pat_appointments" class="tab-pane fade show active">
											<div class="card card-table mb-0">
												<div class="card-body">
													<div class="table-responsive">
														<table id="table" class="table table-hover table-center mb-0">
															<thead>
																<tr>
																	<th>Patient</th>
																	<th>Appt Date</th>
																	<th>Comment</th>
																	<th>Status</th>
																	<th></th>
																</tr>
															</thead>
															<tbody>
															<?php
																	foreach($appointments_arr as $data)
																	{
																	?>
																<?php
																	if($data->appointment_status=="Pending")
																	{
																	?>
																<tr>
																	<td>
																		<h2 class="table-avatar">
																		    <?php
																				$ptprofile_img=$data->ptprofile_img;
																				if($ptprofile_img=="null")
																				{
																			?>
																				<a href="<?php echo e(url('/patient-profile')); ?>" class="avatar avatar-sm mr-2">
																					<img class="avatar-img rounded-circle" src="<?php echo e(url('Frontend/assets/img/patients/user.png')); ?>" alt="dammy Image">
																				</a>
																			<?php
																				}
																				else
																				{
																			?>
																				<a href="<?php echo e(url('/patient-profile')); ?>" class="avatar avatar-sm mr-2">
																					<img class="avatar-img rounded-circle" src="<?php echo e(url('upload/patient/'. $data->ptprofile_img)); ?>" alt="User Image">
																				</a>
																			<?php
																				}
																			?>
																			<a href="<?php echo e(url('/doctor-profile')); ?>"><?php echo $data->name?></a>
																		</h2>
																	</td>
																	<td><?php echo $data->date?> <span class="d-block text-info"><?php echo $data->time?></span></td>
																	<td><?php echo $data->comment?> </td>
																	<td><span class="badge badge-pill bg-success-light"><?php echo $data->appointment_status?></span></td>
															
																	<td class="text-right">
																		<div class="table-action">

																		<a href="#" class="btn btn-sm bg-info-light" data-toggle="modal" data-target="#appt_details">
																			<i class="far fa-eye"></i> View
																		</a>
																		<a href="javascript:void(0);" class="btn btn-sm bg-success-light">
																			<i class="fas fa-check"></i> Accept
																		</a>
																		<a href="javascript:void(0);" class="btn btn-sm bg-danger-light">
																			<i class="fas fa-times"></i> Cancel
																		</a>
																		</div>
																	</td>
																	
																	
																	
																</tr>
																<?php
																	}
																	
																	?>
															<?php
															}
															?>
																
																
																
																
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
										<!-- /Appointment Tab -->
										
										<!-- Prescription Tab -->
										<div class="tab-pane fade" id="pat_prescriptions">
											<div class="card card-table mb-0">
												<div class="card-body">
													<div class="table-responsive">
													<table id="table1" class="table table-hover table-center mb-0">
															<thead>
																<tr>
																	<th>Patient</th>
																	<th>Appt Date</th>
																	<th>Comment</th>
																	<th>Status</th>
																	<th></th>
																</tr>
															</thead>
															<tbody>
															<?php
																	foreach($appointments_arr as $data)
																	{
																	?>
																<?php
																	if($data->appointment_status=="Approved")
																	{
																	?>
																<tr>
																	<td>
																		<h2 class="table-avatar">
																		<?php
																				$ptprofile_img=$data->ptprofile_img;
																				if($ptprofile_img=="null")
																				{
																			?>
																				<a href="<?php echo e(url('/patient-profile')); ?>" class="avatar avatar-sm mr-2">
																					<img class="avatar-img rounded-circle" src="<?php echo e(url('Frontend/assets/img/patients/user.png')); ?>" alt="dammy Image">
																				</a>
																			<?php
																				}
																				else
																				{
																			?>
																				<a href="<?php echo e(url('/patient-profile')); ?>" class="avatar avatar-sm mr-2">
																					<img class="avatar-img rounded-circle" src="<?php echo e(url('upload/patient/'. $data->ptprofile_img)); ?>" alt="User Image">
																				</a>
																			<?php
																				}
																			?>
																			<a href="<?php echo e(url('/doctor-profile')); ?>"><?php echo $data->name?></a>
																		</h2>
																	</td>
																	<td><?php echo $data->date?> <span class="d-block text-info"><?php echo $data->time?></span></td>
																	<td><?php echo $data->comment?> </td>
																	<td><span class="badge badge-pill bg-success-light"><?php echo $data->appointment_status?></span></td>
															
																	<td class="text-right">
																		<div class="table-action">

																		<a href="<?php echo e(url('bill_dtview/'.$data->id)); ?>" class="btn btn-sm bg-info-light" data-toggle="modal" data-target="#appt_details">
																			<i class="far fa-eye"></i> View
																		</a>
																		
																		</div>
																	</td>
																	
																	
																	
																</tr>
																<?php
																	}
																	
																	?>
															<?php
															}
															?>
																
																
																
																
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>	<!-- /Prescription Tab -->
								</div>
							</div>
						</div>
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
			
   
			<!-- Footer -->
			<footer class="footer">
				
				<!-- Footer Top -->
				<div class="footer-top">
					<div class="container-fluid">
						<div class="row">
							<div class="col-lg-3 col-md-6">
							
								<!-- Footer Widget -->
								<div class="footer-widget footer-about">
									<div class="footer-logo">
										<img src="<?php echo e(url('Frontend/assets/img/footer-logo.png')); ?>" alt="logo">
									</div>
									<div class="footer-about-content">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
										<div class="social-icon">
											<ul>
												<li>
													<a href="#" target="_blank"><i class="fab fa-facebook-f"></i> </a>
												</li>
												<li>
													<a href="#" target="_blank"><i class="fab fa-twitter"></i> </a>
												</li>
												<li>
													<a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
												</li>
												<li>
													<a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
												</li>
												<li>
													<a href="#" target="_blank"><i class="fab fa-dribbble"></i> </a>
												</li>
											</ul>
										</div>
									</div>
								</div>
								<!-- /Footer Widget -->
								
							</div>
							
							<div class="col-lg-3 col-md-6">
							
								<!-- Footer Widget -->
								<div class="footer-widget footer-menu">
									<h2 class="footer-title">For Patients</h2>
									<ul>
										<li><a href="<?php echo e(url('/search')); ?>"><i class="fas fa-angle-double-right"></i> Search for Doctors</a></li>
										<li><a href="<?php echo e(url('/login')); ?>"><i class="fas fa-angle-double-right"></i> Login</a></li>
										<li><a href="<?php echo e(url('/login')); ?>"><i class="fas fa-angle-double-right"></i> Register</a></li>
										<li><a href="<?php echo e(url('/booking')); ?>"><i class="fas fa-angle-double-right"></i> Booking</a></li>
										<li><a href="<?php echo e(url('/patient-dashboard')); ?>"><i class="fas fa-angle-double-right"></i> Patient Dashboard</a></li>
									</ul>
								</div>
								<!-- /Footer Widget -->
								
							</div>
							
							<div class="col-lg-3 col-md-6">
							
								<!-- Footer Widget -->
								<div class="footer-widget footer-menu">
									<h2 class="footer-title">For Doctors</h2>
									<ul>
										<li><a href="<?php echo e(url('/appointments')); ?>"><i class="fas fa-angle-double-right"></i> Appointments</a></li>
										<li><a href="<?php echo e(url('/chat')); ?>"><i class="fas fa-angle-double-right"></i> Chat</a></li>
										<li><a href="<?php echo e(url('/login')); ?>"><i class="fas fa-angle-double-right"></i> Login</a></li>
										<li><a href="<?php echo e(url('/doctor-register')); ?>"><i class="fas fa-angle-double-right"></i> Register</a></li>
										<li><a href="<?php echo e(url('/doctor-dashboard')); ?>"><i class="fas fa-angle-double-right"></i> Doctor Dashboard</a></li>
									</ul>
								</div>
								<!-- /Footer Widget -->
								
							</div>
							
							<div class="col-lg-3 col-md-6">
							
								<!-- Footer Widget -->
								<div class="footer-widget footer-contact">
									<h2 class="footer-title">Contact Us</h2>
									<div class="footer-contact-info">
										<div class="footer-address">
											<span><i class="fas fa-map-marker-alt"></i></span>
											<p> 3556  Beech Street, San Francisco,<br> California, CA 94108 </p>
										</div>
										<p>
											<i class="fas fa-phone-alt"></i>
											+1 315 369 5943
										</p>
										<p class="mb-0">
											<i class="fas fa-envelope"></i>
											doccure@example.com
										</p>
									</div>
								</div>
								<!-- /Footer Widget -->
								
							</div>
							
						</div>
					</div>
				</div>
				<!-- /Footer Top -->
				
				<!-- Footer Bottom -->
                <div class="footer-bottom">
					<div class="container-fluid">
					
						<!-- Copyright -->
						<div class="copyright">
							<div class="row">
								<div class="col-md-6 col-lg-6">
									<div class="copyright-text">
										<p class="mb-0"><a href="templateshub.net">Templates Hub</a></p>
									</div>
								</div>
								<div class="col-md-6 col-lg-6">
								
									<!-- Copyright Menu -->
									<div class="copyright-menu">
										<ul class="policy-menu">
											<li><a href="<?php echo e(url('/term-condition')); ?>">Terms and Conditions</a></li>
											<li><a href="<?php echo e(url('/privacy-policy')); ?>">Policy</a></li>
										</ul>
									</div>
									<!-- /Copyright Menu -->
									
								</div>
							</div>
						</div>
						<!-- /Copyright -->
						
					</div>
				</div>
				<!-- /Footer Bottom -->
				
			</footer>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
		
		<!-- Appointment Details Modal -->
		<div class="modal fade custom-modal" id="appt_details">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
				<div class="row">
						<div class="col-lg-8 offset-lg-2">
							<div class="invoice-content">
								<div class="invoice-item">
									<div class="row">
										<div class="col-md-6">
											<div class="invoice-logo">
												<img src="<?php echo e(url('Frontend/assets/img/logo.png')); ?>" alt="logo">
											</div>
										</div>
										<div class="col-md-6">
											<p class="invoice-details">
												<strong>Appointment id : <?php echo e($app_data->id); ?></strong> <br>
												<strong>Issued:</strong> <?php echo e($app_data->date); ?>

											</p>
										</div>
									</div>
								</div>
								
								<!-- Invoice Item -->
								<div class="invoice-item">
									<div class="row">
										<div class="col-md-6">
											<div class="invoice-info">
												<strong class="customer-text">Invoice From</strong>
												<p class="invoice-details invoice-details-two">
												
													
													Dr. <?php echo e($doctor_data->first_name); ?> <?php echo e($doctor_data->last_name); ?> <br>
													<?php echo e($doctor_data->address); ?>,<br>
													<?php echo e($doctor_data->city); ?>, <?php echo e($doctor_data->state); ?> <br>
													
															
												</p>
											</div>
										</div>
										<div class="col-md-6">
											<div class="invoice-info invoice-info2">
												<strong class="customer-text">Invoice To</strong>
												<p class="invoice-details">
													<?php echo e($patient_data->name); ?> <br>
													<?php echo e($patient_data->email); ?><br>
													<?php echo e($patient_data->mobileno); ?><br>
												</p>
											</div>
										</div>
									</div>
								</div>
								<!-- /Invoice Item -->
								<br>
								<br>
								<!-- Invoice Item -->
								<div class="invoice-item invoice-table-wrap">
									<div class="row">
										<div class="col-md-12">
											<strong>Patient Reports and Diagnosis</strong>
											<br>
											<br>
											<div class="table-responsive">
												<table class="invoice-table table table-bordered">
													<thead>
														<tr>
															<th class="text-center">problems</th>
															<th class="text-center">diagnosis</th>
															<th class="text-center">care suggestion</th>
															<th class="text-center">reports</th>
														</tr>
													</thead>
													<tbody>
													<?php if(!$diagnoses_data->isEmpty()): ?>
															<?php $__currentLoopData = $diagnoses_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diagnoses_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<tr>
															<td class="text-center"><?php echo e($diagnoses_data->problems); ?></td>
															<td class="text-center"><?php echo e($diagnoses_data->diagnosis); ?></td>
															<td class="text-center"><?php echo e($diagnoses_data->care_suggestion); ?></td>
															<td class="text-center"><?php echo e($diagnoses_data->reports); ?></td>
														</tr>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php else: ?>
														<p class="text-danger mt-2">No data added</p>
														<?php endif; ?>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
								<!-- /Invoice Item -->
								<br>
								<br>
								<!-- Invoice Item -->
								<div class="invoice-item invoice-table-wrap">
									<div class="row">
										<div class="col-md-12">
											<strong>Patient Reports and Diagnosis</strong>
											<br>
											<br>
											<div class="table-responsive">
												<table class="invoice-table table table-bordered">	
													<thead>
														<tr>
															<th class="text-center">medicine name</th>
															<th class="text-center">medicine Quantity</th>
															<th class="text-center">medicine take Days</th>
															<th class="text-center">medicine take Time</th>
															<th class="text-center">medicine dose</th>
														</tr>
													</thead>
													<tbody>
													<?php if(!$prescriptions_data->isEmpty()): ?>
															<?php $__currentLoopData = $prescriptions_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescriptions_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<tr>
															<td class="text-center"><?php echo e($prescriptions_data->medicine_name); ?></td>
															<td class="text-center"><?php echo e($prescriptions_data->medicine_Quantity); ?></td>
															<td class="text-center"><?php echo e($prescriptions_data->medicine_take_Days); ?></td>
															<td class="text-center"><?php echo e($prescriptions_data->medicine_take_Time); ?></td>
															<td class="text-center"><?php echo e($prescriptions_data->medicine_dose); ?></td>
														</tr>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php else: ?>
														<p class="text-danger mt-2">No data added</p>
														<?php endif; ?>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
								<!-- /Invoice Item -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /Appointment Details Modal -->
	  
		
		
		<!-- Bootstrap Core JS -->
		<script src="<?php echo e(url('Frontend/assets/js/popper.min.js')); ?>"></script>
		<script src="<?php echo e(url('Frontend/assets/js/bootstrap.min.js')); ?>"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="<?php echo e(url('Frontend/assets/plugins/theia-sticky-sidebar/ResizeSensor.js')); ?>"></script>
        <script src="<?php echo e(url('Frontend/assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js')); ?>"></script>
		
		<!-- Custom JS -->
		<script src="<?php echo e(url('Frontend/assets/js/script.js')); ?>"></script>
		
	</body>

<!-- doccure/<?php echo e(url('/appointments')); ?>  30 Nov 2019 04:12:09 GMT -->
</html>
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('doctor.Layout.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mohini\ADMP\resources\views/doctor/appointments.blade.php ENDPATH**/ ?>