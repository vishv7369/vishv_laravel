 	
<?php $__env->startSection('main_container'); ?>
			
			
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col">
								<h3 class="page-title"> MR</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
									<li class="breadcrumb-item active">Add MR</li>
								</ul>
							</div>
							<?php if(session()->has('success')): ?>
												
								<i class="alert alert-success"><?php echo e(session('success')); ?></i>
												
							<?php endif; ?>
						</div>
					</div>
					<!-- /Page Header -->
					
					

					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h4 class="card-title">Add MR</h4>
								</div>
								<div class="card-body">
									<form action="<?php echo e(url('/admin-add-mr')); ?>" method="post" enctype="multipart/form-data">
										<?php echo csrf_field(); ?>
										<div class="row">
											<div class="col-xl-6">
												<h4 class="card-title">Personal Details</h4>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Profile Img</label>
													<div class="col-lg-9">
														<input type="file" class="form-control" value="<?php echo e(old('mrprofile_img')); ?>" name="mrprofile_img">
														<?php if($errors->has('mrprofile_img')): ?>
												    		<span class="text-danger"><?php echo e($errors->first('mrprofile_img')); ?></span>
														<?php endif; ?>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">First Name</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" value="<?php echo e(old('first_name')); ?>" name="first_name">
														<?php if($errors->has('first_name')): ?>
												    		<span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
														<?php endif; ?>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Last Name</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" value="<?php echo e(old('last_name')); ?>" name="last_name">
														<?php if($errors->has('last_name')): ?>
												    		<span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
														<?php endif; ?>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Email</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" value="<?php echo e(old('email')); ?>" name="email">
														<?php if($errors->has('email')): ?>
												    		<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
														<?php endif; ?>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Password</label>
													<div class="col-lg-9">
														<input type="password" class="form-control" value="<?php echo e(old('password')); ?>" name="password">
														<?php if($errors->has('password')): ?>
												    		<span class="text-danger"><?php echo e($errors->first('password')); ?></span>
														<?php endif; ?>
													</div>
												</div>
											</div>

											<div class="col-xl-6">
												<h4 class="card-title">Company details</h4>
												<div class="form-group row">
											        <label class="col-lg-3 col-form-label">Company Id</label>
													<div class="col-lg-9">
													<select class="select form-control" value="<?php echo e(old('company_id')); ?>" name="company_id">
															<option value="">Select</option>
															<?php
															foreach($company_id_arr as $data)
															{
															?>
															<option value="<?php echo $data->id;?>">
														        <?php echo $data->company_name ?></option>
															<?php
															}
															?>
														</select>
														<?php if($errors->has('company_id')): ?>
												    		<span class="text-danger"><?php echo e($errors->first('company_id')); ?></span>
														<?php endif; ?>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Company Name</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" value="<?php echo e(old('company_name')); ?>" name="company_name">
														<?php if($errors->has('company_name')): ?>
												    		<span class="text-danger"><?php echo e($errors->first('company_name')); ?></span>
														<?php endif; ?>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Manager Id</label>
													<div class="col-lg-9">
													<select class="select form-control" value="<?php echo e(old('manager_id')); ?>" name="manager_id">
															<option value="">Select</option>
															<?php
															foreach($manager_id_arr as $data)
															{
															?>
															<option value="<?php echo $data->id;?>">
														        <?php echo $data->Manager_name ?></option>
															<?php
															}
															?>
														</select>
														<?php if($errors->has('manager_id')): ?>
												    		<span class="text-danger"><?php echo e($errors->first('manager_id')); ?></span>
														<?php endif; ?>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Visiting Card</label>
													<div class="col-lg-9">
														<input type="file" class="form-control" value="<?php echo e(old('visiting_card')); ?>" name="visiting_card">
														<?php if($errors->has('visiting_card')): ?>
												    		<span class="text-danger"><?php echo e($errors->first('visiting_card')); ?></span>
														<?php endif; ?>
													</div>
												</div>
											</div>
										</div>
										<div class="text-right">
											<button type="submit" class="btn btn-primary" name="submit" value="send">Submit</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
					
				
				</div>			
			</div>
			<!-- /Main Wrapper -->
		
        </div>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
        <script src="<?php echo e(url('Backend/assets/js/jquery-3.2.1.min.js')); ?>"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="<?php echo e(url('Backend/assets/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(url('Backend/assets/js/bootstrap.min.js')); ?>"></script>
		
		<!-- Slimscroll JS -->
        <script src="<?php echo e(url('Backend/assets/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>
		
		<!-- Select2 JS -->
		<script src="<?php echo e(url('Backend/assets/js/select2.min.js')); ?>"></script>
		
		<!-- Custom JS -->
		<script  src="<?php echo e(url('Backend/assets/js/script.js')); ?>"></script>
		
    </body>

<!-- Mirrored from dreamguys.co.in/demo/doccure/admin/<?php echo e(url('/admin-form-horizontal')); ?> by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Nov 2019 04:12:55 GMT -->
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.Layout.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ADMP\resources\views/admin/add-mr.blade.php ENDPATH**/ ?>