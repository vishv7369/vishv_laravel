 	
<?php $__env->startSection('main_container'); ?>
			
			<!-- Breadcrumb -->
			<div class="breadcrumb-bar">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-md-12 col-12">
							<nav aria-label="breadcrumb" class="page-breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="<?php echo e(url('/index')); ?>">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Medicine</li>
								</ol>
							</nav>
							<h2 class="breadcrumb-title">My Medicines</h2>
						</div>
					</div>
				</div>
			</div>
			<!-- /Breadcrumb -->
			
			<!-- Page Content -->
			<div class="content">
				<div class="container-fluid">

					<div class="row">
						<div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
						
							<!-- Profile Sidebar -->
							<div class="profile-sidebar">
								
								<?php echo $__env->make('doctor/Layout/doctor-widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
								
							</div>
							<!-- /Profile Sidebar -->
							
						</div>
                        <div class="col-md-7 col-lg-8 col-xl-9">
							<div class="card card-table">
								<div class="card-body">
								<div class="row p-3">
									<div class="col-md-6 col-lg-6">
										<h4>Add Medicines Form-list</h4>
										<?php if(session()->has('success')): ?>
								            <i class="alert alert-success"><?php echo e(session('success')); ?></i>
							            <?php endif; ?>
										<form action="<?php echo e(url('/addlistmedicine')); ?>" method="post" enctype="multipart/form-data">
											<?php echo csrf_field(); ?>
										<div class="form-group">
											<label>Medicines</label>
											<select class="col-lg-9 form-control" name="medicine_name">
											<option value="">Select</option>
												<?php
												foreach($medicine_arr as $data)
												{
												?>
												<option value="<?php echo $data->medicine_name;?>">
														<?php echo $data->medicine_name ?></option>
												<?php
												}
												?>			
											</select>
											<?php if($errors->has('medicine_name')): ?>
            									<span class="text-danger"><?php echo e($errors->first('medicine_name')); ?></span>
       										<?php endif; ?>
										</div>
										<div class="text-right">
											<button type="submit" style="margin-right:125px" class="btn btn-primary" name="submit" value="Send">Submit</button>
										</div>
										</form>
									</div>
									<div class="col-md-6 col-lg-6">
										<h4>Add Medicines </h4>
										<?php if(session()->has('succes')): ?>
								            <i class="alert alert-success"><?php echo e(session('succes')); ?></i>
							            <?php endif; ?>
										<form action="<?php echo e(url('/addmedicine')); ?>" method="post" enctype="multipart/form-data">
											<?php echo csrf_field(); ?>
										<div class="form-group col-lg-9">
											<label>Medicine </label>
											<input type="text" class="form-control" name="medicine_name1" placeholder="">
											<?php if($errors->has('medicine_name1')): ?>
            									<span class="text-danger"><?php echo e($errors->first('medicine_name1')); ?></span>
       										<?php endif; ?>
										</div>
										<div class="text-right">
											<button type="submit" style="margin-right:145px" class="btn btn-primary" name="submit" value="Send">Submit</button>
										</div>
										</form>
									</div>
								</div>
								</div>
								<hr>
								<?php if(session()->has('suc')): ?>
									<i class="alert alert-success"><?php echo e(session('suc')); ?></i>
								<?php endif; ?>
								<div class="table-responsive p-3">
												<table id="table" class="table table-hover table-center mb-0">
											<thead>
												<tr>
													<th>Medicine ID</th>
													<th>Medicine Name</th>
													<th class="text-right">Actions</th>
												</tr>
											</thead>
											<tbody>
											<?php
													foreach($medi_arr as $fetch) 
													{
												?>
												<tr>
													<td><?php echo $fetch->id?></td>
													<td><?php echo $fetch->medicine_name?></td>
													<td class="text-right">
														<div class="actions">
															<a  href="<?php echo e(url('doctor-my-medicine/'. $fetch->id)); ?>" class="btn btn-sm bg-danger-light">
																<i class="fe fe-trash"></i> Delete
															</a>
														</div>
													</td>
												</tr>
												<?php
												}
												?>
												
												
												
												
											</tbody>
										</table>
									</div>
								
									
									
								
							</div>
						</div>
                        

						



						
					</div>

				</div>

			</div>		
			<!-- /Page Content -->
   
			<!-- Footer -->
			<footer class="footer">
				
				<!-- Footer Top -->
				<div class="footer-top">
					<div class="container-fluid">
						<div class="row">
							<div class="col-lg-3 col-md-6">
							
								<!-- Footer Widget -->
								<div class="footer-widget footer-about">
									<div class="footer-logo">
										<img src="<?php echo e(url('Frontend/assets/img/footer-logo.png')); ?>" alt="logo">
									</div>
									<div class="footer-about-content">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
										<div class="social-icon">
											<ul>
												<li>
													<a href="#" target="_blank"><i class="fab fa-facebook-f"></i> </a>
												</li>
												<li>
													<a href="#" target="_blank"><i class="fab fa-twitter"></i> </a>
												</li>
												<li>
													<a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
												</li>
												<li>
													<a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
												</li>
												<li>
													<a href="#" target="_blank"><i class="fab fa-dribbble"></i> </a>
												</li>
											</ul>
										</div>
									</div>
								</div>
								<!-- /Footer Widget -->
								
							</div>
							
							<div class="col-lg-3 col-md-6">
							
								<!-- Footer Widget -->
								<div class="footer-widget footer-menu">
									<h2 class="footer-title">For Patients</h2>
									<ul>
										<li><a href="<?php echo e(url('/search')); ?>"><i class="fas fa-angle-double-right"></i> Search for Doctors</a></li>
										<li><a href="<?php echo e(url('/login')); ?>"><i class="fas fa-angle-double-right"></i> Login</a></li>
										<li><a href="<?php echo e(url('/login')); ?>"><i class="fas fa-angle-double-right"></i> Register</a></li>
										<li><a href="<?php echo e(url('/booking')); ?>"><i class="fas fa-angle-double-right"></i> Booking</a></li>
										<li><a href="<?php echo e(url('/patient-dashboard')); ?>"><i class="fas fa-angle-double-right"></i> Patient Dashboard</a></li>
									</ul>
								</div>
								<!-- /Footer Widget -->
								
							</div>
							
							<div class="col-lg-3 col-md-6">
							
								<!-- Footer Widget -->
								<div class="footer-widget footer-menu">
									<h2 class="footer-title">For Doctors</h2>
									<ul>
										<li><a href="<?php echo e(url('/appointments')); ?>"><i class="fas fa-angle-double-right"></i> Appointments</a></li>
										<li><a href="<?php echo e(url('/chat')); ?>"><i class="fas fa-angle-double-right"></i> Chat</a></li>
										<li><a href="<?php echo e(url('/login')); ?>"><i class="fas fa-angle-double-right"></i> Login</a></li>
										<li><a href="<?php echo e(url('/doctor-register')); ?>"><i class="fas fa-angle-double-right"></i> Register</a></li>
										<li><a href="<?php echo e(url('/doctor-dashboard')); ?>"><i class="fas fa-angle-double-right"></i> Doctor Dashboard</a></li>
									</ul>
								</div>
								<!-- /Footer Widget -->
								
							</div>
							
							<div class="col-lg-3 col-md-6">
							
								<!-- Footer Widget -->
								<div class="footer-widget footer-contact">
									<h2 class="footer-title">Contact Us</h2>
									<div class="footer-contact-info">
										<div class="footer-address">
											<span><i class="fas fa-map-marker-alt"></i></span>
											<p> 3556  Beech Street, San Francisco,<br> California, CA 94108 </p>
										</div>
										<p>
											<i class="fas fa-phone-alt"></i>
											+1 315 369 5943
										</p>
										<p class="mb-0">
											<i class="fas fa-envelope"></i>
											doccure@example.com
										</p>
									</div>
								</div>
								<!-- /Footer Widget -->
								
							</div>
							
						</div>
					</div>
				</div>
				<!-- /Footer Top -->
				
				<!-- Footer Bottom -->
                <div class="footer-bottom">
					<div class="container-fluid">
					
						<!-- Copyright -->
						<div class="copyright">
							<div class="row">
								<div class="col-md-6 col-lg-6">
									<div class="copyright-text">
										<p class="mb-0"><a href="templateshub.net">Templates Hub</a></p>
									</div>
								</div>
								<div class="col-md-6 col-lg-6">
								
									<!-- Copyright Menu -->
									<div class="copyright-menu">
										<ul class="policy-menu">
											<li><a href="<?php echo e(url('/term-condition')); ?>">Terms and Conditions</a></li>
											<li><a href="<?php echo e(url('/privacy-policy')); ?>">Policy</a></li>
										</ul>
									</div>
									<!-- /Copyright Menu -->
									
								</div>
							</div>
						</div>
						<!-- /Copyright -->
						
					</div>
				</div>
				<!-- /Footer Bottom -->
				
			</footer>
			<!-- /Footer -->
		   
		</div>
		<!-- /Main Wrapper -->
	  
		
		
		<!-- Bootstrap Core JS -->
		<script src="<?php echo e(url('Frontend/assets/js/popper.min.js')); ?>"></script>
		<script src="<?php echo e(url('Frontend/assets/js/bootstrap.min.js')); ?>"></script>
		
		<!-- Sticky Sidebar JS -->
        <script src="<?php echo e(url('Frontend/assets/plugins/theia-sticky-sidebar/ResizeSensor.js')); ?>"></script>
        <script src="<?php echo e(url('Frontend/assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js')); ?>"></script>
		
		<!-- Custom JS -->
		<script src="<?php echo e(url('Frontend/assets/js/script.js')); ?>"></script>
		
	</body>

<!-- doccure/<?php echo e(url('/invoices')); ?>  30 Nov 2019 04:12:14 GMT -->
</html>
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('doctor.Layout.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ADMP\resources\views/doctor/my-medicine.blade.php ENDPATH**/ ?>