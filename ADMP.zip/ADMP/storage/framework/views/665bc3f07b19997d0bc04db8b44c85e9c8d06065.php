<?php echo $__env->make('manager.Layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('main_container'); ?>

<?php /**PATH C:\xampp\htdocs\laravel\ADMP\resources\views/manager/Layout/main_layout.blade.php ENDPATH**/ ?>