@include('doctor.Layout.header')
@yield('main_container')

