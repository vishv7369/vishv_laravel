
<div class="container mt-3">
    <h1>{{$name}}</h1>  
    <h1>{{$body}}</h1>
    <h1>Your OTP : {{$ptbookotp}}</h1>
    <h1>Thanks for registration</h1>
</div>