@include('patient.Layout.header')
@yield('main_container')
@include('patient.Layout.footer')
